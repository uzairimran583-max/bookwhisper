const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ALLOWED_HOSTS = new Set([
  "www.googleapis.com",
  "openlibrary.org",
  "covers.openlibrary.org",
  "gutendex.com",
]);

const cache = new Map<string, { at: number; body: string; status: number }>();
const TTL_MS = 10 * 60 * 1000;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const target = new URL(req.url).searchParams.get("url");
    if (!target) {
      return json({ error: "Missing url parameter" }, 400);
    }

    let parsed: URL;
    try {
      parsed = new URL(target);
    } catch {
      return json({ error: "Invalid url" }, 400);
    }

    if (parsed.protocol !== "https:" || !ALLOWED_HOSTS.has(parsed.hostname)) {
      return json({ error: "Host not allowed" }, 403);
    }

    // Attach a Google Books API key when one is configured (higher quota).
    const googleKey = Deno.env.get("GOOGLE_BOOKS_API_KEY");
    if (googleKey && parsed.hostname === "www.googleapis.com" && !parsed.searchParams.get("key")) {
      parsed.searchParams.set("key", googleKey);
    }

    const cacheKey = parsed.toString();
    const hit = cache.get(cacheKey);
    if (hit && Date.now() - hit.at < TTL_MS) {
      return new Response(hit.body, {
        status: hit.status,
        headers: { ...corsHeaders, "Content-Type": "application/json", "X-Proxy-Cache": "hit" },
      });
    }

    const upstream = await fetch(cacheKey, {
      headers: { Accept: "application/json", "User-Agent": "BookWhisper/1.0" },
    });
    const body = await upstream.text();

    if (upstream.ok) {
      cache.set(cacheKey, { at: Date.now(), body, status: upstream.status });
    }

    return new Response(body, {
      status: upstream.status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("books-proxy error", error);
    return json({ error: String(error) }, 502);
  }
});

function json(payload: unknown, status: number) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
