CREATE TABLE public.saved_books (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  book_id TEXT NOT NULL,
  title TEXT NOT NULL,
  authors TEXT[],
  thumbnail TEXT,
  category TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, book_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_books TO authenticated;
GRANT ALL ON public.saved_books TO service_role;
ALTER TABLE public.saved_books ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their own saved books" ON public.saved_books FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);