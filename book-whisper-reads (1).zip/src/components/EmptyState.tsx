
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, Search, Sparkles, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionText?: string;
  actionLink?: string;
  type?: "search" | "library" | "recommendations" | "general";
}

const EmptyState = ({ 
  title, 
  description, 
  actionText, 
  actionLink,
  type = "general" 
}: EmptyStateProps) => {
  const configs = {
    search: {
      icon: Search,
      title: "No books found",
      description: "Try adjusting your search terms or explore our curated collections",
      actionText: "Explore Books",
      actionLink: "/explore",
      gradient: "from-blue-500/20 to-cyan-500/20"
    },
    library: {
      icon: BookOpen,
      title: "Your library is empty",
      description: "Start building your personal collection by saving books you're interested in",
      actionText: "Discover Books",
      actionLink: "/explore",
      gradient: "from-green-500/20 to-emerald-500/20"
    },
    recommendations: {
      icon: TrendingUp,
      title: "No recommendations yet",
      description: "Get personalized book recommendations powered by AI",
      actionText: "Try AI Features",
      actionLink: "/ai-features",
      gradient: "from-purple-500/20 to-pink-500/20"
    },
    general: {
      icon: Sparkles,
      title: "Nothing here yet",
      description: "Explore our vast collection of books and AI-powered features",
      actionText: "Get Started",
      actionLink: "/explore",
      gradient: "from-primary/20 to-accent/20"
    }
  };

  const config = configs[type];
  const finalTitle = title || config.title;
  const finalDescription = description || config.description;
  const finalActionText = actionText || config.actionText;
  const finalActionLink = actionLink || config.actionLink;

  const IconComponent = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-[400px] p-8"
    >
      <Card className="modern-card max-w-md w-full p-8 text-center">
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className={`w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br ${config.gradient} flex items-center justify-center`}
        >
          <IconComponent className="h-10 w-10 text-primary" />
        </motion.div>

        <motion.h3
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="heading-modern text-xl mb-3"
        >
          {finalTitle}
        </motion.h3>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-modern mb-6 leading-relaxed"
        >
          {finalDescription}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Button asChild className="btn-primary-modern">
            <Link to={finalActionLink}>
              {finalActionText}
            </Link>
          </Button>
        </motion.div>

        {/* Decorative elements */}
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-primary/20 rounded-full animate-pulse" />
        <div className="absolute -bottom-2 -left-2 w-3 h-3 bg-accent/20 rounded-full animate-pulse delay-300" />
      </Card>
    </motion.div>
  );
};

export default EmptyState;
