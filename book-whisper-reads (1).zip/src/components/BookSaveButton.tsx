
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Bookmark, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { Book } from "@/services/bookService";
import { savedBooksService } from "@/services/savedBooksService";
import { useAuth } from "@/context/AuthContext";
import BookDetailAuthPrompt from "./BookDetailAuthPrompt";
import { motion } from "framer-motion";

interface BookSaveButtonProps {
  book: Book;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg" | "icon";
}

const BookSaveButton = ({ book, variant = "outline", size = "default" }: BookSaveButtonProps) => {
  const [isSaved, setIsSaved] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const checkIfSaved = async () => {
      if (isAuthenticated) {
        setIsChecking(true);
        const saved = await savedBooksService.isBookSaved(book.id);
        setIsSaved(saved);
        setIsChecking(false);
      } else {
        setIsChecking(false);
      }
    };

    checkIfSaved();
  }, [book.id, isAuthenticated]);

  const handleSave = async (e: React.MouseEvent) => {
    if (!isAuthenticated) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    if (isSaved) {
      const success = await savedBooksService.removeBook(book.id);
      if (success) {
        setIsSaved(false);
      }
    } else {
      const success = await savedBooksService.saveBook(book);
      if (success) {
        setIsSaved(true);
      }
    }
  };

  if (isChecking) {
    return (
      <Button variant={variant} size={size} disabled className="opacity-50">
        <Bookmark className="h-4 w-4" />
        {size !== "icon" && <span className="ml-2">Save</span>}
      </Button>
    );
  }

  if (!isAuthenticated) {
    return (
      <BookDetailAuthPrompt triggerAction="save books">
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button variant={variant} size={size}>
            <Bookmark className="h-4 w-4" />
            {size !== "icon" && <span className="ml-2">Save</span>}
          </Button>
        </motion.div>
      </BookDetailAuthPrompt>
    );
  }

  return (
    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
      <Button
        variant={isSaved ? "default" : variant}
        size={size}
        onClick={handleSave}
        className={isSaved ? "bg-green-500 hover:bg-green-600" : ""}
      >
        {isSaved ? (
          <>
            <CheckCircle className="h-4 w-4" />
            {size !== "icon" && <span className="ml-2">Saved</span>}
          </>
        ) : (
          <>
            <Bookmark className="h-4 w-4" />
            {size !== "icon" && <span className="ml-2">Save</span>}
          </>
        )}
      </Button>
    </motion.div>
  );
};

export default BookSaveButton;
