import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Book } from "@/services/bookService";
import {
  Bookmark,
  BookmarkCheck,
  Share2,
  Headphones,
  Star,
  ImageIcon,
  ShoppingCart,
  Lock,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { motion } from "framer-motion";
import ImageLoader from "@/components/ImageLoader";
import { savedBooksService } from "@/services/savedBooksService";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { openAmazonBook } from "@/utils/amazonAffiliate";
import { useAuth } from "@/context/AuthContext";

interface BookCardProps {
  book: Book;
  highlightCategory?: boolean;
  isPremium?: boolean;
  showAudio?: boolean;
  isFeatured?: boolean;
}

const BookCard = ({ 
  book, 
  highlightCategory = false, 
  showAudio = false,
  isFeatured = false 
}: BookCardProps) => {
  const [isSaved, setIsSaved] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const { isAuthenticated, openAuthModal } = useAuth();
  
  useEffect(() => {
    let isMounted = true;
    const checkStatus = async () => {
      const saved = await savedBooksService.isBookSaved(book.id);
      if (isMounted) {
        setIsSaved(saved);
      }
    };
    checkStatus();

    const handleSavedSync = async () => {
      if (isMounted) {
        const saved = await savedBooksService.isBookSaved(book.id);
        setIsSaved(saved);
      }
    };

    window.addEventListener("bookwhisper:saved_books_changed", handleSavedSync);
    return () => {
      isMounted = false;
      window.removeEventListener("bookwhisper:saved_books_changed", handleSavedSync);
    };
  }, [book.id]);
  
  const handleSaveBook = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isSaved) {
      const success = await savedBooksService.removeBook(book.id);
      if (success) {
        setIsSaved(false);
      }
    } else {
      const success = await savedBooksService.saveBook(book);
      if (success) {
        setIsSaved(true);
      }
    }
  };
  
  const handleBuyBook = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      toast.info("Sign in with Gmail to unlock book purchasing.");
      openAuthModal(`Sign in with Gmail to buy "${book.title}"`);
      return;
    }

    toast.success("Opening book purchase link in a new tab...");
    openAmazonBook({
      title: book.title,
      author: book.authors?.[0],
      bookId: book.id,
      thumbnail: book.thumbnail,
    });
  };

  const handleShareBook = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (navigator.share) {
      navigator.share({
        title: book.title,
        text: `Check out this book: ${book.title} by ${book.authors.join(", ")}`,
        url: window.location.origin + `/book/${book.id}`,
      }).catch(err => {
        console.error('Error sharing:', err);
      });
    } else {
      navigator.clipboard.writeText(window.location.origin + `/book/${book.id}`);
      toast.success('Link copied to clipboard!');
    }
  };
  
  const cardVariants = {
    hover: {
      scale: 1.02,
      boxShadow: "0px 20px 40px rgba(0, 0, 0, 0.1)",
      transition: { duration: 0.3, type: "spring" as const, stiffness: 300 }
    },
    tap: {
      scale: 0.98,
      transition: { duration: 0.2 }
    }
  };
  
  const MotionCard = motion(Card);
  
  return (
    <Link to={`/book/${book.id}`} className="block h-full group">
      <MotionCard 
        className="book-card h-full flex flex-col overflow-hidden relative border border-border/70 shadow-sm hover:shadow-lg transition-all rounded-xl"
        initial="rest"
        whileHover="hover"
        whileTap="tap"
        variants={cardVariants}
      >
        <div className="relative h-64 overflow-hidden bg-gradient-to-br from-muted to-muted/50">
          <ImageLoader
            src={book.thumbnail}
            alt={`Cover of ${book.title}`}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            animate={true}
            onLoad={() => setImageLoaded(true)}
          />
          
          {!imageLoaded && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted">
              <ImageIcon className="h-6 w-6 text-muted-foreground mb-1" />
              <span className="text-xs text-muted-foreground">Loading...</span>
            </div>
          )}
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {highlightCategory && book.categories && book.categories.length > 0 && (
            <motion.div 
              className="absolute top-2 left-2 z-10"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <span className="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider rounded-md bg-background/90 backdrop-blur-sm text-foreground shadow-sm">
                {book.categories[0]}
              </span>
            </motion.div>
          )}
          
          {showAudio && (
            <div className="absolute bottom-2 left-2 z-10">
              <span className="px-2 py-0.5 text-[10px] rounded-md bg-amber-500/95 text-white font-bold backdrop-blur-sm shadow-sm flex items-center gap-1">
                <Headphones className="h-3 w-3" /> AUDIBLE
              </span>
            </div>
          )}
          
          {isFeatured && (
            <div className="absolute top-2 left-2 z-10">
              <span className="px-2 py-0.5 text-[10px] rounded-md bg-primary text-primary-foreground font-bold shadow-sm flex items-center gap-1">
                <Star className="h-3 w-3" /> BESTSELLER
              </span>
            </div>
          )}
          
          {/* Top Right Quick Actions Menu */}
          <div 
            className="absolute top-2 right-2 opacity-90 group-hover:opacity-100 transition-opacity z-10"
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
          >
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="secondary" 
                  size="icon" 
                  className="h-8 w-8 rounded-full bg-background/90 hover:bg-background shadow-md border border-border"
                >
                  {isSaved ? (
                    <BookmarkCheck className="h-4 w-4 text-primary fill-current" />
                  ) : (
                    <Bookmark className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                <DropdownMenuItem onClick={handleSaveBook}>
                  {isSaved ? (
                    <>
                      <BookmarkCheck className="h-4 w-4 mr-2 text-primary fill-current" /> Remove from Shelf
                    </>
                  ) : (
                    <>
                      <Bookmark className="h-4 w-4 mr-2" /> Save to My Library
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleBuyBook}>
                  {!isAuthenticated ? (
                    <>
                      <Lock className="h-4 w-4 mr-2 text-amber-500" /> Buy Book (Locked)
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="h-4 w-4 mr-2 text-amber-500" /> Buy Book ↗
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleShareBook}>
                  <Share2 className="h-4 w-4 mr-2" /> Share Book
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <CardContent className="flex-1 flex flex-col p-4 bg-card">
          <h3 className="font-semibold text-sm sm:text-base line-clamp-2 group-hover:text-primary transition-colors leading-snug mb-1 text-foreground">
            {book.title}
          </h3>
          <p className="text-xs text-muted-foreground mb-3 font-medium line-clamp-1">
            {book.authors.join(", ")}
          </p>
          
          <div className="mt-auto pt-2 border-t border-border/40 flex justify-between items-center text-xs">
            <span className="text-muted-foreground text-[11px]">
              {book.publishedDate ? book.publishedDate.substring(0, 4) : 'Available'}
            </span>

            {/* Quick Buy Button */}
            <div onClick={(e) => { e.stopPropagation(); }}>
              <AmazonBuyButton
                bookTitle={book.title}
                author={book.authors?.[0]}
                bookId={book.id}
                thumbnail={book.thumbnail}
                variant="compact"
                size="sm"
              />
            </div>
          </div>
        </CardContent>
      </MotionCard>
    </Link>
  );
};

export default BookCard;
