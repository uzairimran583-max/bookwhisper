import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import {
  Lock,
  Sparkles,
  BookOpen,
  Headphones,
  Brain,
  MessageSquare,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  LogIn,
  UserPlus
} from "lucide-react";
import { toast } from "sonner";

interface RequireAuthProps {
  children: React.ReactNode;
  requireAuth?: boolean;
  showModal?: boolean;
  feature?: string;
}

export function RequireAuth({
  children,
  requireAuth = true,
  feature = "AI Summaries & Literary Tools",
}: RequireAuthProps) {
  const { isAuthenticated, isLoading, signInWithGmail } = useAuth();
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const location = useLocation();

  if (!requireAuth) {
    return <>{children}</>;
  }

  // During initial auth check, don't flash gate
  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Verifying access...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <>{children}</>;
  }

  const handleQuickSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes("@")) {
      toast.error("Please enter a valid Gmail / email address");
      return;
    }

    setSubmitting(true);
    try {
      await signInWithGmail(email.trim());
      toast.success("Welcome! AI features are now unlocked.");
    } catch {
      toast.error("Failed to sign in. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container min-h-[75vh] flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-xl"
      >
        <Card className="relative overflow-hidden border-border/80 shadow-2xl bg-card/90 backdrop-blur-xl p-6 sm:p-8 rounded-3xl">
          {/* Ambient background glow */}
          <div className="absolute -top-24 -right-24 w-60 h-60 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="text-center space-y-3 relative z-10">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-primary/20 border border-amber-500/30 text-amber-500 shadow-inner">
              <Lock className="w-8 h-8" />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-xs font-semibold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" /> Sign-In Required
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground">
              Unlock {feature}
            </h1>

            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              AI Summaries, Deep Literary Analysis, AI Chat, and Voice Narration are reserved for signed-in readers. Sign in or sign up free to continue.
            </p>
          </div>

          {/* Feature Highlights Gated */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-6 relative z-10">
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-muted/40 border border-border/50 text-xs font-medium">
              <BookOpen className="w-4 h-4 text-primary shrink-0" />
              <span>Full AI Book Summaries</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-muted/40 border border-border/50 text-xs font-medium">
              <Brain className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>Deep Literary Analysis</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-muted/40 border border-border/50 text-xs font-medium">
              <MessageSquare className="w-4 h-4 text-cyan-500 shrink-0" />
              <span>Interactive AI Chat Suite</span>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-muted/40 border border-border/50 text-xs font-medium">
              <Headphones className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Audible Voice Narration</span>
            </div>
          </div>

          {/* Quick 1-Click Sign-in Form */}
          <form onSubmit={handleQuickSignIn} className="space-y-3 relative z-10">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-foreground">
                Enter Gmail or Email for instant access:
              </label>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="your.email@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={submitting}
                  className="rounded-xl bg-background/80"
                  required
                />
                <Button
                  type="submit"
                  disabled={submitting}
                  className="rounded-xl px-5 font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-md"
                >
                  {submitting ? "Signing in..." : "Unlock Now"}
                </Button>
              </div>
            </div>
          </form>

          {/* Alternative standard Sign In / Sign Up buttons */}
          <div className="mt-5 pt-5 border-t border-border/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs relative z-10">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Link to="/login" state={{ from: location }} className="flex-1 sm:flex-none">
                <Button variant="outline" size="sm" className="w-full rounded-xl text-xs gap-1.5">
                  <LogIn className="w-3.5 h-3.5" /> Sign In
                </Button>
              </Link>
              <Link to="/signup" state={{ from: location }} className="flex-1 sm:flex-none">
                <Button variant="secondary" size="sm" className="w-full rounded-xl text-xs gap-1.5">
                  <UserPlus className="w-3.5 h-3.5" /> Create Account
                </Button>
              </Link>
            </div>

            <Link
              to="/"
              className="text-muted-foreground hover:text-foreground text-xs font-medium underline-offset-4 hover:underline"
            >
              Browse catalog as guest →
            </Link>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
export default RequireAuth;
