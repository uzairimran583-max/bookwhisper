
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CategoryFilterProps {
  onSelectCategory: (category: string) => void;
  selectedCategory: string;
}

const CATEGORIES = [
  "All",
  "Fiction",
  "Business",
  "Entrepreneurship",
  "Leadership",
  "Investing",
  "Technology",
  "Innovation",
  "Science",
  "Biography",
  "History",
  "Self-Help",
  "Philosophy",
  "Psychology",
  "Economy",
];

const CategoryFilter = ({ onSelectCategory, selectedCategory }: CategoryFilterProps) => {
  return (
    <div className="mb-6">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-2 pb-2">
          {CATEGORIES.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => onSelectCategory(category)}
              className="transition-all rounded-full text-xs py-1 px-3 h-auto"
            >
              {category}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default CategoryFilter;
