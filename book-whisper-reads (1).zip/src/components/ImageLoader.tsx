
import React, { useState, useEffect, useCallback } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

interface ImageLoaderProps {
  src: string;
  alt: string;
  className?: string;
  fallbackSrc?: string;
  objectFit?: "cover" | "contain" | "fill" | "none" | "scale-down";
  onLoad?: () => void;
  animate?: boolean;
}

const ImageLoader = ({ 
  src, 
  alt, 
  className = "", 
  fallbackSrc = "/placeholder.svg",
  objectFit = "cover",
  onLoad: externalOnLoadHandler,
  animate = false
}: ImageLoaderProps) => {
  const [imgSrc, setImgSrc] = useState<string>(src);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  
  // Enhanced URL optimization for better image loading
  useEffect(() => {
    setIsLoading(true);
    setHasError(false);
    setRetryCount(0);
    
    if (!src) {
      setImgSrc(fallbackSrc);
      setIsLoading(false);
      return;
    }
    
    // Optimize image URLs for better loading
    let optimizedUrl = src;
    
    // Force HTTPS for security and better loading
    if (src.startsWith('http:')) {
      optimizedUrl = src.replace('http:', 'https:');
    }
    
    // Enhanced optimization for Google Books images
    if (src.includes("books.google.com")) {
      optimizedUrl = optimizedUrl.replace(/&edge=curl/g, '');
      if (!optimizedUrl.includes('zoom=')) {
        optimizedUrl += '&zoom=1';
      }
    }

    // Enhanced optimization for OpenLibrary covers
    if (src.includes("covers.openlibrary.org")) {
      optimizedUrl = optimizedUrl.replace(/-S\.jpg/, '-M.jpg').replace(/-L\.jpg/, '-M.jpg');
    }

    
    setImgSrc(optimizedUrl);
    console.log("Optimized image URL:", optimizedUrl);
  }, [src, fallbackSrc]);

  // Enhanced retry mechanism with exponential backoff
  useEffect(() => {
    if (hasError && retryCount < 3) {
      const retryDelay = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
      
      const timer = setTimeout(() => {
        console.log(`Retrying image load (attempt ${retryCount + 1}/3)...`);
        
        let retryUrl = src;
        if (src.startsWith('http:')) {
          retryUrl = src.replace('http:', 'https:');
        }
        
        // Add retry-specific cache busting
        const timestamp = Date.now();
        const retryParam = `retry=${retryCount + 1}&t=${timestamp}`;
        
        if (retryUrl.includes('?')) {
          retryUrl += `&${retryParam}`;
        } else {
          retryUrl += `?${retryParam}`;
        }
        
        setImgSrc(retryUrl);
        setHasError(false);
        setIsLoading(true);
        setRetryCount(prev => prev + 1);
      }, retryDelay);
      
      return () => clearTimeout(timer);
    }
  }, [hasError, retryCount, src]);

  const handleLoad = useCallback(() => {
    setIsLoading(false);
    setHasError(false);
    console.log("Image loaded successfully:", imgSrc);
    if (externalOnLoadHandler) {
      externalOnLoadHandler();
    }
  }, [imgSrc, externalOnLoadHandler]);

  const [showFallbackCover, setShowFallbackCover] = useState(false);

  const handleError = useCallback(() => {
    setIsLoading(false);
    setHasError(true);
    setShowFallbackCover(true);
  }, []);
  
  // Preload image for better performance
  useEffect(() => {
    if (imgSrc && imgSrc !== fallbackSrc) {
      const img = new Image();
      img.onload = handleLoad;
      img.onerror = handleError;
      img.src = imgSrc;
      
      return () => {
        img.onload = null;
        img.onerror = null;
      };
    } else if (!imgSrc || imgSrc === fallbackSrc) {
      setShowFallbackCover(true);
      setIsLoading(false);
    }
  }, [imgSrc, fallbackSrc, handleLoad, handleError]);

  // Clean title for fallback
  const cleanTitle = alt.replace(/^Cover of /i, "");

  if (showFallbackCover) {
    return (
      <div className={`w-full h-full flex flex-col justify-between p-4 bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 text-white relative overflow-hidden select-none border-l-4 border-amber-600/60 shadow-inner ${className}`}>
        <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="text-[10px] font-mono tracking-widest uppercase text-amber-400/80">
          BookWhisper
        </div>
        <div className="my-auto py-2">
          <div className="font-serif text-sm sm:text-base font-bold line-clamp-3 leading-snug tracking-tight text-slate-100">
            {cleanTitle || "Book Summary"}
          </div>
        </div>
        <div className="text-[10px] text-slate-400 flex items-center justify-between border-t border-white/10 pt-2">
          <span>Read Insight</span>
          <span className="font-mono">15m</span>
        </div>
      </div>
    );
  }
  
  if (animate) {
    return (
      <motion.div 
        className="relative w-full h-full"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        {isLoading && (
          <Skeleton className="absolute inset-0 animate-pulse bg-muted" />
        )}
        <motion.img
          src={imgSrc}
          alt={alt}
          referrerPolicy="no-referrer"
          className={`w-full h-full object-${objectFit} transition-all duration-500 ${className} ${isLoading ? 'opacity-0' : 'opacity-100'}`}
          onLoad={handleLoad}
          onError={handleError}
          loading="lazy"
          initial={{ opacity: 0 }}
          animate={{ opacity: isLoading ? 0 : 1 }}
          transition={{ duration: 0.3 }}
        />
        {retryCount > 0 && retryCount < 3 && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/80">
            <span className="text-xs text-muted-foreground">Retrying...</span>
          </div>
        )}
      </motion.div>
    );
  }

  return (
    <div className="relative w-full h-full">
      {isLoading && (
        <Skeleton className="absolute inset-0 animate-pulse bg-muted" />
      )}
      <img
        src={imgSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        className={`w-full h-full object-${objectFit} transition-all duration-500 ${className} ${isLoading ? 'opacity-0' : 'opacity-100'}`}
        onLoad={handleLoad}
        onError={handleError}
        loading="lazy"
      />
      {retryCount > 0 && retryCount < 3 && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/80">
          <span className="text-xs text-muted-foreground">Retrying...</span>
        </div>
      )}
    </div>
  );
};

export default ImageLoader;
