import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import { GmailAuthModal } from "./GmailAuthModal";

const Layout = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <GmailAuthModal />
    </div>
  );
};

export default Layout;
