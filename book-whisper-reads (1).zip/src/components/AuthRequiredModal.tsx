import React from "react";
import { GmailAuthModal } from "./GmailAuthModal";
import { useAuth } from "@/context/AuthContext";

interface AuthRequiredModalProps {
  open: boolean;
  setOpen: (open: boolean) => void;
  feature?: string;
}

const AuthRequiredModal = ({ open, setOpen, feature }: AuthRequiredModalProps) => {
  const { openAuthModal } = useAuth();

  React.useEffect(() => {
    if (open) {
      openAuthModal(feature ? `Sign in with Gmail to use ${feature}` : undefined);
      setOpen(false);
    }
  }, [open, feature, openAuthModal, setOpen]);

  return <GmailAuthModal />;
};

export default AuthRequiredModal;
