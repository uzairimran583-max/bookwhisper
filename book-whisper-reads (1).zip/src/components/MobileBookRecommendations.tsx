import { useState, useEffect } from "react";
import { Book, getTrendingBooks, getBooksByCategory } from "@/services/bookService";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Star, BookOpen } from "lucide-react";
import { motion } from "framer-motion";
import { subscriptionService } from "@/services/subscriptionService";
import ImageLoader from "@/components/ImageLoader";
import { toast } from "sonner";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";

const MobileBookRecommendations = () => {
  const [popularBooks, setPopularBooks] = useState<Book[]>([]);
  const [dailyPicks, setDailyPicks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [notificationCount, setNotificationCount] = useState(3);
  const navigate = useNavigate();
  const currentPlan = subscriptionService.getCurrentPlan();

  useEffect(() => {
    const fetchBooks = async () => {
      setLoading(true);
      try {
        // Use Promise.all to fetch all types of books in parallel
        const [trending, fiction] = await Promise.all([
          getTrendingBooks(), // Using regular trending books instead of enhanced
          getBooksByCategory("fiction", 6),
        ]);
        
        setPopularBooks(trending);
        setDailyPicks(fiction);
      } catch (error) {
        console.error("Error fetching books:", error);
        toast.error("Could not load recommended books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();
  }, []);

  // Animated variants for scroll animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring" as const,
        stiffness: 260,
        damping: 20
      }
    }
  };

  // Handle book click
  const handleBookClick = (book: Book) => {
    navigate(`/book/${book.id}`, {
      state: { bookData: book }
    });
  };

  const handleNotificationClick = () => {
    setNotificationCount(0);
    toast.success("Notifications cleared");
  };

  // Loading skeleton
  if (loading) {
    return (
      <div className="container py-6 space-y-10">
        <div className="space-y-4">
          <div className="h-8 w-40 bg-muted rounded animate-pulse"></div>
          <div className="flex space-x-4 overflow-x-auto pb-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="w-32 flex-shrink-0">
                <div className="h-48 bg-muted rounded-lg animate-pulse"></div>
                <div className="h-4 w-3/4 bg-muted rounded mt-2 animate-pulse"></div>
                <div className="h-3 w-1/2 bg-muted rounded mt-1 animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 mb-20 relative">
      {/* Popular Books Section with Luxury Design */}
      <motion.div 
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="mb-10"
      >
        <motion.h2 
          className="text-2xl font-bold mb-4 tracking-tight bg-gradient-to-r from-purple-600 via-primary to-amber-600 bg-clip-text text-transparent"
          variants={itemVariants}
        >
          Popular Books
        </motion.h2>
        
        <Carousel className="w-full">
          <CarouselContent>
            {popularBooks.map((book) => (
              <CarouselItem key={book.id} className="basis-1/2 sm:basis-1/3 md:basis-1/4 lg:basis-1/5">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  variants={itemVariants}
                  onClick={() => handleBookClick(book)}
                >
                  <Card className="overflow-hidden border-2 shadow-lg border-primary/10 hover:border-primary/30 transition-all duration-300 bg-gradient-to-b from-background to-background/60">
                    <div className="aspect-[2/3] relative">
                      <ImageLoader
                        src={book.thumbnail || ''}
                        alt={book.title}
                        className="w-full h-full object-cover rounded-t-lg"
                        fallbackSrc="/placeholder.svg"
                      />
                      {currentPlan.id !== 'premium' && Math.random() > 0.7 && (
                        <div className="absolute top-2 right-2 bg-primary/90 text-white text-xs px-2 py-1 rounded-full">
                          Premium
                        </div>
                      )}
                      
                      {book.averageRating && book.averageRating > 0 && (
                        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full flex items-center">
                          <Star className="w-3 h-3 text-yellow-400 mr-1" fill="#FFD700" />
                          <span>{book.averageRating.toFixed(1)}</span>
                        </div>
                      )}
                    </div>
                    <div className="p-3 backdrop-blur-sm bg-gradient-to-b from-transparent to-background/80">
                      <h3 className="font-semibold line-clamp-1 text-foreground">{book.title}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-1">
                        {book.authors?.join(", ") || "Unknown Author"}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="hidden sm:block">
            <CarouselPrevious className="-left-3" />
            <CarouselNext className="-right-3" />
          </div>
        </Carousel>
      </motion.div>

      {/* Daily Picks Section */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="mb-8"
      >
        <div className="mb-6">
          <motion.h2 
            className="text-2xl font-bold mb-1 tracking-tight bg-gradient-to-r from-amber-600 via-primary to-purple-600 bg-clip-text text-transparent"
            variants={itemVariants}
          >
            Daily Picks
          </motion.h2>
          <motion.p 
            className="text-sm text-muted-foreground"
            variants={itemVariants}
          >
            Similar to your Book Crushes
          </motion.p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {dailyPicks.map((book, index) => (
            <motion.div
              key={book.id}
              variants={itemVariants}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleBookClick(book)}
              className="cursor-pointer"
            >
              <Card className="overflow-hidden rounded-xl border-2 border-primary/10 hover:border-primary/30 shadow-md hover:shadow-lg bg-gradient-to-b from-background to-background/60 transition-all duration-300">
                <div className="aspect-[2/3] relative">
                  <ImageLoader
                    src={book.thumbnail}
                    alt={book.title}
                    className="w-full h-full object-cover rounded-t-lg"
                    fallbackSrc="/placeholder.svg"
                  />
                  {index === 0 && (
                    <div className="absolute top-2 left-2 flex space-x-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="h-3 w-3"
                          fill={i < 4 ? "#FFD700" : "none"}
                          stroke={i < 4 ? "#FFD700" : "#64748b"}
                        />
                      ))}
                    </div>
                  )}
                </div>
                <div className="p-3 space-y-1 backdrop-blur-sm bg-gradient-to-b from-transparent to-background/80">
                  <h3 className="font-semibold text-sm line-clamp-1">
                    {book.title}
                  </h3>
                  <p className="text-xs text-muted-foreground line-clamp-1">
                    {book.authors?.join(", ") || "Unknown Author"}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Today's Discovery Section */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="mb-8"
      >
        <motion.h2 
          className="text-2xl font-bold mb-4 tracking-tight bg-gradient-to-r from-primary via-purple-600 to-amber-600 bg-clip-text text-transparent"
          variants={itemVariants}
        >
          Today's Discovery
        </motion.h2>
        
        {popularBooks.length > 0 && (
          <Card className="overflow-hidden border-0 shadow-xl relative flex flex-col sm:flex-row">
            <div className="sm:w-1/3 aspect-[2/3] sm:aspect-auto relative">
              <ImageLoader
                src={popularBooks[0].thumbnail}
                alt={popularBooks[0].title}
                className="w-full h-full object-cover"
                fallbackSrc="/placeholder.svg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent sm:bg-gradient-to-r"></div>
            </div>
            <div className="p-6 sm:w-2/3 bg-gradient-to-br from-background to-background/90 backdrop-blur-sm">
              <h3 className="text-xl font-bold mb-2">{popularBooks[0].title}</h3>
              <p className="text-sm text-muted-foreground mb-4">
                {popularBooks[0].authors?.join(", ") || "Unknown Author"}
              </p>
              <p className="text-sm mb-6 line-clamp-3">
                {popularBooks[0].description || "No description available."}
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex items-center gap-2 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                  onClick={() => handleBookClick(popularBooks[0])}
                >
                  <BookOpen className="h-4 w-4" />
                  View Details
                </Button>
              </div>
            </div>
          </Card>
        )}
      </motion.div>

      {/* Floating Action Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-10"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring" as const }}
      >
        <Button 
          size="icon" 
          className="h-14 w-14 rounded-full shadow-lg bg-gradient-to-br from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 transition-all duration-300"
          onClick={handleNotificationClick}
        >
          <div className="relative">
            <Bell className="h-6 w-6 text-white" />
            {notificationCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                {notificationCount}
              </span>
            )}
          </div>
        </Button>
      </motion.div>
    </div>
  );
};

export default MobileBookRecommendations;
