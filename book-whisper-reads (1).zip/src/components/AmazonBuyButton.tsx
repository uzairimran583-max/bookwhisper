import React from "react";
import { Button } from "@/components/ui/button";
import { ShoppingCart, ExternalLink, Sparkles } from "lucide-react";
import { toast } from "sonner";
import {
  getAmazonBookUrl,
  openAmazonBook,
  AMAZON_FALLBACK_LINK,
} from "@/utils/amazonAffiliate";

export const AMAZON_AFFILIATE_LINK = AMAZON_FALLBACK_LINK;

interface AmazonBuyButtonProps {
  bookTitle?: string;
  author?: string;
  bookId?: string;
  isbn?: string;
  thumbnail?: string;
  variant?: "default" | "outline" | "compact" | "banner";
  size?: "default" | "sm" | "lg" | "icon";
  className?: string;
  showPriceHint?: boolean;
}

export const AmazonBuyButton: React.FC<AmazonBuyButtonProps> = ({
  bookTitle,
  author,
  bookId,
  isbn,
  thumbnail,
  variant = "default",
  size = "default",
  className = "",
  showPriceHint = false,
}) => {
  const purchaseUrl = getAmazonBookUrl({
    title: bookTitle,
    author,
    bookId,
    isbn,
    thumbnail,
  });

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toast.success(
      bookTitle
        ? `Opening "${bookTitle}" on Amazon...`
        : "Opening book on Amazon..."
    );
  };

  // Compact variant (used on cards and top reader bars)
  if (variant === "compact") {
    return (
      <a
        href={purchaseUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className={`inline-flex items-center justify-center font-medium text-xs rounded-lg px-2.5 py-1.5 transition-all bg-amber-500/15 text-amber-700 dark:text-amber-300 hover:bg-amber-500/25 border border-amber-500/30 hover:border-amber-500/60 active:scale-95 group shadow-xs ${className}`}
        title={bookTitle ? `Buy "${bookTitle}" on Amazon` : "Buy Book on Amazon"}
      >
        <ShoppingCart className="h-3.5 w-3.5 mr-1 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform" />
        <span>Buy</span>
        <ExternalLink className="h-3 w-3 ml-1 opacity-70 group-hover:opacity-100 transition-opacity" />
      </a>
    );
  }

  // Banner variant (used at the end of reader and detailed overview)
  if (variant === "banner") {
    return (
      <a
        href={purchaseUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className={`block rounded-2xl p-4 sm:p-5 border transition-all bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-background border-amber-500/40 hover:border-amber-500 shadow-md hover:shadow-lg active:scale-[0.99] group ${className}`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 group-hover:rotate-6 transition-transform">
              <ShoppingCart className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-foreground">
                  Buy Exact Book Copy
                </span>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
                  Amazon Official
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {bookTitle ? `Get the hardcover, paperback, or Kindle edition of "${bookTitle}"` : "Get the verified paperback or Kindle edition on Amazon"}
              </p>
            </div>
          </div>

          <div className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm shrink-0 shadow-sm transition-colors group-hover:shadow-md">
            <ShoppingCart className="h-4 w-4" />
            <span>Buy on Amazon</span>
            <ExternalLink className="h-3.5 w-3.5 ml-1" />
          </div>
        </div>
      </a>
    );
  }

  // Outline variant
  if (variant === "outline") {
    return (
      <a
        href={purchaseUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className={`inline-flex items-center justify-center font-semibold rounded-lg px-3 py-1.5 transition-all border border-amber-500/40 text-amber-600 dark:text-amber-400 hover:bg-amber-500/15 hover:border-amber-500 active:scale-95 text-xs sm:text-sm group ${className}`}
        title={bookTitle ? `Buy "${bookTitle}" on Amazon` : "Buy Book on Amazon"}
      >
        <ShoppingCart className="h-3.5 w-3.5 mr-1.5 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform" />
        <span>Buy Book</span>
        <ExternalLink className="h-3 w-3 ml-1 opacity-70 group-hover:opacity-100" />
      </a>
    );
  }

  // Default button variant
  return (
    <a
      href={purchaseUrl}
      target="_blank"
      rel="noopener noreferrer"
      onClick={handleClick}
      className={`inline-flex items-center justify-center font-semibold rounded-lg px-4 py-2 transition-all bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-md hover:shadow-lg active:scale-95 group text-sm ${className}`}
      title={bookTitle ? `Buy "${bookTitle}" on Amazon` : "Buy Book on Amazon"}
    >
      <ShoppingCart className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
      <span>Buy</span>
      <ExternalLink className="h-3.5 w-3.5 ml-1.5 opacity-80 group-hover:opacity-100" />
    </a>
  );
};

export default AmazonBuyButton;
