
import { motion } from "framer-motion";
import Logo from "./navbar/Logo";
import SearchBar from "./navbar/SearchBar";
import ThemeToggle from "./navbar/ThemeToggle";
import UserMenu from "./navbar/UserMenu";
import MobileNavigation from "./navbar/MobileNavigation";
import NavigationLinks from "./navbar/NavigationLinks";

const Navbar = () => {
  return (
    <>
      <motion.header 
        className="sticky top-0 z-50 navbar-modern w-full py-3"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Logo />
            <NavigationLinks />
          </div>
          
          <SearchBar />
          
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <UserMenu />
          </div>
        </div>
      </motion.header>
      
      <MobileNavigation />
    </>
  );
};

export default Navbar;
