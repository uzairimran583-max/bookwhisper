
import { useNavigate } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import ImageLoader from "@/components/ImageLoader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Lock, UserPlus } from "lucide-react";
import { Link } from "react-router-dom";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";
import { BookItem } from "@/data/billionaireRecommendations";
import { useBillionaireRecommendations } from "@/hooks/useBillionaireRecommendations";
import { useAuth } from "@/context/AuthContext";

const BillionaireRecommendations = () => {
  const navigate = useNavigate();
  const { loading, currentBillionaire, displayedRecommendations } = useBillionaireRecommendations();
  const { isAuthenticated } = useAuth();

  const handleBookClick = (book: BookItem) => {
    if (!isAuthenticated) return;
    
    try {
      // Store book data in session storage for recovery from 404s
      sessionStorage.setItem('billionaireBook', JSON.stringify(book));
      
      // Mark current valid route for recovery
      sessionStorage.setItem('lastValidRoute', '/');
      
      // Navigate to book detail page
      navigate(`/book/${book.id}`, { state: { fromBillionaire: true, bookData: book } });
    } catch (error) {
      console.error("Error navigating to book:", error);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring" as const,
        stiffness: 260,
        damping: 20
      }
    }
  };

  return (
    <div className="my-8">
      <motion.div 
        className="flex justify-between items-center mb-6"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h2 className="text-2xl font-bold text-foreground">Curated by Billionaire Minds</h2>
        <div className="text-sm font-medium text-primary">
          {isAuthenticated ? `${currentBillionaire}'s Picks` : "Sign up to unlock"}
        </div>
      </motion.div>

      <Carousel className="w-full">
        <CarouselContent>
          {displayedRecommendations.map((book) => (
            <CarouselItem key={book.id} className="sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5">
              <motion.div 
                variants={itemVariants}
                whileHover={isAuthenticated ? { scale: 1.03 } : {}}
                className="p-1"
                onClick={() => isAuthenticated && handleBookClick(book)}
              >
                <Card className={`overflow-hidden bg-card border-primary/10 ${isAuthenticated ? 'hover:border-primary/30 cursor-pointer' : ''} transition-colors shadow-md hover:shadow-lg relative`}>
                  <div className="aspect-[2/3] relative">
                    {loading ? (
                      <Skeleton className="w-full h-full absolute" />
                    ) : (
                      <>
                        <ImageLoader
                          src={book.thumbnail}
                          alt={book.title}
                          className="rounded-t-lg"
                        />
                        {!isAuthenticated && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-t-lg">
                            <Lock className="h-8 w-8 text-white" />
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className={`font-semibold line-clamp-1 ${!isAuthenticated ? 'text-muted-foreground' : ''}`}>
                      {book.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">{book.authors.join(", ")}</p>
                    <div className="mt-2 flex items-center">
                      <span className="text-xs font-semibold bg-primary/10 text-primary px-2 py-1 rounded-full">
                        {book.billionaire}
                      </span>
                    </div>
                    {isAuthenticated ? (
                      <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                        "{book.quote}"
                      </p>
                    ) : (
                      <div className="mt-2 text-center">
                        <p className="text-xs text-muted-foreground mb-2">Sign up to read insights</p>
                        <div className="flex gap-1">
                          <Button size="sm" className="text-xs h-6 px-2 flex-1" asChild>
                            <Link to="/signup">
                              <UserPlus className="h-3 w-3 mr-1" />
                              Sign Up
                            </Link>
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>
        {isAuthenticated && (
          <div className="hidden md:block">
            <CarouselPrevious className="left-0" />
            <CarouselNext className="right-0" />
          </div>
        )}
      </Carousel>
    </div>
  );
};

export default BillionaireRecommendations;
