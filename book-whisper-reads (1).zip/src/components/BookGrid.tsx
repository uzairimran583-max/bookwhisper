
import BookCard from "@/components/BookCard";
import { Book } from "@/services/bookService";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import EmptyState from "./EmptyState";

interface BookGridProps {
  books: Book[];
  loading?: boolean;
  emptyStateType?: "search" | "library" | "recommendations" | "general";
  emptyTitle?: string;
  emptyDescription?: string;
}

const BookGrid = ({ 
  books, 
  loading = false, 
  emptyStateType = "general",
  emptyTitle,
  emptyDescription 
}: BookGridProps) => {
  // Animation variants for the grid items
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring" as const,
        stiffness: 260,
        damping: 20
      }
    }
  };

  if (loading) {
    return (
      <div className="book-grid-modern">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="space-y-3">
            <Skeleton className="skeleton-modern h-56 w-full" />
            <Skeleton className="skeleton-modern h-4 w-full" />
            <Skeleton className="skeleton-modern h-4 w-2/3" />
          </div>
        ))}
      </div>
    );
  }

  if (books.length === 0) {
    return (
      <EmptyState 
        type={emptyStateType}
        title={emptyTitle}
        description={emptyDescription}
      />
    );
  }

  return (
    <motion.div 
      className="book-grid-modern"
      variants={containerVariants}
      initial="hidden"
      animate="show"
    >
      {books.map((book, index) => (
        <motion.div key={book.id} variants={itemVariants} custom={index} className="hover-lift">
          <div className="book-card-modern hover-glow">
            <BookCard book={book} highlightCategory />
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default BookGrid;
