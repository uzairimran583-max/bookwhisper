import React, { useEffect, useState } from "react";
import { audioNarrationService, AudioNarrationState } from "@/services/audioNarrationService";
import { Button } from "@/components/ui/button";
import { Play, Pause, Square, SkipBack, SkipForward, Headphones, Volume2, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface AudiblePlayerProps {
  className?: string;
  variant?: "floating" | "inline";
}

const SPEED_OPTIONS = [0.75, 1.0, 1.25, 1.5, 2.0];

export const AudiblePlayer: React.FC<AudiblePlayerProps> = ({
  className = "",
  variant = "floating",
}) => {
  const [state, setState] = useState<AudioNarrationState>(audioNarrationService.getState());

  useEffect(() => {
    const unsubscribe = audioNarrationService.subscribe((newState) => {
      setState(newState);
    });
    return () => unsubscribe();
  }, []);

  if (!state.isPlaying && !state.isPaused) {
    return null;
  }

  const handleNextSpeed = () => {
    const currentIndex = SPEED_OPTIONS.indexOf(state.rate);
    const nextIndex = (currentIndex + 1) % SPEED_OPTIONS.length;
    audioNarrationService.setRate(SPEED_OPTIONS[nextIndex]);
  };

  const isInline = variant === "inline";

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: isInline ? 0 : 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: isInline ? 0 : 20 }}
        transition={{ duration: 0.2 }}
        className={`z-50 ${
          isInline
            ? "w-full"
            : "fixed bottom-5 left-1/2 -translate-x-1/2 w-[94%] max-w-2xl shadow-2xl"
        } ${className}`}
      >
        <div className="bg-card/95 backdrop-blur-md border border-primary/20 rounded-2xl p-3 sm:p-4 shadow-xl">
          <div className="flex items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="h-8 w-8 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Headphones className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                    Audible Narration
                  </span>
                  {state.isPlaying && !state.isPaused && (
                    <span className="flex items-center gap-0.5">
                      <span className="w-1 h-3 bg-amber-500 rounded-full animate-pulse" />
                      <span className="w-1 h-4 bg-amber-500 rounded-full animate-pulse delay-75" />
                      <span className="w-1 h-2 bg-amber-500 rounded-full animate-pulse delay-150" />
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground truncate font-medium">
                  {state.title || "Reading Book Summary"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <Button
                variant="outline"
                size="sm"
                onClick={handleNextSpeed}
                className="h-7 px-2 text-xs font-bold rounded-lg"
                title="Change playback speed"
              >
                {state.rate}x
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => audioNarrationService.stop()}
                className="h-7 w-7 rounded-lg text-muted-foreground hover:text-foreground"
                title="Stop narration"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Current reading excerpt */}
          {state.currentSentence && (
            <div className="bg-muted/40 rounded-lg p-2 mb-2 text-xs text-foreground/90 leading-relaxed max-h-14 overflow-hidden border border-border/40">
              <span className="text-amber-600 dark:text-amber-400 font-semibold mr-1.5">
                § {state.currentSentenceIndex + 1}/{state.totalSentences}:
              </span>
              "{state.currentSentence}"
            </div>
          )}

          {/* Progress bar */}
          <div className="w-full bg-muted/60 h-1.5 rounded-full overflow-hidden mb-2">
            <div
              className="bg-gradient-to-r from-amber-500 to-primary h-full transition-all duration-300"
              style={{ width: `${state.progressPercent}%` }}
            />
          </div>

          {/* Playback Controls */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {state.currentSentenceIndex + 1} of {state.totalSentences} sentences
            </span>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full"
                onClick={() => audioNarrationService.previousSentence()}
                disabled={state.currentSentenceIndex <= 0}
                title="Previous sentence"
              >
                <SkipBack className="h-4 w-4" />
              </Button>

              <Button
                size="icon"
                className="h-9 w-9 rounded-full bg-amber-500 hover:bg-amber-600 text-white shadow-md"
                onClick={() => audioNarrationService.togglePlayPause()}
                title={state.isPaused ? "Resume" : "Pause"}
              >
                {state.isPaused ? (
                  <Play className="h-4 w-4 fill-current ml-0.5" />
                ) : (
                  <Pause className="h-4 w-4 fill-current" />
                )}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full"
                onClick={() => audioNarrationService.nextSentence()}
                disabled={state.currentSentenceIndex >= state.totalSentences - 1}
                title="Next sentence"
              >
                <SkipForward className="h-4 w-4" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full text-destructive hover:bg-destructive/10"
                onClick={() => audioNarrationService.stop()}
                title="Stop"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
              </Button>
            </div>

            <span className="font-medium text-foreground">{state.progressPercent}%</span>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
