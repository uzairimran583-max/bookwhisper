import React from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Lock, UserPlus, Briefcase, Sparkles, Target, Compass, Flame, ArrowRight, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

interface CollectionItem {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  bookCount: number;
  icon: React.ElementType;
  gradient: string;
  accentColor: string;
  tags: string[];
}

const BookCollections: React.FC = () => {
  const { isAuthenticated, openAuthModal } = useAuth();

  const collections: CollectionItem[] = [
    {
      id: "career",
      title: "Workplace Mastery & Career Strategies",
      subtitle: "High-leverage habits, executive presence, and modern leadership tactics.",
      badge: "Executive Series",
      bookCount: 8,
      icon: Briefcase,
      gradient: "from-blue-500/15 via-indigo-500/10 to-purple-500/10 border-blue-500/30",
      accentColor: "text-blue-500 dark:text-blue-400",
      tags: ["Leadership", "Strategy", "Productivity"]
    },
    {
      id: "effective",
      title: "Habits of Highly Effective Thinkers",
      subtitle: "Mental models, deep work mastery, and focus in a world full of distractions.",
      badge: "High Impact",
      bookCount: 10,
      icon: Target,
      gradient: "from-amber-500/15 via-orange-500/10 to-rose-500/10 border-amber-500/30",
      accentColor: "text-amber-500 dark:text-amber-400",
      tags: ["Deep Work", "Decision Making", "Focus"]
    },
    {
      id: "wealth",
      title: "Wealth Architecture & Psychology",
      subtitle: "Timeless wisdom on money, compound growth, and strategic risk management.",
      badge: "Bestseller Pack",
      bookCount: 7,
      icon: Flame,
      gradient: "from-emerald-500/15 via-teal-500/10 to-cyan-500/10 border-emerald-500/30",
      accentColor: "text-emerald-500 dark:text-emerald-400",
      tags: ["Finance", "Psychology", "Investing"]
    },
    {
      id: "philosophy",
      title: "Stoic Resilience & Inner Calm",
      subtitle: "Classical wisdom and mental frameworks to thrive under high pressure.",
      badge: "Mindset Essentials",
      bookCount: 6,
      icon: Compass,
      gradient: "from-purple-500/15 via-violet-500/10 to-pink-500/10 border-purple-500/30",
      accentColor: "text-purple-500 dark:text-purple-400",
      tags: ["Philosophy", "Mindset", "Wisdom"]
    }
  ];

  return (
    <section className="my-10 relative">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="p-1 rounded-md bg-primary/10 text-primary">
              <Sparkles className="h-4 w-4" />
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-primary">
              Curated Masterclasses
            </span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">Curated Book Collections</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {isAuthenticated
              ? "Hand-picked intelligence stacks tailored for ambitious readers."
              : "Sign in with your Google account to unlock deep curated reading paths."}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {collections.map((col, idx) => {
          const Icon = col.icon;
          return (
            <motion.div
              key={col.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08, duration: 0.35 }}
              whileHover={{ y: -3 }}
              className="relative group"
            >
              <Card
                className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br ${col.gradient} p-6 transition-all duration-300 hover:shadow-xl backdrop-blur-sm`}
              >
                {/* Background decorative mesh circle */}
                <div className="absolute -right-12 -top-12 w-44 h-44 rounded-full bg-primary/5 blur-2xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-background/80 shadow-sm border border-border/50 text-foreground group-hover:text-primary transition-colors">
                      <Icon className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="text-[11px] font-semibold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-background/70 border border-border/60 text-muted-foreground inline-block mb-1">
                        {col.badge}
                      </span>
                      <h3 className="text-lg font-bold text-foreground leading-snug">
                        {col.title}
                      </h3>
                    </div>
                  </div>

                  <span className="text-xs font-medium text-muted-foreground shrink-0 px-2 py-1 rounded-md bg-background/60 border border-border/40">
                    {col.bookCount} Books
                  </span>
                </div>

                <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">
                  {col.subtitle}
                </p>

                {/* Tag Pills */}
                <div className="flex flex-wrap items-center gap-1.5 mb-6">
                  {col.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] px-2 py-0.5 rounded-md bg-background/50 border border-border/40 text-muted-foreground"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Action button / lock overlay */}
                {isAuthenticated ? (
                  <Link
                    to={`/search?q=${encodeURIComponent(col.tags[0])}`}
                    className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary/80 transition-colors group/link"
                  >
                    <span>Explore Collection</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover/link:translate-x-1" />
                  </Link>
                ) : (
                  <div className="pt-2 border-t border-border/40 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Lock className="h-3.5 w-3.5 text-amber-500" />
                      <span>Free Member Access</span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openAuthModal("Sign in with Gmail to unlock curated book collections")}
                      className="text-xs h-8 px-3 font-medium bg-background/70 hover:bg-background"
                    >
                      <UserPlus className="h-3.5 w-3.5 mr-1 text-primary" />
                      Unlock Free
                    </Button>
                  </div>
                )}
              </Card>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};

export default BookCollections;
