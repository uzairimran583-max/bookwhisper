import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Palette, Check } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

interface ThemeOption {
  name: string;
  id: string;
  primary: string;
  accent: string;
  background: string;
  description: string;
  preview: React.ReactNode;
}

const THEME_OPTIONS: ThemeOption[] = [
  {
    name: "Default Purple",
    id: "default",
    primary: "265 85% 58%",
    accent: "213 94% 68%",
    background: "0 0% 100%",
    description: "Modern purple with vibrant blue accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full" style={{background: 'hsl(265 85% 58%)'}}></div><div className="w-4 h-4 rounded-full" style={{background: 'hsl(213 94% 68%)'}}></div></div>
  },
  {
    name: "Midnight Black",
    id: "black",
    primary: "0 0% 12%",
    accent: "0 0% 25%",
    background: "0 0% 3%",
    description: "Ultra dark theme with deep shadows",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-gray-950"></div><div className="w-4 h-4 rounded-full bg-gray-800"></div></div>
  },
  {
    name: "Deep Space",
    id: "space",
    primary: "240 15% 15%",
    accent: "260 20% 25%",
    background: "240 20% 4%",
    description: "Dark space theme with subtle purple hints",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-slate-900"></div><div className="w-4 h-4 rounded-full bg-violet-900"></div></div>
  },
  {
    name: "Ruby Red",
    id: "red",
    primary: "0 84% 60%",
    accent: "15 80% 55%",
    background: "0 0% 100%",
    description: "Bold red with warm orange accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-red-500"></div><div className="w-4 h-4 rounded-full bg-orange-500"></div></div>
  },
  {
    name: "Sunshine Yellow",
    id: "yellow",
    primary: "45 93% 58%",
    accent: "35 91% 65%",
    background: "0 0% 100%",
    description: "Bright yellow with golden accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-yellow-400"></div><div className="w-4 h-4 rounded-full bg-amber-400"></div></div>
  },
  {
    name: "Forest Green",
    id: "green",
    primary: "142 76% 36%",
    accent: "120 60% 50%",
    background: "0 0% 100%",
    description: "Natural green with fresh mint accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-green-600"></div><div className="w-4 h-4 rounded-full bg-emerald-500"></div></div>
  },
  {
    name: "Ocean Blue",
    id: "blue",
    primary: "213 94% 68%",
    accent: "200 98% 58%",
    background: "0 0% 100%",
    description: "Deep blue with cyan accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-blue-500"></div><div className="w-4 h-4 rounded-full bg-cyan-400"></div></div>
  },
  {
    name: "Purple & Red Fusion",
    id: "purple-red",
    primary: "320 85% 58%",
    accent: "0 84% 60%",
    background: "0 0% 100%",
    description: "Vibrant purple mixed with bold red",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-purple-500"></div><div className="w-4 h-4 rounded-full bg-red-500"></div></div>
  },
  {
    name: "Blue & Pink Harmony",
    id: "blue-pink",
    primary: "213 94% 68%",
    accent: "330 85% 70%",
    background: "0 0% 100%",
    description: "Cool blue with soft pink accents",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-blue-500"></div><div className="w-4 h-4 rounded-full bg-pink-400"></div></div>
  },
  {
    name: "Monochrome",
    id: "white-black",
    primary: "0 0% 20%",
    accent: "0 0% 50%",
    background: "0 0% 98%",
    description: "Classic white and black contrast",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-gray-800"></div><div className="w-4 h-4 rounded-full bg-gray-500"></div></div>
  },
  {
    name: "Sunset Gradient",
    id: "gradient",
    primary: "14 91% 60%",
    accent: "280 85% 65%",
    background: "0 0% 100%",
    description: "Beautiful orange to purple gradient",
    preview: <div className="flex space-x-1"><div className="w-4 h-4 rounded-full bg-gradient-to-r from-orange-400 to-purple-500"></div><div className="w-4 h-4 rounded-full bg-gradient-to-r from-purple-500 to-pink-400"></div></div>
  }
];

const ThemeSettings = () => {
  const [currentTheme, setCurrentTheme] = useState<string>("default");

  useEffect(() => {
    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem("app-theme");
    if (savedTheme) {
      setCurrentTheme(savedTheme);
    }
  }, []);

  const applyTheme = (theme: ThemeOption) => {
    const root = document.documentElement;
    
    // Update CSS variables
    root.style.setProperty('--primary', theme.primary);
    root.style.setProperty('--accent', theme.accent);
    root.style.setProperty('--background', theme.background);
    
    // Update related colors based on theme
    if (theme.id === "black" || theme.id === "space") {
      root.style.setProperty('--foreground', '0 0% 98%');
      root.style.setProperty('--card', theme.id === "black" ? '0 0% 5%' : '240 20% 6%');
      root.style.setProperty('--card-foreground', '0 0% 98%');
      root.style.setProperty('--muted', theme.id === "black" ? '0 0% 8%' : '240 15% 8%');
      root.style.setProperty('--muted-foreground', '0 0% 70%');
      root.style.setProperty('--border', theme.id === "black" ? '0 0% 12%' : '240 15% 12%');
      root.style.setProperty('--input', theme.id === "black" ? '0 0% 8%' : '240 20% 8%');
    } else {
      root.style.setProperty('--foreground', '223 84% 5%');
      root.style.setProperty('--card', '0 0% 100%');
      root.style.setProperty('--card-foreground', '223 84% 5%');
      root.style.setProperty('--muted', '220 14% 96%');
      root.style.setProperty('--muted-foreground', '220 9% 46%');
      root.style.setProperty('--border', '220 13% 91%');
    }
    
    // Save theme to localStorage
    localStorage.setItem("app-theme", theme.id);
    setCurrentTheme(theme.id);
    
    toast.success(`Applied ${theme.name} theme successfully!`);
  };

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5" />
          Theme Customization
        </CardTitle>
        <CardDescription>
          Choose from a variety of beautiful color themes to personalize your reading experience
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {THEME_OPTIONS.map((theme, index) => (
            <motion.div
              key={theme.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`
                relative p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 hover:shadow-lg
                ${currentTheme === theme.id ? 'border-primary shadow-lg bg-primary/5' : 'border-border hover:border-primary/30'}
              `}
              onClick={() => applyTheme(theme)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {theme.preview}
                  <div>
                    <h3 className="font-medium flex items-center gap-2">
                      {theme.name}
                      {currentTheme === theme.id && <Check className="h-4 w-4 text-primary" />}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {theme.description}
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Theme Preview */}
              <div className="mt-3 p-3 rounded border border-border/30 bg-card/50">
                <div className="flex items-center justify-between mb-2">
                  <div 
                    className="w-12 h-3 rounded-full" 
                    style={{ background: `hsl(${theme.primary})` }}
                  ></div>
                  <div 
                    className="w-8 h-3 rounded-full" 
                    style={{ background: `hsl(${theme.accent})` }}
                  ></div>
                </div>
                <div 
                  className="w-full h-2 rounded" 
                  style={{ background: `hsl(${theme.background})` }}
                ></div>
              </div>
              
              {currentTheme === theme.id && (
                <Badge variant="secondary" className="absolute top-2 right-2">
                  Active
                </Badge>
              )}
            </motion.div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h4 className="font-medium mb-2">Pro Tips:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Themes are saved automatically and persist across sessions</li>
            <li>• Dark themes work better in low-light environments</li>
            <li>• Gradient themes add a modern, dynamic feel to the interface</li>
            <li>• High contrast themes improve readability for some users</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default ThemeSettings;