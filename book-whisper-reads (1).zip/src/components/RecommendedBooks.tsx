
import { useState, useEffect } from "react";
import { getTrendingBooks } from "@/services/bookService";
import { Book } from "@/services/bookService";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Headphones, Lock, ArrowRight, Sparkles, UserPlus } from "lucide-react";
import ImageLoader from "./ImageLoader";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

// Add framer-motion for animations
const MotionCard = motion(Card);
const MotionLink = motion(Link);

const RecommendedBooks = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const fetchRecommendedBooks = async () => {
      setLoading(true);
      try {
        // Instead of using OpenLibrary, fetch from standard book service
        const allBooks = await getTrendingBooks();
        
        // Select a random subset of books for recommendations
        const randomBooks = [...allBooks].sort(() => 0.5 - Math.random());
        
        // Filter out books with missing data
        const validBooks = randomBooks.filter(book => 
          book.title && 
          book.title.length > 3 && 
          book.authors && 
          book.authors.length > 0 &&
          book.thumbnail // Ensure we have a thumbnail
        );
        
        setBooks(validBooks.slice(0, 2));
        
        if (validBooks.length === 0) {
          console.error("No valid books found in the recommended books response");
          toast.error("Could not load recommended books. Please refresh the page.");
        }
      } catch (error) {
        console.error("Error fetching recommended books:", error);
        toast.error("Failed to load recommended books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendedBooks();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[...Array(2)].map((_, i) => (
          <Card key={i} className="h-64 animate-pulse bg-muted"></Card>
        ))}
      </div>
    );
  }

  // If we couldn't get any books, show a fallback
  if (books.length === 0) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground mb-4">We're preparing personalized recommendations for you.</p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Refresh
        </Button>
      </Card>
    );
  }

  // Select two popular books for the main display
  const selectedBooks = books.slice(0, 2);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {selectedBooks.map((book, index) => (
        <div key={book.id} className="relative">
          {!isAuthenticated && (
            <MotionCard 
              className="h-full overflow-hidden shadow-md border-primary/20 relative group"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex flex-row h-full relative">
                <div className="w-1/3 bg-muted relative overflow-hidden">
                  <ImageLoader
                    src={book.thumbnail}
                    alt={book.title}
                    className="w-full h-full object-cover"
                    fallbackSrc="/placeholder.svg"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <Lock className="h-8 w-8 text-white" />
                  </div>
                </div>
                <div className="w-2/3 p-4 flex flex-col relative">
                  <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">
                    {book.categories?.[0] || "Recommended"}
                  </div>
                  <h3 className="font-bold text-xl line-clamp-2 leading-tight mb-2 text-muted-foreground">{book.title}</h3>
                  <p className="text-base text-muted-foreground mb-1">{book.authors[0]}</p>
                  <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                    Sign up to unlock this book and many more...
                  </p>
                  
                  <div className="flex items-center mt-auto pt-2">
                    <UserPlus className="h-4 w-4 text-primary mr-1" />
                    <span className="text-xs text-primary font-medium">Sign up required</span>
                  </div>

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-background/95 to-transparent flex flex-col justify-end p-4">
                    <p className="text-sm font-medium mb-3 text-center">Sign up to access this book</p>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1" asChild>
                        <Link to="/signup">
                          Sign Up Free
                        </Link>
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1" asChild>
                        <Link to="/login">
                          Sign In
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </MotionCard>
          )}

          {isAuthenticated && (
            <MotionLink 
              to={`/book/${book.id}`} 
              className="block"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <MotionCard 
                className="h-full overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group relative border-primary/10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex flex-row h-full">
                  <div className="w-1/3 bg-muted relative overflow-hidden">
                    <ImageLoader
                      src={book.thumbnail}
                      alt={book.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      fallbackSrc="/placeholder.svg"
                    />
                  </div>
                  <div className="w-2/3 p-4 flex flex-col">
                    <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">
                      {book.categories?.[0] || "Recommended"}
                    </div>
                    <h3 className="font-bold text-xl line-clamp-2 leading-tight mb-2 group-hover:text-primary transition-colors">{book.title}</h3>
                    <p className="text-base text-foreground mb-1">{book.authors[0]}</p>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {book.description 
                        ? book.description.substring(0, 120) + '...' 
                        : 'Discover insights and wisdom in this recommended read.'}
                    </p>
                    
                    <div className="flex items-center mt-auto pt-2 justify-between">
                      <div className="flex items-center">
                        {index === 0 ? (
                          <>
                            <Sparkles className="h-4 w-4 text-primary mr-1" />
                            <span className="text-xs text-muted-foreground">AI summary available</span>
                          </>
                        ) : (
                          <>
                            <Headphones className="h-4 w-4 text-primary mr-1" />
                            <span className="text-xs text-muted-foreground">Audio available</span>
                          </>
                        )}
                      </div>
                      <motion.div 
                        whileHover={{ x: 5 }}
                        transition={{ type: "spring", stiffness: 400, damping: 10 }}
                      >
                        <ArrowRight className="h-4 w-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                      </motion.div>
                    </div>
                  </div>
                </div>
              </MotionCard>
            </MotionLink>
          )}
        </div>
      ))}
    </div>
  );
};

export default RecommendedBooks;
