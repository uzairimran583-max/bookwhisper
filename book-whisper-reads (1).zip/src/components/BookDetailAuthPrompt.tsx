interface BookDetailAuthPromptProps {
  children: React.ReactNode;
  triggerAction: string;
}

// Sign-in has been removed from the app: the action runs directly.
const BookDetailAuthPrompt = ({ children }: BookDetailAuthPromptProps) => <>{children}</>;

export default BookDetailAuthPrompt;
