
import { useState, useEffect } from "react";
import { Book, getTrendingBooks } from "@/services/bookService";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";
import ImageLoader from "@/components/ImageLoader";
import { toast } from "sonner";

const DailyPicksCarousel = () => {
  const [dailyPicks, setDailyPicks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDailyBooks = async () => {
      setLoading(true);
      try {
        // Fetch from Google Books API for fresh daily picks
        const googleBooksUrl = `https://www.googleapis.com/books/v1/volumes?q=subject:bestseller&orderBy=newest&maxResults=10&printType=books&key=${import.meta.env.VITE_GOOGLE_BOOKS_API_KEY || ''}`;
        
        let googleBooks: Book[] = [];
        
        try {
          const response = await fetch(googleBooksUrl);
          if (response.ok) {
            const data = await response.json();
            googleBooks = data.items?.slice(0, 8).map((item: any) => ({
              id: item.id,
              title: item.volumeInfo.title,
              authors: item.volumeInfo.authors || ['Unknown Author'],
              thumbnail: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || '',
              description: item.volumeInfo.description || '',
              pageCount: item.volumeInfo.pageCount || 0,
              publishedDate: item.volumeInfo.publishedDate || '',
              categories: item.volumeInfo.categories || [],
              averageRating: item.volumeInfo.averageRating || 0,
              ratingsCount: item.volumeInfo.ratingsCount || 0
            })) || [];
          }
        } catch (googleError) {
          console.log("Google Books API unavailable, using fallback");
        }
        
        // Fallback to trending books if Google Books fails
        if (googleBooks.length === 0) {
          const trendingBooks = await getTrendingBooks();
          googleBooks = trendingBooks.slice(0, 5);
        }
        
        setDailyPicks(googleBooks);
      } catch (error) {
        console.error("Error fetching daily picks:", error);
        toast.error("Failed to load daily book picks. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchDailyBooks();
  }, []);

  return (
    <div className="my-8">
      <motion.div 
        className="flex justify-between items-center mb-6"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h2 className="text-2xl font-bold text-foreground">Your Personalized Daily Book Fix</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-primary"
          onClick={() => navigate("/library")}
        >
          View All
        </Button>
      </motion.div>

      <Carousel className="w-full">
        <CarouselContent>
          {dailyPicks.map((book) => (
            <CarouselItem key={book.id} className="sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5">
              <motion.div 
                whileHover={{ scale: 1.03 }}
                className="p-1"
                onClick={() => navigate(`/book/${book.id}`)}
              >
                <Card className="overflow-hidden bg-card border-primary/10 hover:border-primary/30 transition-colors cursor-pointer shadow-md hover:shadow-lg">
                  <div className="aspect-[2/3] relative">
                    <ImageLoader
                      src={book.thumbnail || ''}
                      alt={book.title}
                      className="rounded-t-lg"
                    />
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold line-clamp-1">{book.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">{book.authors?.join(", ")}</p>
                  </div>
                </Card>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <div className="hidden md:block">
          <CarouselPrevious className="left-0" />
          <CarouselNext className="right-0" />
        </div>
      </Carousel>
    </div>
  );
};

export default DailyPicksCarousel;
