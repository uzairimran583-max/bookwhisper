
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen } from "lucide-react";

const CallToAction = () => {
  const navigate = useNavigate();

  return (
    <div className="my-12">
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
        <div className="p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h3 className="text-xl font-bold mb-2 flex items-center">
              <BookOpen className="h-5 w-5 text-primary mr-2" />
              Find Your Next Great Book
            </h3>
            <p className="text-muted-foreground">
              Discover new titles, personalized recommendations, and expert reviews
            </p>
          </div>
          <Button 
            size="lg" 
            onClick={() => navigate("/explore")}
            className="bg-primary hover:bg-primary/90"
          >
            Browse Library
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default CallToAction;
