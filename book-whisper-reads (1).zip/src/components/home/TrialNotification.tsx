import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, BookOpen, MessageSquare, Headphones, Brain, Lock, CheckCircle2, UserCheck } from "lucide-react";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

interface TrialNotificationProps {
  showFreemiumStatus?: boolean;
}

const TrialNotification = ({ showFreemiumStatus = false }: TrialNotificationProps) => {
  const navigate = useNavigate();
  const { isAuthenticated, user, openAuthModal } = useAuth();

  return (
    <motion.div
      initial={{ opacity: 0, y: -15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className="mb-8 overflow-hidden bg-gradient-to-r from-primary/10 via-amber-500/5 to-background border-primary/20 shadow-sm rounded-2xl p-4 sm:p-5">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-start gap-3.5">
            <span className="flex h-10 w-10 shrink-0 rounded-xl bg-primary/15 text-primary items-center justify-center shadow-inner">
              {isAuthenticated ? <UserCheck className="h-5 w-5 text-emerald-500" /> : <Lock className="h-5 w-5 text-amber-500" />}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-foreground text-sm sm:text-base">
                  {isAuthenticated
                    ? `Welcome back, ${user?.name || user?.email || "Reader"}! ✨`
                    : "AI Summaries, Deep Analysis & Voice Require Sign-In"}
                </h3>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-primary/20 text-primary">
                  {isAuthenticated ? "Unlocked & Active" : "Sign-In Required"}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1 max-w-xl">
                {isAuthenticated
                  ? "Your account is authenticated. Enjoy unlimited AI book summaries, 5000+ word deep analysis, interactive AI chat, and voice narration."
                  : "AI Book Summaries, Deep Chapter Analysis, AI Literary Chat, and Audible Voice Narration are reserved for members. Sign in or sign up free to unlock instantly!"}
              </p>

              {showFreemiumStatus && (
                <div className="flex flex-wrap gap-3 mt-2.5">
                  <div className="flex items-center text-xs text-muted-foreground">
                    <BookOpen className="h-3.5 w-3.5 mr-1.5 text-primary" />
                    <span>AI Summaries</span>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Brain className="h-3.5 w-3.5 mr-1.5 text-indigo-500" />
                    <span>Deep Analysis</span>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <MessageSquare className="h-3.5 w-3.5 mr-1.5 text-cyan-500" />
                    <span>AI Chat</span>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Headphones className="h-3.5 w-3.5 mr-1.5 text-amber-500" />
                    <span>Voice Narration</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-center shrink-0">
            {isAuthenticated ? (
              <Button
                onClick={() => navigate('/ai-features')}
                className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs rounded-xl shadow-xs"
                size="sm"
              >
                Launch AI Suite →
              </Button>
            ) : (
              <>
                <Button
                  onClick={() => openAuthModal("Sign in or sign up with Gmail to unlock AI features")}
                  className="bg-amber-500 hover:bg-amber-600 text-white text-xs rounded-xl shadow-xs"
                  size="sm"
                >
                  Sign In / Sign Up
                </Button>
                <Link to="/signup">
                  <Button
                    variant="outline"
                    className="text-xs rounded-xl"
                    size="sm"
                  >
                    Create Account
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default TrialNotification;
