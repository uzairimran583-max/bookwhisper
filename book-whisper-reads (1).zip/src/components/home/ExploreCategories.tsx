
import { useState, useEffect } from "react";
import { Book, getBooksByCategory } from "@/services/bookService";
import BookGrid from "@/components/BookGrid";
import CategoryFilter from "@/components/CategoryFilter";
import { toast } from "sonner";

const ExploreCategories = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("All");

  useEffect(() => {
    const fetchBooks = async () => {
      setLoading(true);
      try {
        let fetchedBooks: Book[] = [];
        
        if (selectedCategory === "All") {
          // When refactoring, we can't reuse getTrendingBooks directly 
          // as that would duplicate API calls with the Popular component
          const categories = ["fiction", "business", "self-help", "science"];
          const category = categories[Math.floor(Math.random() * categories.length)];
          fetchedBooks = await getBooksByCategory(category);
        } else {
          fetchedBooks = await getBooksByCategory(selectedCategory);
        }
        
        // Filter out books without thumbnails or with invalid data
        const validBooks = fetchedBooks.filter(book => 
          book.title && 
          book.authors && 
          book.authors.length > 0
        );
        
        setBooks(validBooks);
      } catch (error) {
        console.error("Error fetching books:", error);
        toast.error("Failed to load books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();
  }, [selectedCategory]);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
  };

  return (
    <div className="my-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <h2 className="text-2xl font-bold">Explore Categories</h2>
        <CategoryFilter
          selectedCategory={selectedCategory}
          onSelectCategory={handleCategorySelect}
        />
      </div>
      
      <BookGrid books={books} loading={loading} />
    </div>
  );
};

export default ExploreCategories;
