
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Search, ArrowRight, BookOpen, Loader2, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";
import { searchBooks, Book, getRelativeBooks } from "@/services/bookService";

const SUGGESTED_SEARCHES = [
  "Atomic Habits",
  "Psychology of Money",
  "Deep Work",
  "Zero to One",
  "Sapiens",
  "Steve Jobs"
];

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<Book[]>([]);
  const [relativeResults, setRelativeResults] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const q = searchQuery.trim();
    if (q.length < 2) {
      setResults([]);
      setRelativeResults([]);
      setLoading(false);
      return;
    }

    let isCancelled = false;
    setLoading(true);
    const timeout = setTimeout(async () => {
      try {
        const [found, relative] = await Promise.all([
          searchBooks(q, 5),
          getRelativeBooks(q, 3)
        ]);
        if (!isCancelled) {
          setResults(found);
          const foundIds = new Set(found.map(b => b.id.toLowerCase()));
          setRelativeResults(relative.filter(b => !foundIds.has(b.id.toLowerCase())).slice(0, 3));
        }
      } catch {
        if (!isCancelled) {
          setResults([]);
          setRelativeResults([]);
        }
      } finally {
        if (!isCancelled) setLoading(false);
      }
    }, 250);

    return () => {
      isCancelled = true;
      clearTimeout(timeout);
    };
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setIsOpen(false);
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleSelectQuick = (term: string) => {
    setSearchQuery(term);
    navigate(`/search?q=${encodeURIComponent(term)}`);
  };

  return (
    <div ref={containerRef} className="mx-auto max-w-xl mb-8 relative">
      <form onSubmit={handleSearch}>
        <Card className="relative overflow-hidden bg-card/95 shadow-lg border border-border hover:border-primary/40 transition-all rounded-xl">
          <div className="relative flex items-center px-4 py-3.5">
            <Search className="h-5 w-5 text-muted-foreground mr-3 shrink-0" />
            <Input 
              className="bg-transparent border-none p-0 focus-visible:ring-0 text-base placeholder:text-muted-foreground/70"
              placeholder="Search by title, author, or keyword (e.g. Atomic Habits)..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsOpen(true);
              }}
              onFocus={() => setIsOpen(true)}
            />
            <button
              type="submit"
              className="ml-2 px-3.5 py-1.5 text-xs font-medium text-primary-foreground bg-primary rounded-lg hover:opacity-90 transition-opacity shrink-0 flex items-center gap-1"
            >
              Search
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </Card>
      </form>

      {/* Live autocomplete dropdown */}
      {isOpen && searchQuery.trim().length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover/95 backdrop-blur-md rounded-xl border border-border shadow-2xl p-2 z-50 max-h-80 overflow-y-auto">
          {loading && results.length === 0 ? (
            <div className="flex items-center gap-2 p-3 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <span>Searching books...</span>
            </div>
          ) : results.length > 0 || relativeResults.length > 0 ? (
            <div>
              {results.length > 0 && (
                <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-3 py-1.5">
                  Direct Matches
                </div>
              )}
              {results.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    navigate(`/book/${b.id}`);
                  }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-accent text-left transition-colors"
                >
                  <img
                    src={b.thumbnail || "/placeholder.svg"}
                    alt=""
                    className="w-10 h-14 object-cover rounded shadow-sm shrink-0 bg-muted"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold text-foreground truncate">{b.title}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {b.authors?.join(", ") || "Unknown Author"}
                      {b.categories?.[0] && ` · ${b.categories[0]}`}
                    </div>
                  </div>
                </button>
              ))}

              {relativeResults.length > 0 && (
                <>
                  <div className="text-[11px] font-semibold text-primary uppercase tracking-wider px-3 pt-2.5 pb-1 flex items-center gap-1 border-t border-border/60 mt-1">
                    <Sparkles className="h-3 w-3" />
                    <span>Related Books & Relative Topics</span>
                  </div>
                  {relativeResults.map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => {
                        setIsOpen(false);
                        navigate(`/book/${b.id}`);
                      }}
                      className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-accent text-left transition-colors opacity-95"
                    >
                      <img
                        src={b.thumbnail || "/placeholder.svg"}
                        alt=""
                        className="w-9 h-12 object-cover rounded shadow-sm shrink-0 bg-muted"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-semibold text-foreground truncate">{b.title}</div>
                        <div className="text-[11px] text-muted-foreground truncate">
                          {b.authors?.join(", ") || "Unknown Author"}
                        </div>
                      </div>
                    </button>
                  ))}
                </>
              )}

              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
                }}
                className="w-full text-center text-xs font-medium text-primary p-2 mt-1 hover:bg-accent rounded-lg border-t border-border/50"
              >
                View all results & relative books for "{searchQuery.trim()}"
              </button>
            </div>
          ) : !loading && (
            <div className="p-3 text-sm text-muted-foreground text-center">
              No direct matches found. Press Enter to search all sources.
            </div>
          )}
        </div>
      )}

      {/* Popular quick-pick searches */}
      <div className="flex items-center flex-wrap gap-1.5 mt-3 px-1 text-xs text-muted-foreground">
        <span className="font-medium mr-1 text-foreground/70">Popular:</span>
        {SUGGESTED_SEARCHES.map((term) => (
          <button
            key={term}
            type="button"
            onClick={() => handleSelectQuick(term)}
            className="px-2.5 py-1 rounded-md bg-secondary/80 hover:bg-secondary text-secondary-foreground transition-colors font-medium hover:text-primary"
          >
            {term}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SearchBar;
