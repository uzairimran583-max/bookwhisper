
import { useState, useEffect } from "react";
import { Book, getTrendingBooks } from "@/services/bookService";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";
import ImageLoader from "@/components/ImageLoader";
import { toast } from "sonner";

const PopularPicksCarousel = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPopularBooks = async () => {
      setLoading(true);
      try {
        const trendingBooks = await getTrendingBooks();
        setBooks(trendingBooks);
      } catch (error) {
        console.error("Error fetching popular books:", error);
        toast.error("Failed to load popular books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchPopularBooks();
  }, []);

  return (
    <div className="my-8">
      <motion.div 
        className="flex justify-between items-center mb-6"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h2 className="text-2xl font-bold text-foreground">Popular Picks</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-primary"
          onClick={() => navigate("/explore")}
        >
          View All
        </Button>
      </motion.div>

      <Carousel className="w-full">
        <CarouselContent>
          {books.slice(0, 10).map((book) => (
            <CarouselItem key={book.id} className="sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5">
              <motion.div 
                whileHover={{ scale: 1.03 }}
                className="p-1"
                onClick={() => navigate(`/book/${book.id}`)}
              >
                <Card className="overflow-hidden bg-card border-primary/10 hover:border-primary/30 transition-colors cursor-pointer shadow-md hover:shadow-lg">
                  <div className="aspect-[2/3] relative">
                    <ImageLoader
                      src={book.thumbnail || ''}
                      alt={book.title}
                      className="rounded-t-lg"
                    />
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold line-clamp-1">{book.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">{book.authors?.join(", ")}</p>
                  </div>
                </Card>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <div className="hidden md:block">
          <CarouselPrevious className="left-0" />
          <CarouselNext className="right-0" />
        </div>
      </Carousel>
    </div>
  );
};

export default PopularPicksCarousel;
