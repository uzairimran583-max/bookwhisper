
import { useState, useEffect } from "react";
import { Book, getModernBooks } from "@/services/bookService";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";
import ImageLoader from "@/components/ImageLoader";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

const ModernBooksSection = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchModernBooks = async () => {
      setLoading(true);
      try {
        const modernBooks = await getModernBooks(15);
        setBooks(modernBooks);
      } catch (error) {
        console.error("Error fetching modern books:", error);
        toast.error("Failed to load modern books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchModernBooks();
  }, []);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring" as const, stiffness: 300 }
    }
  };
  
  const handleBookClick = (book: Book) => {
    navigate(`/book/${book.id}`);
  };

  if (loading) {
    return (
      <div className="my-8">
        <motion.h2 
          className="text-3xl font-bold mb-6 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Modern Book Collection
        </motion.h2>
        <motion.div 
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {[...Array(10)].map((_, i) => (
            <motion.div key={i} variants={itemVariants}>
              <Card className="h-64 aspect-[2/3] animate-pulse bg-muted/40"></Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="my-12">
      <motion.h2 
        className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Modern Books Collection
      </motion.h2>
      
      <Carousel className="w-full">
        <CarouselContent>
          {books.map((book) => (
            <CarouselItem key={book.id} className="sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5">
              <motion.div 
                whileHover={{ scale: 1.05, y: -10 }}
                whileTap={{ scale: 0.98 }}
                transition={{ type: "spring" as const, stiffness: 300 }}
                className="p-1 cursor-pointer"
                onClick={() => handleBookClick(book)}
              >
                <Card className="overflow-hidden border-amber-500/10 transition-all duration-300 shadow-md hover:shadow-xl">
                  <div className="aspect-[2/3] relative">
                    <ImageLoader
                      src={book.thumbnail || ''}
                      alt={book.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Card>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <div className="hidden md:block">
          <CarouselPrevious className="left-0" />
          <CarouselNext className="right-0" />
        </div>
      </Carousel>
    </div>
  );
};

export default ModernBooksSection;
