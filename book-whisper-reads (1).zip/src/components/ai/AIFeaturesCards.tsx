
import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";

const AIFeaturesCards: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card className="p-6 hover:border-primary/30 transition-colors">
        <BookOpen className="h-10 w-10 text-primary mb-4" />
        <h3 className="text-lg font-bold mb-2">AI Book Summaries</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Get quick summaries of any book to help you decide what to read next.
          Our AI creates concise overviews of plot, themes, and key insights.
        </p>
        <Button onClick={() => navigate('/search')} variant="outline" className="w-full">
          Find a book to summarize
        </Button>
      </Card>
      
      <Card className="p-6 hover:border-primary/30 transition-colors">
        <Search className="h-10 w-10 text-primary mb-4" />
        <h3 className="text-lg font-bold mb-2">Book Recommendations</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Tell me what you've enjoyed reading, and I'll suggest your next favorite books.
          Get personalized recommendations based on your taste.
        </p>
        <Button onClick={() => navigate('/')} className="w-full">
          Get recommendations
        </Button>
      </Card>
    </div>
  );
};

export default AIFeaturesCards;
