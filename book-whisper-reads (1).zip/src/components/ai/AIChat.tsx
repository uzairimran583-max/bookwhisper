
import React, { FormEvent, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { X, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

interface Message {
  type: 'user' | 'ai';
  text: string;
}

interface AIChatProps {
  messages: Message[];
  isTyping: boolean;
  userInput: string;
  setUserInput: (val: string) => void;
  handleSubmit: (e: FormEvent) => void;
  handleClearChat: () => void;
  hasFreeChat: boolean;
  isAuthenticated: boolean;
}

const messageVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const AIChat: React.FC<AIChatProps> = ({
  messages,
  isTyping,
  userInput,
  setUserInput,
  handleSubmit,
  handleClearChat,
  hasFreeChat,
  isAuthenticated,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom when messages change
  useEffect(() => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  }, [messages]);

  return (
    <div>
      <div className="space-y-4 mb-6 max-h-[60vh] overflow-y-auto p-1">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            initial="hidden"
            animate="visible"
            variants={messageVariants}
            transition={{ duration: 0.3 }}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex gap-3 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
              <Avatar className={`h-8 w-8 ${message.type === 'user' ? 'bg-primary' : 'bg-secondary'}`}>
                <span className="text-xs font-bold">
                  {message.type === 'user' ? 'You' : 'AI'}
                </span>
              </Avatar>
              <div className={`rounded-lg p-3 text-sm whitespace-pre-wrap ${
                message.type === 'user' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted/50 text-foreground'
              }`}>
                {message.text}
              </div>
            </div>
          </motion.div>
        ))}

        {isTyping && (
          <motion.div
            initial="hidden"
            animate="visible"
            variants={messageVariants}
            className="flex justify-start"
          >
            <div className="flex gap-3 max-w-[80%]">
              <Avatar className="h-8 w-8 bg-secondary">
                <span className="text-xs font-bold">AI</span>
              </Avatar>
              <div className="rounded-lg p-4 bg-muted/50">
                <span className="animate-pulse">●</span>
                <span className="animate-pulse ml-1">●</span>
                <span className="animate-pulse ml-1">●</span>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>
      {/* Input form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder={!isAuthenticated 
            ? "Sign in to chat with AI" 
            : hasFreeChat 
              ? "Ask about a book or author..." 
              : "Subscribe to unlock AI chat"}
          className="flex-1"
          disabled={isTyping || (isAuthenticated && !hasFreeChat) || !isAuthenticated}
        />
        <Button 
          type="submit" 
          disabled={isTyping || !userInput.trim() || (isAuthenticated && !hasFreeChat) || !isAuthenticated}
        >
          {isTyping ? (
            <span className="animate-pulse">✨</span>
          ) : (
            <ArrowRight className="h-5 w-5" />
          )}
        </Button>
        <Button 
          type="button" 
          variant="outline" 
          onClick={handleClearChat} 
          disabled={(isAuthenticated && !hasFreeChat) || !isAuthenticated}
        >
          <X className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
};

export default AIChat;
