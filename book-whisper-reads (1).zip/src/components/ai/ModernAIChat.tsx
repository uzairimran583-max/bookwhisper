import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Send,
  Bot,
  User,
  Loader2,
  ImageIcon,
  X,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Lightbulb,
  Target,
  Brain,
  ShieldAlert
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { getAIChatResponse } from "@/services/aiService";
import { toast } from "sonner";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { useAuth } from "@/context/AuthContext";

interface ModernAIChatProps {
  book?: {
    id?: string;
    title: string;
    authors: string[];
    description?: string;
    thumbnail?: string;
  };
}

interface ChatMessage {
  id: string;
  type: "user" | "bot";
  content: string;
  timestamp: Date;
  image?: string;
}

export const ModernAIChat: React.FC<ModernAIChatProps> = ({ book }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const { isAuthenticated, openAuthModal } = useAuth();

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize welcome message when book changes or mounts
  useEffect(() => {
    if (book) {
      const welcomeMessage: ChatMessage = {
        id: crypto.randomUUID(),
        type: "bot",
        content: `👋 Welcome! I am your AI Literary Intelligence partner for **"${book.title}"** by ${book.authors.join(", ")}.\n\nHere are a few high-impact directions we can explore:\n• **Core Mental Models**: The foundational frameworks introduced in the book\n• **Action System**: How to apply these lessons in your daily routine\n• **Critical Analysis**: Flaws, counter-arguments, and edge cases\n• **Visual Analysis**: Upload any page or cover photo for instant breakdown\n\nClick any suggested prompt below or type your question to begin!`,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    } else {
      const generalWelcome: ChatMessage = {
        id: crypto.randomUUID(),
        type: "bot",
        content: `👋 Greetings! I'm your universal BookWhisper AI Assistant. Ask me about any book, author, philosophical concept, or recommendation. You can also upload a book cover or page photo for instant visual analysis!`,
        timestamp: new Date()
      };
      setMessages([generalWelcome]);
    }
  }, [book]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading]);

  // Audio Speech synthesis
  const handleToggleSpeak = (msgId: string, text: string) => {
    if (!isAuthenticated) {
      toast.info("Sign in or sign up to listen to AI Voice Narration.");
      openAuthModal("Sign in or sign up with Gmail to unlock AI Voice Narration");
      return;
    }

    if (!("speechSynthesis" in window)) {
      toast.info("Audio narration is not supported in this browser.");
      return;
    }

    if (speakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown asterisks
    const cleanText = text.replace(/[*_#`]/g, "");
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      setSpeakingMessageId(null);
    };
    utterance.onerror = () => {
      setSpeakingMessageId(null);
    };

    setSpeakingMessageId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopyMessage = (msgId: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(msgId);
    toast.success("Message copied to clipboard!");
    setTimeout(() => {
      setCopiedId(null);
    }, 2000);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setUploadedImage(e.target?.result as string);
          toast.success("Image attached! Ask AI to analyze it.");
        };
        reader.readAsDataURL(file);
      } else {
        toast.error("Please upload an image file");
      }
    }
  };

  const removeUploadedImage = () => {
    setUploadedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    if (!isAuthenticated) {
      toast.info("Sign in or sign up to chat with BookWhisper AI.");
      openAuthModal("Sign in or sign up with Gmail to chat with AI");
      return;
    }

    const query = (textToSend || input).trim();
    if (!query && !uploadedImage) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      type: "user",
      content: query || "Please analyze this book image.",
      timestamp: new Date(),
      image: uploadedImage || undefined
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    const currentImg = uploadedImage;
    setUploadedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setIsLoading(true);

    try {
      let response: string;
      const contextObj = book
        ? { title: book.title, author: book.authors.join(", ") }
        : undefined;

      if (currentImg) {
        response = await getAIChatResponse(userMessage.content, contextObj, currentImg);
      } else {
        response = await getAIChatResponse(userMessage.content, contextObj);
      }

      const botMessage: ChatMessage = {
        id: crypto.randomUUID(),
        type: "bot",
        content: response,
        timestamp: new Date()
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Error in AI chat:", error);
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        type: "bot",
        content: "I encountered a minor connection delay. Please feel free to ask again or try a suggested topic.",
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const promptPresets = [
    { label: "💡 Top 3 Takeaways", prompt: "What are the top 3 most transformative takeaways from this book?" },
    { label: "🧠 Core Mental Models", prompt: "Summarize the core mental models and frameworks explained in this book." },
    { label: "🎯 Immediate Action Plan", prompt: "Create a 7-day actionable implementation plan based on the principles of this book." },
    { label: "⚔️ Devil's Advocate", prompt: "What are the common criticisms, limitations, and counter-arguments against the book's thesis?" },
    { label: "📚 Books to Read Next", prompt: "What are 3 books with complementary or contrasting viewpoints that I should read next?" }
  ];

  return (
    <div className="flex flex-col h-[680px] w-full rounded-2xl overflow-hidden border border-border/70 bg-background/95 backdrop-blur-2xl shadow-2xl relative">
      {/* Top Ambient Cyber Gradient */}
      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-primary via-indigo-500 to-cyan-400" />

      {/* Header */}
      <div className="p-4 px-5 bg-card/80 border-b border-border/60 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="p-2.5 rounded-xl bg-primary/10 border border-primary/20 text-primary">
              <Bot className="h-5 w-5" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-foreground leading-tight">
                {book ? book.title : "BookWhisper AI Intelligence"}
              </h3>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
                Gemini 3.8
              </span>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-1">
              {book ? `by ${book.authors.join(", ")}` : "Contextual literary assistant & image scanner"}
            </p>
          </div>
        </div>

        {/* Book Action buttons if present */}
        {book && (
          <div className="flex items-center gap-2">
            <AmazonBuyButton
              bookTitle={book.title}
              author={book.authors?.[0]}
              bookId={book.id}
              thumbnail={book.thumbnail}
              variant="compact"
              size="sm"
            />
          </div>
        )}
      </div>

      {/* Messages Scroll Area */}
      <ScrollArea className="flex-1 p-5 overflow-y-auto">
        <div className="space-y-5 max-w-4xl mx-auto">
          <AnimatePresence initial={false}>
            {messages.map((message) => {
              const isUser = message.type === "user";
              const isSpeaking = speakingMessageId === message.id;

              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex items-start gap-3 max-w-[88%] sm:max-w-[80%] ${
                      isUser ? "flex-row-reverse" : ""
                    }`}
                  >
                    {/* Avatar */}
                    <div
                      className={`h-8 w-8 rounded-xl shrink-0 flex items-center justify-center shadow-sm text-xs font-bold ${
                        isUser
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted border border-border/60 text-primary"
                      }`}
                    >
                      {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </div>

                    {/* Bubble */}
                    <div className="space-y-1.5 flex flex-col">
                      <div
                        className={`rounded-2xl p-4 shadow-sm text-sm leading-relaxed ${
                          isUser
                            ? "bg-primary text-primary-foreground ml-auto rounded-tr-none"
                            : "bg-card/90 border border-border/70 text-foreground rounded-tl-none shadow-md backdrop-blur-md"
                        }`}
                      >
                        {/* Image Attachment Preview */}
                        {message.image && (
                          <div className="mb-3 rounded-lg overflow-hidden border border-border/40">
                            <img
                              src={message.image}
                              alt="Analyzed preview"
                              className="max-h-52 w-auto object-cover"
                            />
                          </div>
                        )}

                        <div className="whitespace-pre-wrap">{message.content}</div>
                      </div>

                      {/* Footer Actions (Copy, Audio Read-aloud, Time) */}
                      <div
                        className={`flex items-center gap-2 px-1 text-[11px] text-muted-foreground ${
                          isUser ? "justify-end" : "justify-start"
                        }`}
                      >
                        <span>{message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>

                        {!isUser && (
                          <>
                            <button
                              onClick={() => handleToggleSpeak(message.id, message.content)}
                              className={`p-1 rounded hover:bg-muted transition-colors flex items-center gap-1 ${
                                isSpeaking ? "text-primary font-semibold" : ""
                              }`}
                              title={isSpeaking ? "Stop reading" : "Read aloud"}
                            >
                              {isSpeaking ? (
                                <>
                                  <VolumeX className="h-3.5 w-3.5 text-primary" />
                                  {/* Animated Waveform Bars */}
                                  <span className="flex items-end gap-0.5 h-3">
                                    <motion.span
                                      animate={{ height: ["4px", "12px", "4px"] }}
                                      transition={{ repeat: Infinity, duration: 0.6 }}
                                      className="w-0.5 bg-primary rounded-full"
                                    />
                                    <motion.span
                                      animate={{ height: ["12px", "6px", "12px"] }}
                                      transition={{ repeat: Infinity, duration: 0.8 }}
                                      className="w-0.5 bg-primary rounded-full"
                                    />
                                    <motion.span
                                      animate={{ height: ["6px", "14px", "6px"] }}
                                      transition={{ repeat: Infinity, duration: 0.5 }}
                                      className="w-0.5 bg-primary rounded-full"
                                    />
                                  </span>
                                </>
                              ) : (
                                <Volume2 className="h-3.5 w-3.5" />
                              )}
                            </button>

                            <button
                              onClick={() => handleCopyMessage(message.id, message.content)}
                              className="p-1 rounded hover:bg-muted transition-colors"
                              title="Copy response"
                            >
                              {copiedId === message.id ? (
                                <Check className="h-3.5 w-3.5 text-emerald-500" />
                              ) : (
                                <Copy className="h-3.5 w-3.5" />
                              )}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {/* Loading Indicator */}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start items-center gap-3"
            >
              <div className="h-8 w-8 rounded-xl shrink-0 bg-muted border border-border/60 flex items-center justify-center text-primary">
                <Bot className="h-4 w-4" />
              </div>
              <div className="p-3 px-4 rounded-2xl rounded-tl-none bg-card border border-border/60 flex items-center gap-2 text-xs text-muted-foreground shadow-sm">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
                <span>Synthesizing literary analysis...</span>
              </div>
            </motion.div>
          )}

          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Suggested Quick Prompt Chips */}
      <div className="px-4 py-2 border-t border-border/50 bg-background/50 overflow-x-auto">
        <div className="flex items-center gap-2 whitespace-nowrap scrollbar-none">
          <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1 shrink-0">
            <Sparkles className="h-3 w-3 text-primary" /> Prompts:
          </span>
          {promptPresets.map((preset, i) => (
            <motion.button
              key={i}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleSendMessage(preset.prompt)}
              disabled={isLoading}
              className="text-xs px-2.5 py-1 rounded-full bg-card hover:bg-primary/10 hover:text-primary border border-border/60 hover:border-primary/30 transition-all font-medium text-foreground shrink-0 shadow-sm"
            >
              {preset.label}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Image Preview & Input Box */}
      <div className="p-4 bg-card/90 border-t border-border/60">
        {uploadedImage && (
          <div className="mb-3 relative inline-block">
            <div className="relative rounded-lg overflow-hidden border border-primary/40 shadow-md">
              <img
                src={uploadedImage}
                alt="Selected preview"
                className="max-h-24 w-auto object-cover"
              />
            </div>
            <button
              onClick={removeUploadedImage}
              className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-destructive text-white flex items-center justify-center shadow-md hover:bg-destructive/90"
              title="Remove image"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )}

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />

          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0 h-10 w-10 rounded-xl"
            title="Upload book image or photo for AI visual analysis"
          >
            <ImageIcon className="h-4 w-4 text-muted-foreground" />
          </Button>

          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={
              uploadedImage
                ? "Ask anything about this book image..."
                : book
                ? `Ask about "${book.title}"...`
                : "Ask about any book, concepts, or reading advice..."
            }
            disabled={isLoading}
            className="flex-1 h-10 rounded-xl bg-background border-border/80 focus-visible:ring-primary"
          />

          <Button
            type="button"
            onClick={() => handleSendMessage()}
            disabled={isLoading || (!input.trim() && !uploadedImage)}
            className="shrink-0 h-10 px-4 rounded-xl gap-2 font-semibold shadow-md shadow-primary/20"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Send className="h-4 w-4" />
                <span className="hidden sm:inline">Ask AI</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ModernAIChat;
