import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RotateCcw, Zap, Gauge, Sparkles, BookOpen } from "lucide-react";

interface AISpeedReaderProps {
  bookTitle?: string;
  author?: string;
}

export const AISpeedReader: React.FC<AISpeedReaderProps> = ({
  bookTitle = "Atomic Habits",
  author = "James Clear"
}) => {
  const sampleText = `True behavior change is identity change. You might start a habit because of motivation, but the only reason you stick with one is that it becomes part of your identity. Anyone can convince themselves to visit the gym or eat healthy once or twice, but if you don't shift the belief behind the behavior, then it is hard to stick with long-term changes. Improvements are only temporary until they become part of who you are. The goal is not to read a book, the goal is to become a reader. The goal is not to run a marathon, the goal is to become a runner. Every action you take is a vote for the type of person you wish to become. No single instance will transform your beliefs, but as the votes build up, the evidence of your new identity builds up. Small habits make a big difference by giving you the proof you need.`;

  const words = sampleText.split(/\s+/);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [wpm, setWpm] = useState(350);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isPlaying) {
      const intervalMs = Math.round(60000 / wpm);
      timerRef.current = setInterval(() => {
        setCurrentIndex((prev) => {
          if (prev >= words.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, intervalMs);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, wpm, words.length]);

  const currentWord = words[currentIndex] || "";
  const pivotIndex = Math.floor(currentWord.length / 2);
  const leftPart = currentWord.slice(0, pivotIndex);
  const pivotChar = currentWord[pivotIndex] || "";
  const rightPart = currentWord.slice(pivotIndex + 1);

  const progressPercent = Math.round(((currentIndex + 1) / words.length) * 100);

  return (
    <div className="relative rounded-2xl overflow-hidden border border-border/60 bg-gradient-to-b from-card/90 via-card/80 to-background p-6 backdrop-blur-xl shadow-xl">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-border/50">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-amber-500/10 text-amber-500">
              <Zap className="h-4 w-4" />
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-500">
              AI RSVP Kinetic Speed-Reader
            </span>
          </div>
          <h3 className="text-xl font-bold tracking-tight text-foreground">
            {bookTitle} <span className="text-sm font-normal text-muted-foreground">— Rapid Insight Stream</span>
          </h3>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-background/60 border border-border/50 px-3 py-1.5 rounded-full">
            <Gauge className="h-3.5 w-3.5 text-primary" />
            <span className="font-semibold text-foreground">{wpm}</span> WPM
          </div>
        </div>
      </div>

      {/* Main Kinetic Display Box */}
      <div className="relative my-6 py-16 px-6 rounded-2xl border border-primary/30 bg-gradient-to-b from-primary/5 via-background to-background flex flex-col items-center justify-center min-h-[220px] shadow-inner overflow-hidden">
        {/* Reticle Guides */}
        <div className="absolute inset-x-0 top-6 flex justify-center opacity-40">
          <div className="w-8 h-1 rounded-full bg-primary" />
        </div>
        <div className="absolute inset-x-0 bottom-6 flex justify-center opacity-40">
          <div className="w-8 h-1 rounded-full bg-primary" />
        </div>

        {/* Ambient Pulsing Rings */}
        {isPlaying && (
          <motion.div
            animate={{ scale: [1, 1.25, 1], opacity: [0.15, 0.35, 0.15] }}
            transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
            className="absolute w-44 h-44 rounded-full bg-primary/20 blur-xl pointer-events-none"
          />
        )}

        {/* Word Display with Optimal Recognition Point (ORP) */}
        <div className="text-3xl sm:text-5xl font-mono font-bold tracking-tight select-none relative z-10 flex items-center justify-center">
          <span className="text-muted-foreground text-right">{leftPart}</span>
          <span className="text-primary font-black text-4xl sm:text-6xl mx-0.5 px-0.5 border-b-2 border-primary">
            {pivotChar}
          </span>
          <span className="text-foreground text-left">{rightPart}</span>
        </div>

        {/* Word index counter */}
        <div className="absolute bottom-3 right-4 text-xs font-mono text-muted-foreground">
          {currentIndex + 1} / {words.length} ({progressPercent}%)
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-muted/40 h-1.5 rounded-full overflow-hidden mb-6">
        <motion.div
          className="bg-primary h-full rounded-full"
          style={{ width: `${progressPercent}%` }}
          transition={{ duration: 0.1 }}
        />
      </div>

      {/* Controls & WPM Slider */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Playback Buttons */}
        <div className="flex items-center gap-3">
          <Button
            size="lg"
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex-1 sm:flex-initial sm:px-8 font-semibold gap-2 shadow-lg shadow-primary/20"
          >
            {isPlaying ? (
              <>
                <Pause className="h-5 w-5" /> Pause
              </>
            ) : (
              <>
                <Play className="h-5 w-5" /> Start Reading
              </>
            )}
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              setIsPlaying(false);
              setCurrentIndex(0);
            }}
            title="Reset"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        {/* Speed Adjustment Slider */}
        <div className="space-y-2 bg-background/50 border border-border/40 p-3.5 rounded-xl">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground font-medium flex items-center gap-1.5">
              <Gauge className="h-3.5 w-3.5 text-primary" /> Velocity (Words Per Minute)
            </span>
            <span className="font-bold text-primary font-mono">{wpm} WPM</span>
          </div>
          <Slider
            value={[wpm]}
            min={200}
            max={650}
            step={25}
            onValueChange={(val) => setWpm(val[0])}
            className="cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-muted-foreground/70 font-mono">
            <span>200 (Normal)</span>
            <span>350 (Dynamic)</span>
            <span>650 (Speed Demon)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AISpeedReader;
