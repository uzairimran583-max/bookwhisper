import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Brain, Lightbulb, Compass, Zap, Target, CheckCircle2, ChevronRight, Layers } from "lucide-react";

interface NodeData {
  id: string;
  title: string;
  category: "Core Principle" | "Mental Model" | "Action System" | "Strategic Advantage";
  icon: React.ElementType;
  description: string;
  points: string[];
  color: string;
}

interface AIMindMapProps {
  bookTitle?: string;
  author?: string;
}

export const AIMindMapVisualizer: React.FC<AIMindMapProps> = ({
  bookTitle = "Atomic Habits",
  author = "James Clear"
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>("node-1");

  const nodes: NodeData[] = [
    {
      id: "node-1",
      title: "1% Aggregation of Marginal Gains",
      category: "Core Principle",
      icon: Zap,
      description: "Tiny improvements compound over time into massive macroscopic breakthroughs.",
      points: [
        "1% better each day yields a 37x compounding increase over 365 days.",
        "Systemic consistency always outlasts sporadic motivational bursts.",
        "Focus on trajectory rather than immediate snapshot metrics."
      ],
      color: "from-blue-500/20 to-cyan-500/10 border-blue-500/40 text-blue-400"
    },
    {
      id: "node-2",
      title: "Identity-Based Habit Architecture",
      category: "Mental Model",
      icon: Brain,
      description: "True behavior shift happens when actions align with who you believe you are.",
      points: [
        "Shift from outcome goals ('I want to run a marathon') to identity votes ('I am a runner').",
        "Every repeated action is a vote cast for the type of person you wish to become.",
        "Pride in a particular aspect of identity fuels relentless intrinsic motivation."
      ],
      color: "from-purple-500/20 to-pink-500/10 border-purple-500/40 text-purple-400"
    },
    {
      id: "node-3",
      title: "The 4 Laws of Behavioral Velocity",
      category: "Action System",
      icon: Target,
      description: "Cue, Craving, Response, and Reward — engineered to form or destroy habits.",
      points: [
        "Make it Obvious: Prime environment cues and implementation intentions.",
        "Make it Attractive: Bundle temptation with required rituals.",
        "Make it Easy: Optimize friction; adhere to the 2-Minute Rule.",
        "Make it Satisfying: Immediate micro-rewards solidify neural pathways."
      ],
      color: "from-amber-500/20 to-orange-500/10 border-amber-500/40 text-amber-400"
    },
    {
      id: "node-4",
      title: "Environment Over Willpower",
      category: "Strategic Advantage",
      icon: Compass,
      description: "High performers do not have superhuman self-control; they engineer low-friction environments.",
      points: [
        "Discipline is a finite resource; context design operates continuously.",
        "Remove trigger cues for unproductive loops instead of battling urges.",
        "Surround yourself with a tribe where your desired behavior is the default norm."
      ],
      color: "from-emerald-500/20 to-teal-500/10 border-emerald-500/40 text-emerald-400"
    }
  ];

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  return (
    <div className="relative rounded-2xl overflow-hidden border border-border/60 bg-gradient-to-b from-card/80 to-background p-6 backdrop-blur-xl">
      {/* Background Neural Grid Graphic */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="neural-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <circle cx="20" cy="20" r="1.5" fill="currentColor" className="text-primary" />
              <path d="M 0 20 L 40 20 M 20 0 L 20 40" stroke="currentColor" strokeWidth="0.5" className="text-primary/30" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#neural-grid)" />
        </svg>
      </div>

      {/* Header bar */}
      <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-border/50">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wider text-primary">
              AI Mind Matrix & Concept Map
            </span>
          </div>
          <h3 className="text-xl font-bold tracking-tight text-foreground">
            {bookTitle} <span className="text-sm font-normal text-muted-foreground">— by {author}</span>
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary font-medium">
            <Layers className="h-3.5 w-3.5" />
            Interactive Concept Graph
          </span>
        </div>
      </div>

      {/* Visual Motion Graphic Map Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative">
        {/* Left column: Interactive Node Network */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">
            Core Nodes (Click to Inspect)
          </p>
          {nodes.map((node, index) => {
            const Icon = node.icon;
            const isSelected = selectedNode.id === node.id;
            return (
              <motion.button
                key={node.id}
                onClick={() => setSelectedNodeId(node.id)}
                whileHover={{ scale: 1.015, x: 4 }}
                whileTap={{ scale: 0.985 }}
                className={`relative w-full text-left p-4 rounded-xl border transition-all duration-300 flex items-center justify-between ${
                  isSelected
                    ? "bg-primary/15 border-primary shadow-lg shadow-primary/10"
                    : "bg-card/60 hover:bg-card/90 border-border/60 hover:border-border"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2.5 rounded-lg border bg-background/80 ${
                      isSelected ? "text-primary border-primary/40" : "text-muted-foreground border-border/50"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground block">
                      Node 0{index + 1} • {node.category}
                    </span>
                    <h4 className="font-semibold text-sm text-foreground leading-tight">
                      {node.title}
                    </h4>
                  </div>
                </div>

                <div className="shrink-0 flex items-center">
                  <ChevronRight
                    className={`h-4 w-4 transition-transform duration-300 ${
                      isSelected ? "text-primary translate-x-1" : "text-muted-foreground/40"
                    }`}
                  />
                </div>

                {isSelected && (
                  <motion.div
                    layoutId="active-indicator"
                    className="absolute -left-1 top-2 bottom-2 w-1.5 rounded-full bg-primary"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Right column: Deep Node Breakdown & Kinetic Details */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedNode.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="h-full"
            >
              <Card className="h-full p-6 border border-border/70 bg-gradient-to-br from-card via-card/90 to-background shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-semibold px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20">
                      {selectedNode.category}
                    </span>
                    <span className="text-xs text-muted-foreground font-mono">
                      SYNAPSE ID: #{selectedNode.id.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-2">
                    {selectedNode.title}
                  </h3>

                  <p className="text-sm text-muted-foreground leading-relaxed mb-6 pb-4 border-b border-border/50">
                    {selectedNode.description}
                  </p>

                  <h5 className="text-xs font-semibold uppercase tracking-wider text-foreground mb-3 flex items-center gap-1.5">
                    <Lightbulb className="h-4 w-4 text-amber-500" />
                    Key Strategic Takeaways
                  </h5>

                  <div className="space-y-3">
                    {selectedNode.points.map((point, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.08, duration: 0.2 }}
                        className="flex items-start gap-2.5 text-sm p-3 rounded-lg bg-background/60 border border-border/40"
                      >
                        <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                        <span className="text-foreground/90 leading-snug">{point}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Brain className="h-4 w-4 text-primary" />
                    <span>Neural synthesis based on chapter-by-chapter modeling.</span>
                  </div>
                  <span className="text-primary font-medium hover:underline cursor-pointer">
                    Ask AI about this node →
                  </span>
                </div>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default AIMindMapVisualizer;
