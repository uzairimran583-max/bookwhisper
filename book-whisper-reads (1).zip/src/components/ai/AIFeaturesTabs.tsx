
import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Sparkles, UserPlus, Infinity as InfinityIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import AIChat from "./AIChat";
import AIFeaturesCards from "./AIFeaturesCards";

interface Message {
  type: 'user' | 'ai';
  text: string;
}

interface AIFeaturesTabsProps {
  messages: Message[];
  isTyping: boolean;
  userInput: string;
  setUserInput: (val: string) => void;
  handleSubmit: (e: React.FormEvent) => void;
  handleClearChat: () => void;
  hasFreeChat: boolean;
  isAuthenticated: boolean;
}

const AIFeaturesTabs: React.FC<AIFeaturesTabsProps> = (props) => {
  const { messages, isTyping, userInput, setUserInput, handleSubmit, handleClearChat, hasFreeChat, isAuthenticated } = props;

  return (
    <Tabs defaultValue="chat" className="mb-6">
      <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto">
        <TabsTrigger value="chat">Chat with AI</TabsTrigger>
        <TabsTrigger value="features">Features</TabsTrigger>
      </TabsList>
      
      <TabsContent value="chat" className="pt-4">
        <Card className="mb-4 bg-muted/20 p-4 border-2 border-primary/10">
          <div className="flex items-center space-x-2 text-sm mb-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-semibold">Unlimited AI-powered book assistant</span>
          </div>
          {!isAuthenticated ? (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Sign up for free to enjoy unlimited chat about books and get personalized recommendations.
              </p>
              <div className="flex gap-2">
                <Button size="sm" asChild>
                  <Link to="/signup">
                    <UserPlus className="h-4 w-4 mr-1" />
                    Sign Up Free
                  </Link>
                </Button>
                <Button size="sm" variant="outline" asChild>
                  <Link to="/login">
                    Sign In
                  </Link>
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <InfinityIcon className="h-4 w-4 text-primary" />
              <p className="text-sm text-muted-foreground">
                Ask me about any book, author, or for personalized recommendations. Unlimited access for everyone!
              </p>
            </div>
          )}
        </Card>
        <AIChat
          messages={messages}
          isTyping={isTyping}
          userInput={userInput}
          setUserInput={setUserInput}
          handleSubmit={handleSubmit}
          handleClearChat={handleClearChat}
          hasFreeChat={true} // Always true since everything is unlimited
          isAuthenticated={isAuthenticated}
        />
      </TabsContent>
      
      <TabsContent value="features" className="pt-4">
        <AIFeaturesCards />
      </TabsContent>
    </Tabs>
  );
};

export default AIFeaturesTabs;
