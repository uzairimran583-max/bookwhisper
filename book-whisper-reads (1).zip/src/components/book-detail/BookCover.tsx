
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Star, TrendingUp, Award, ImageIcon } from "lucide-react";
import ImageLoader from "@/components/ImageLoader";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";

interface BookCoverProps {
  id?: string;
  title: string;
  author: string;
  coverImage: string;
  rating?: number;
  isTrending?: boolean;
  billionaireRecommendation?: {
    billionaire: string;
    quote: string;
  } | boolean;
  onReadClick?: () => void;
  buttonText?: string;
  showButton?: boolean;
}

const BookCover = ({ 
  id, 
  title, 
  author, 
  coverImage, 
  rating, 
  isTrending, 
  billionaireRecommendation, 
  onReadClick,
  buttonText = "Read Summary",
  showButton = true
}: BookCoverProps) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  
  // Get recommendation details if available
  const hasBillionaireRec = !!billionaireRecommendation;
  const billionaireName = typeof billionaireRecommendation === 'object' ? billionaireRecommendation.billionaire : '';
  const quoteText = typeof billionaireRecommendation === 'object' ? billionaireRecommendation.quote : '';

  return (
    <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
      <CardContent className="p-0">
        <div className="relative">
          <div className="relative aspect-[2/3] overflow-hidden bg-gradient-to-br from-muted to-muted/50">
            <ImageLoader 
              src={coverImage} 
              alt={`Cover of ${title} by ${author}`} 
              className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" 
              onLoad={() => setImageLoaded(true)}
              fallbackSrc="/placeholder.svg"
              animate={true}
            />
            
            {/* Enhanced loading state */}
            {!imageLoaded && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted">
                <ImageIcon className="h-8 w-8 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">Loading cover...</span>
              </div>
            )}
          </div>
          
          {/* Trending Badge */}
          {isTrending && (
            <div className="absolute top-3 right-3">
              <Badge className="bg-orange-500 hover:bg-orange-600 text-white flex items-center gap-1 py-1.5 px-2.5 shadow-md">
                <TrendingUp className="h-3 w-3" />
                <span className="text-xs font-medium">Trending</span>
              </Badge>
            </div>
          )}
          
          {/* Billionaire Recommendation */}
          {hasBillionaireRec && (
            <div className="absolute top-3 left-3">
              <Badge className="bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1 py-1.5 px-2.5 shadow-md">
                <Award className="h-3 w-3" />
                <span className="text-xs font-medium">Billionaire Pick</span>
              </Badge>
            </div>
          )}
          
          {/* Enhanced overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
        
        <div className="p-5">
          <h3 className="text-xl font-bold mb-2 line-clamp-2 group-hover:text-primary transition-colors leading-tight">
            {title}
          </h3>
          <p className="text-sm text-muted-foreground mb-3 font-medium">{author}</p>
          
          {/* Enhanced Rating Display */}
          {rating && (
            <div className="flex items-center mb-4 gap-2">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-4 w-4 ${
                      i < rating 
                        ? 'text-yellow-500 fill-yellow-500' 
                        : 'text-gray-300'
                    }`} 
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground font-medium">
                {rating.toFixed(1)}/5
              </span>
            </div>
          )}
          
          {/* Enhanced Button */}
          {showButton && (id || onReadClick) && (
            <div className="space-y-2">
              <Button 
                className="w-full group-hover:bg-primary/90 transition-all duration-300 font-semibold" 
                size="sm"
                onClick={onReadClick}
              >
                <BookOpen className="mr-2 h-4 w-4" />
                {buttonText}
              </Button>
              <AmazonBuyButton
                bookTitle={title}
                author={author}
                bookId={id}
                thumbnail={coverImage}
                variant="default"
                size="sm"
                className="w-full"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default BookCover;
