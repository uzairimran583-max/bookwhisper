
import React from 'react';
import { Book } from '@/services/bookService';
import { motion, AnimatePresence } from "framer-motion";
import { Star } from "lucide-react";

interface BookSummaryProps {
  book: Book;
}

const BookSummary = ({ book }: BookSummaryProps) => {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key="description"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="space-y-4"
      >
        <p className="text-muted-foreground leading-relaxed">
          {book.description || "No description available for this book."}
        </p>
        
        <div className="pt-4">
          <h3 className="font-medium mb-2">Why you'll love this book:</h3>
          <ul className="space-y-2">
            <motion.li 
              className="flex items-start"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <span className="bg-primary/10 p-1 rounded-full mr-2 mt-0.5">
                <Star className="h-3.5 w-3.5 text-primary" />
              </span>
              <span className="text-sm">Engaging story with compelling characters</span>
            </motion.li>
            <motion.li 
              className="flex items-start"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <span className="bg-primary/10 p-1 rounded-full mr-2 mt-0.5">
                <Star className="h-3.5 w-3.5 text-primary" />
              </span>
              <span className="text-sm">Insightful exploration of key themes</span>
            </motion.li>
            <motion.li 
              className="flex items-start"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <span className="bg-primary/10 p-1 rounded-full mr-2 mt-0.5">
                <Star className="h-3.5 w-3.5 text-primary" />
              </span>
              <span className="text-sm">Well-researched with actionable insights</span>
            </motion.li>
          </ul>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default BookSummary;
