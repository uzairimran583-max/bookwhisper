import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, MessageSquare, Headphones, Clock, BookMarked, ShoppingBag } from "lucide-react";
import { Book } from '@/services/bookService';
import { audioNarrationService } from '@/services/audioNarrationService';
import { toast } from 'sonner';
import { AmazonBuyButton } from '@/components/AmazonBuyButton';
import { AudiblePlayer } from '@/components/audio/AudiblePlayer';
import { useAuth } from '@/context/AuthContext';
import { Lock, Sparkles } from 'lucide-react';

interface BookAIFeaturesProps {
  book: Book;
  summaryUsed: boolean;
  isAudibleAvailable: boolean;
  generatingSummary: boolean;
  handleGenerateSummary: () => Promise<void>;
  handleNavigateToAIChat: () => void;
  handleGenerateComprehensiveSummary?: () => Promise<void>;
}

const BookAIFeatures = ({ 
  book, 
  summaryUsed, 
  isAudibleAvailable, 
  generatingSummary, 
  handleGenerateSummary, 
  handleNavigateToAIChat,
  handleGenerateComprehensiveSummary 
}: BookAIFeaturesProps) => {
  const navigate = useNavigate();
  const { isAuthenticated, openAuthModal } = useAuth();

  const handleSummaryClick = async () => {
    if (!isAuthenticated) {
      toast.info("Please sign in or sign up to read AI book summaries.");
      openAuthModal("Sign in or sign up to read AI book summaries");
      return;
    }
    await handleGenerateSummary();
  };

  const handleChatClick = () => {
    if (!isAuthenticated) {
      toast.info("Please sign in or sign up to chat with AI.");
      openAuthModal("Sign in or sign up to chat with AI");
      return;
    }
    handleNavigateToAIChat();
  };
  
  // Real Audible audio narration playback
  const handleAudioClick = () => {
    if (!isAuthenticated) {
      toast.info("Please sign in or sign up to listen to voice narration.");
      openAuthModal("Sign in or sign up to listen to voice narration");
      return;
    }
    const textToRead = `${book.title} by ${book.authors.join(", ")}. ${book.description || "Executive book summary and core insights."}`;
    audioNarrationService.playText(textToRead, `${book.title} Audio Overview`);
    toast.success("Playing Audible narration...");
  };

  const handleComprehensiveClick = async () => {
    if (!isAuthenticated) {
      toast.info("Please sign in or sign up to access deep analysis.");
      openAuthModal("Sign in or sign up to access deep chapter analysis");
      return;
    }
    if (handleGenerateComprehensiveSummary) {
      await handleGenerateComprehensiveSummary();
    } else {
      toast.info("Generating comprehensive summary...");
    }
  };

  return (
    <>
      <Card className="glass-card overflow-hidden border border-border/80 shadow-md">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Book Actions & AI Features
            </h3>
            <AmazonBuyButton
              bookTitle={book.title}
              author={book.authors?.[0]}
              bookId={book.id}
              thumbnail={book.thumbnail}
              variant="compact"
              size="sm"
            />
          </div>

          {/* Grid Layout for Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* AI Summary */}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-feature-card p-4 rounded-xl border border-border/60 bg-card"
            >
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-3 rounded-full bg-primary/10 text-primary">
                  <BookOpen className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Read Summary</h3>
                  <p className="text-xs text-muted-foreground">Key takeaways in 5 min</p>
                </div>
                <Button 
                  size="sm"
                  onClick={handleSummaryClick}
                  disabled={generatingSummary}
                  className="w-full font-medium"
                >
                  {generatingSummary ? 'Loading...' : 'Read Summary'}
                </Button>
              </div>
            </motion.div>

            {/* AI Chat */}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-feature-card p-4 rounded-xl border border-border/60 bg-card"
            >
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-3 rounded-full bg-primary/10 text-primary">
                  <MessageSquare className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Ask AI Tutor</h3>
                  <p className="text-xs text-muted-foreground">Ask any question on book</p>
                </div>
                <Button 
                  size="sm"
                  variant="outline"
                  onClick={handleChatClick}
                  className="w-full font-medium"
                >
                  Chat Now
                </Button>
              </div>
            </motion.div>

            {/* Audible Audio Summary */}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-feature-card p-4 rounded-xl border border-border/60 bg-card"
            >
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-3 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <Headphones className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Audible Voice</h3>
                  <p className="text-xs text-muted-foreground">Hands-free narration</p>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={handleAudioClick}
                  className="w-full font-medium border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/10"
                >
                  Listen Now
                </Button>
              </div>
            </motion.div>

            {/* Deep Analysis */}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-feature-card p-4 rounded-xl border border-border/60 bg-card"
            >
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-3 rounded-full bg-primary/10 text-primary">
                  <BookMarked className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Deep Analysis</h3>
                  <p className="text-xs text-muted-foreground">In-depth chapter guide</p>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={handleComprehensiveClick} 
                  className="w-full font-medium"
                >
                  Explore Deep
                </Button>
              </div>
            </motion.div>
          </div>
          
          {/* Amazon Affiliate Buy Banner Inside Book Details */}
          <div className="mt-6 pt-4 border-t border-border/40">
            <AmazonBuyButton
              bookTitle={book.title}
              author={book.authors?.[0]}
              bookId={book.id}
              thumbnail={book.thumbnail}
              variant="banner"
            />
          </div>

          {/* Reading Time */}
          <div className="mt-4 pt-3 flex justify-between items-center text-xs text-muted-foreground">
            <div className="flex items-center space-x-1.5">
              <Clock className="h-3.5 w-3.5" />
              <span>Estimated Reading Time:</span>
            </div>
            <span className="font-medium text-foreground">
              {book.pageCount ? `${Math.ceil(book.pageCount / 30)} hours (full) • ~6 mins (summary)` : '~5 mins summary'}
            </span>
          </div>
        </div>
      </Card>

      {/* Floating Audible Narration Player */}
      <AudiblePlayer />
    </>
  );
};

export default BookAIFeatures;
