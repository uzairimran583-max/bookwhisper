
import React from 'react';
import { motion } from "framer-motion";
import { Calendar, BookOpen, Star, Headphones } from "lucide-react";
import { Book } from '@/services/bookService';

interface BookMetadataProps {
  book: Book;
  isAudibleAvailable: boolean;
}

const BookMetadata = ({ book, isAudibleAvailable }: BookMetadataProps) => {
  return (
    <div className="grid grid-cols-2 gap-4 mt-2">
      <div className="flex flex-col items-center p-3 bg-muted/50 rounded-lg">
        <Calendar className="h-5 w-5 text-primary mb-1" />
        <span className="text-xs text-muted-foreground">Published</span>
        <span className="text-sm font-medium">{book?.publishedDate ? book.publishedDate.substring(0, 4) : 'N/A'}</span>
      </div>
      
      <div className="flex flex-col items-center p-3 bg-muted/50 rounded-lg">
        <BookOpen className="h-5 w-5 text-primary mb-1" />
        <span className="text-xs text-muted-foreground">Pages</span>
        <span className="text-sm font-medium">{book?.pageCount || 'N/A'}</span>
      </div>
      
      {book?.averageRating && book.averageRating > 0 && (
        <div className="flex flex-col items-center p-3 bg-muted/50 rounded-lg">
          <Star className="h-5 w-5 text-amber-500 mb-1" />
          <span className="text-xs text-muted-foreground">Rating</span>
          <span className="text-sm font-medium">{book.averageRating.toFixed(1)}/5</span>
        </div>
      )}
      
      <div className="flex flex-col items-center p-3 bg-muted/50 rounded-lg">
        <Headphones className="h-5 w-5 text-primary mb-1" />
        <span className="text-xs text-muted-foreground">Audible</span>
        <span className="text-sm font-medium">
          {isAudibleAvailable ? "Available" : (
            <span className="text-amber-500">Coming Soon</span>
          )}
        </span>
      </div>
    </div>
  );
};

export default BookMetadata;
