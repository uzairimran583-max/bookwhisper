
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Bot, BookOpen, Search, Sparkles } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

const NavigationLinks = () => {
  const location = useLocation();
  const { isAuthenticated } = useAuth();
  
  const navigationItems = [
    { 
      path: "/explore", 
      label: "Explore", 
      icon: Search,
      requireAuth: true 
    },
    { 
      path: "/ai-features", 
      label: "AI Features", 
      icon: Bot,
      requireAuth: true,
      highlight: true 
    },
    { 
      path: "/library", 
      label: "My Library", 
      icon: BookOpen,
      requireAuth: true 
    },
  ];

  const isActive = (path: string) => location.pathname === path;

  if (!isAuthenticated) {
    return null;
  }

  return (
    <nav className="hidden md:flex items-center space-x-1">
      {navigationItems.map((item) => (
        <Link key={item.path} to={item.path}>
          <motion.div
            className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              isActive(item.path)
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            } ${item.highlight ? "ring-1 ring-primary/20" : ""}`}
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
          >
            <div className="flex items-center gap-2">
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
              {item.highlight && (
                <Sparkles className="h-3 w-3 text-primary" />
              )}
            </div>
            
            {isActive(item.path) && (
              <motion.div
                className="absolute -bottom-3 left-1/2 w-1 h-1 bg-primary rounded-full"
                layoutId="activeIndicator"
                initial={false}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                style={{ transform: "translateX(-50%)" }}
              />
            )}
          </motion.div>
        </Link>
      ))}
    </nav>
  );
};

export default NavigationLinks;
