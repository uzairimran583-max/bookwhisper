
import { Link, useLocation } from "react-router-dom";
import { Home, Search, MessageSquare, BookText, User, Bot } from "lucide-react";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

const MobileNavigation = () => {
  const location = useLocation();
  const { isAuthenticated } = useAuth();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navigationItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/explore", icon: Search, label: "Explore" },
    { path: "/ai-features", icon: Bot, label: "AI", highlight: true },
    { path: "/library", icon: BookText, label: "Library" },
    { path: "/profile", icon: User, label: "Profile" }
  ];

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      <motion.div 
        className="md:hidden fixed bottom-0 left-0 right-0 navbar-modern border-t z-50 shadow-xl"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.3 }}
      >
        <div className="grid grid-cols-5 h-16">
          {navigationItems.map((item) => (
            <Link 
              key={item.path}
              to={item.path} 
              className="flex flex-col items-center justify-center text-xs relative"
            >
              <motion.div 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className={`p-2 rounded-lg transition-colors duration-200 ${
                  isActive(item.path) 
                    ? 'text-primary bg-primary/10' 
                    : 'text-muted-foreground hover:text-foreground'
                } ${item.highlight ? 'ring-1 ring-primary/30' : ''}`}
              >
                <item.icon size={20} />
                {isActive(item.path) && (
                  <motion.div 
                    className="absolute -top-1 left-1/2 w-1 h-1 bg-primary rounded-full"
                    layoutId="mobileNavIndicator"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    style={{ translateX: "-50%" }}
                  />
                )}
              </motion.div>
              <span className={`mt-1 ${isActive(item.path) ? 'font-medium text-primary' : ''}`}>
                {item.label}
              </span>
            </Link>
          ))}
        </div>
      </motion.div>
      
      {/* Add space at the bottom to account for the fixed navbar on mobile */}
      <div className="md:hidden h-16"></div>
    </>
  );
};

export default MobileNavigation;
