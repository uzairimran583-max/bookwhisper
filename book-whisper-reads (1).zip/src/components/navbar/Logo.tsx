
import { Link } from "react-router-dom";
import { BookMarked, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const Logo = () => {
  return (
    <motion.div 
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 400, damping: 10 }}
      className="relative"
    >
      <Link to="/" className="flex items-center gap-2">
        <motion.div 
          className="relative flex items-center justify-center"
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <BookMarked className="h-6 w-6 text-primary" />
          <motion.div 
            className="absolute -top-1 -right-1.5"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              type: "spring",
              stiffness: 500,
              damping: 15,
              delay: 0.5
            }}
          >
            <Sparkles className="h-3 w-3 text-amber-400" />
          </motion.div>
        </motion.div>
        <motion.span 
          className="font-serif font-bold text-xl luxury-logo-text"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          BookWhisper
        </motion.span>
      </Link>
    </motion.div>
  );
};

export default Logo;
