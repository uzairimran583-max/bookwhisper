import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Search, X, BookOpen, Loader2, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { searchBooks, Book, getRelativeBooks } from "@/services/bookService";

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [results, setResults] = useState<Book[]>([]);
  const [relativeResults, setRelativeResults] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const q = searchQuery.trim();
    if (q.length < 2) {
      setResults([]);
      setRelativeResults([]);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const [r, rel] = await Promise.all([
          searchBooks(q, 6),
          getRelativeBooks(q, 4)
        ]);
        if (!cancelled) {
          setResults(r);
          const rIds = new Set(r.map(b => b.id.toLowerCase()));
          setRelativeResults(rel.filter(b => !rIds.has(b.id.toLowerCase())).slice(0, 3));
        }
      } catch {
        if (!cancelled) {
          setResults([]);
          setRelativeResults([]);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setIsFocused(false);
      inputRef.current?.blur();
    }
  };

  const openBook = (id: string) => {
    setIsFocused(false);
    inputRef.current?.blur();
    navigate(`/book/${id}`);
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFocused) {
        setIsFocused(false);
        inputRef.current?.blur();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [isFocused]);

  const q = searchQuery.trim();

  return (
    <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-4 relative">
      <div
        className={`relative w-full rounded-md overflow-hidden transition-all duration-300 ${
          isFocused ? "ring-2 ring-primary/50 shadow-lg" : ""
        }`}
      >
        <Search
          className={`absolute left-2.5 top-2.5 h-4 w-4 transition-colors duration-200 ${
            isFocused ? "text-primary" : "text-muted-foreground"
          }`}
        />
        <Input
          ref={inputRef}
          type="search"
          placeholder="Search books, authors, topics..."
          className="pl-9 pr-8 w-full transition-all bg-background/70 backdrop-blur-sm border-primary/10 focus-visible:ring-0 focus-visible:border-primary/30"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 150)}
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => {
              setSearchQuery("");
              inputRef.current?.focus();
            }}
            className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <AnimatePresence>
        {isFocused && (
          <motion.div
            className="absolute top-12 left-0 right-0 bg-popover shadow-xl rounded-lg border border-border p-1 z-50 max-h-[70vh] overflow-y-auto"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {q.length < 2 ? (
              <div className="text-xs text-muted-foreground p-2 flex items-center gap-2">
                <BookOpen className="h-3 w-3" />
                <span>Type a book name, author or topic</span>
              </div>
            ) : loading && results.length === 0 ? (
              <div className="text-xs text-muted-foreground p-3 flex items-center gap-2">
                <Loader2 className="h-3 w-3 animate-spin" /> Searching...
              </div>
            ) : results.length === 0 && relativeResults.length === 0 ? (
              <div className="text-xs text-muted-foreground p-3">No matching books found</div>
            ) : (
              <>
                {results.length > 0 && (
                  <div className="px-2 pt-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Direct Matches
                  </div>
                )}
                {results.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => openBook(b.id)}
                    className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-accent text-left transition-colors"
                  >
                    <div className="h-14 w-10 shrink-0 rounded bg-muted overflow-hidden">
                      {b.thumbnail && (
                        <img src={b.thumbnail} alt="" className="h-full w-full object-cover" loading="lazy" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">{b.title}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {b.authors?.join(", ") || "Unknown author"}
                      </div>
                    </div>
                  </button>
                ))}

                {relativeResults.length > 0 && (
                  <>
                    <div className="px-2 pt-2 pb-1 text-[10px] font-semibold uppercase tracking-wider text-primary flex items-center gap-1 border-t border-border/60 mt-1">
                      <Sparkles className="h-3 w-3" />
                      <span>Related & Suggested</span>
                    </div>
                    {relativeResults.map((b) => (
                      <button
                        key={b.id}
                        type="button"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => openBook(b.id)}
                        className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-accent text-left transition-colors opacity-95"
                      >
                        <div className="h-12 w-9 shrink-0 rounded bg-muted overflow-hidden">
                          {b.thumbnail && (
                            <img src={b.thumbnail} alt="" className="h-full w-full object-cover" loading="lazy" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-foreground truncate">{b.title}</div>
                          <div className="text-[11px] text-muted-foreground truncate">
                            {b.authors?.join(", ") || "Unknown author"}
                          </div>
                        </div>
                      </button>
                    ))}
                  </>
                )}

                <button
                  type="submit"
                  onMouseDown={(e) => e.preventDefault()}
                  className="w-full text-center text-xs font-medium text-primary p-2 hover:bg-accent rounded-md border-t border-border/50 mt-1"
                >
                  See all results & relative books for "{q}"
                </button>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </form>
  );
};

export default SearchBar;
