import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/context/AuthContext";
import { BookOpen, User, Settings, LogOut, LogIn, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const UserMenu = () => {
  const { isAuthenticated, user, signOut, openAuthModal } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [initials, setInitials] = useState("U");
  const navigate = useNavigate();

  useEffect(() => {
    if (user && user.email) {
      const email = user.email;
      const emailName = email.split("@")[0];
      if (emailName.length > 0) {
        setInitials(emailName[0].toUpperCase());
      }
    }
  }, [user]);

  const handleLogout = async () => {
    try {
      await signOut();
      setIsMenuOpen(false);
      navigate("/");
    } catch (error) {
      console.error("Error logging out:", error);
      toast.error("Failed to log out");
    }
  };

  if (!isAuthenticated) {
    return (
      <Button
        variant="default"
        size="sm"
        onClick={() => openAuthModal("Sign in with your Gmail to unlock book purchasing & library storage")}
        className="text-xs font-semibold h-8 px-3 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-sm flex items-center gap-1.5"
      >
        <LogIn className="h-3.5 w-3.5" />
        <span>Sign In</span>
      </Button>
    );
  }

  return (
    <DropdownMenu open={isMenuOpen} onOpenChange={setIsMenuOpen}>
      <DropdownMenuTrigger asChild>
        <motion.button
          className="relative rounded-full outline-none ring-offset-background transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          aria-label="User profile menu"
        >
          <Avatar className="h-8 w-8 border border-primary/20 hover:border-primary/40 transition-colors">
            <AvatarImage
              src={user?.user_metadata?.avatar_url || ""}
              alt={user?.email || "User"}
            />
            <AvatarFallback className="bg-primary/10 text-primary font-bold text-xs">
              {initials}
            </AvatarFallback>
          </Avatar>
        </motion.button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-semibold leading-none truncate text-foreground">
              {user?.name || user?.email?.split("@")[0] || "Authenticated Reader"}
            </p>
            <p className="text-xs leading-none text-muted-foreground truncate">
              {user?.email || ""}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/library" className="flex items-center cursor-pointer">
            <BookOpen className="mr-2 h-4 w-4" />
            <span>My Library</span>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/profile" className="flex items-center cursor-pointer">
            <User className="mr-2 h-4 w-4" />
            <span>Profile</span>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/settings" className="flex items-center cursor-pointer">
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={handleLogout}
          className="text-destructive focus:text-destructive cursor-pointer"
        >
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserMenu;
