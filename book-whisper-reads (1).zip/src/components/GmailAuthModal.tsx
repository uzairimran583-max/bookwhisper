import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, Mail, Sparkles, CheckCircle2, ShoppingBag } from "lucide-react";
import { toast } from "sonner";

export const GmailAuthModal: React.FC = () => {
  const { isAuthModalOpen, authModalReason, closeAuthModal, signInWithGmail } = useAuth();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast.error("Please enter your Gmail address");
      return;
    }

    setLoading(true);
    try {
      await signInWithGmail(email.trim());
      setEmail("");
    } catch (err: any) {
      toast.error(err.message || "Failed to authenticate");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = async (suggestedEmail: string) => {
    setLoading(true);
    try {
      await signInWithGmail(suggestedEmail);
      setEmail("");
    } catch (err: any) {
      toast.error(err.message || "Failed to authenticate");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isAuthModalOpen} onOpenChange={(open) => !open && closeAuthModal()}>
      <DialogContent className="sm:max-w-md p-6 bg-card border border-border shadow-2xl rounded-2xl">
        <DialogHeader className="text-center sm:text-center space-y-2">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-1 shadow-inner">
            <Lock className="h-6 w-6" />
          </div>
          <DialogTitle className="text-xl font-bold tracking-tight">
            Unlock Book Purchasing & Saved Library
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            {authModalReason || "Enter your Gmail to unlock verified purchase links and sync your saved library."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 my-2">
          {/* Perks list */}
          <div className="bg-muted/40 rounded-xl p-3 text-xs space-y-2 border border-border/50">
            <div className="flex items-center gap-2 text-foreground font-medium">
              <ShoppingBag className="h-3.5 w-3.5 text-amber-500 shrink-0" />
              <span>Unlock direct book buying deals</span>
            </div>
            <div className="flex items-center gap-2 text-foreground font-medium">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
              <span>Personal bookshelf storage across all your devices</span>
            </div>
            <div className="flex items-center gap-2 text-foreground font-medium">
              <Sparkles className="h-3.5 w-3.5 text-primary shrink-0" />
              <span>Unlimited Audible voice summaries & reading progress</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="gmail-input" className="text-xs font-semibold">
                Your Gmail / Email Address
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="gmail-input"
                  type="email"
                  placeholder="e.g. yourname@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-9 h-11 text-sm bg-background"
                  autoFocus
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-md transition-all"
            >
              {loading ? "Authenticating..." : "Continue with Gmail ➔"}
            </Button>
          </form>

          {/* Quick 1-click option */}
          <div className="pt-2 border-t border-border/50 text-center">
            <span className="text-[11px] text-muted-foreground block mb-2">
              Or quick 1-click sign-in:
            </span>
            <div className="flex flex-wrap gap-2 justify-center">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleQuickDemo("reader@gmail.com")}
                className="text-xs h-8"
              >
                reader@gmail.com
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleQuickDemo("imranuzair014@gmail.com")}
                className="text-xs h-8"
              >
                imranuzair014@gmail.com
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
export default GmailAuthModal;
