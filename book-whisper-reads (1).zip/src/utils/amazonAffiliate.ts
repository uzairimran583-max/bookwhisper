/**
 * Amazon Affiliate Utility
 * Generates exact Amazon product and department links with the affiliate tracking tag.
 */

export const AMAZON_ASSOCIATE_TAG = "bookwise0f3-20";
export const AMAZON_FALLBACK_LINK = "https://amzn.to/4AZqSWv";

// Direct Amazon ASINs (10-character identifiers) for curated & popular books
const KNOWN_BOOK_ASINS: Record<string, string> = {
  // By Book ID
  "atomic-habits": "0735211299",
  "psychology-of-money": "0857197681",
  "deep-work": "1455586692",
  "zero-to-one": "0804139296",
  "billionaire-1": "0804139296",
  "sapiens": "0062316095",
  "thinking-fast-and-slow": "0374533555",
  "principles-life-work": "1501124021",
  "intelligent-investor": "0060555661",
  "billionaire-4": "0060555661",
  "almanack-naval-ravikant": "1544514212",
  "steve-jobs": "1451648537",
  "factfulness": "1250107814",
  "creativity-inc": "0812993012",
  "the-lean-startup": "0307887898",
  "man-search-for-meaning": "080701429X",
  "good-to-great": "0066620996",
  "meditations-marcus-aurelius": "0812968255",
  "billionaire-2": "0199678111", // Superintelligence
  "billionaire-3": "0553293354", // The Foundation Trilogy
  "billionaire-5": "1497644895", // Business Adventures
  "billionaire-6": "1422162672", // The Outsiders
  "billionaire-7": "1544514212", // Naval Almanack
  "billionaire-8": "0062316095", // Sapiens
  "billionaire-9": "0061452056", // The Rational Optimist
  "billionaire-10": "0525427570", // Enlightenment Now
  "billionaire-11": "1250107814", // Factfulness
  "billionaire-12": "0143122010", // The Better Angels of Our Nature
  "billionaire-13": "0812993012", // Creativity, Inc.
  "billionaire-14": "0226458083", // The Structure of Scientific Revolutions
  "billionaire-15": "1455504211", // Dealing with China
};

// Normalized title lookup for quick exact ASIN matching
const TITLE_ASIN_MAP: Record<string, string> = {
  "atomic habits": "0735211299",
  "the psychology of money": "0857197681",
  "psychology of money": "0857197681",
  "deep work": "1455586692",
  "zero to one": "0804139296",
  "sapiens": "0062316095",
  "sapiens: a brief history of humankind": "0062316095",
  "thinking, fast and slow": "0374533555",
  "thinking fast and slow": "0374533555",
  "principles: life and work": "1501124021",
  "principles": "1501124021",
  "the intelligent investor": "0060555661",
  "intelligent investor": "0060555661",
  "the almanack of naval ravikant": "1544514212",
  "almanack of naval ravikant": "1544514212",
  "steve jobs": "1451648537",
  "factfulness": "1250107814",
  "creativity, inc.": "0812993012",
  "creativity inc": "0812993012",
  "the lean startup": "0307887898",
  "lean startup": "0307887898",
  "man's search for meaning": "080701429X",
  "mans search for meaning": "080701429X",
  "good to great": "0066620996",
  "meditations": "0812968255",
  "superintelligence": "0199678111",
  "the foundation trilogy": "0553293354",
  "foundation": "0553293354",
  "business adventures": "1497644895",
  "the outsiders": "1422162672",
  "the rational optimist": "0061452056",
  "rational optimist": "0061452056",
  "enlightenment now": "0525427570",
  "the better angels of our nature": "0143122010",
  "better angels of our nature": "0143122010",
  "the structure of scientific revolutions": "0226458083",
  "structure of scientific revolutions": "0226458083",
  "dealing with china": "1455504211",
  "rich dad poor dad": "1612680194",
  "the 7 habits of highly effective people": "1982137274",
  "7 habits of highly effective people": "1982137274",
  "start with why": "1591846447",
  "essentialism": "0804137382",
  "grit": "1501111116",
  "can't hurt me": "1544512287",
  "the subtle art of not giving a f*ck": "0062457713",
  "think and grow rich": "1585424331",
  "how to win friends and influence people": "0671027034",
};

/**
 * Converts a 13-digit ISBN (starting with 978) into a 10-digit ISBN/ASIN
 */
function isbn13ToIsbn10(isbn13: string): string | null {
  const clean = isbn13.replace(/[^0-9]/g, "");
  if (clean.length !== 13 || !clean.startsWith("978")) {
    return null;
  }
  const core = clean.substring(3, 12);
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(core[i], 10) * (10 - i);
  }
  const remainder = (11 - (sum % 11)) % 11;
  const check = remainder === 10 ? "X" : remainder.toString();
  return core + check;
}

/**
 * Extracts ISBN from cover thumbnail URL if present
 */
function extractIsbnFromThumbnail(thumbnail?: string): string | null {
  if (!thumbnail) return null;
  const match = thumbnail.match(/isbn\/([0-9Xx]{10,13})/i);
  if (match && match[1]) {
    const raw = match[1];
    if (raw.length === 10) return raw.toUpperCase();
    if (raw.length === 13) {
      const conv = isbn13ToIsbn10(raw);
      return conv || raw;
    }
  }
  return null;
}

export interface AmazonBookUrlOptions {
  title?: string;
  author?: string;
  bookId?: string;
  isbn?: string;
  thumbnail?: string;
}

/**
 * Generates the exact Amazon purchase URL with affiliate tracking:
 * 1. If exact ASIN is matched: lands directly on the book's product detail page (/dp/ASIN?tag=...)
 * 2. If thumbnail/isbn has 10-digit ISBN: lands directly on /dp/ISBN?tag=...
 * 3. Otherwise: opens Amazon Books search (/s?k=Title+Author&i=stripbooks&tag=...) for exact book match in Books department
 * 4. Fallback: returns user's primary affiliate link
 */
export function getAmazonBookUrl(options: AmazonBookUrlOptions = {}): string {
  const { title, author, bookId, isbn, thumbnail } = options;

  // 1. Check direct bookId mapping
  if (bookId && KNOWN_BOOK_ASINS[bookId.toLowerCase()]) {
    const asin = KNOWN_BOOK_ASINS[bookId.toLowerCase()];
    return `https://www.amazon.com/dp/${asin}?tag=${AMAZON_ASSOCIATE_TAG}`;
  }

  // 2. Check title mapping
  if (title) {
    const cleanTitle = title.toLowerCase().trim().replace(/['"“”]/g, "");
    if (TITLE_ASIN_MAP[cleanTitle]) {
      const asin = TITLE_ASIN_MAP[cleanTitle];
      return `https://www.amazon.com/dp/${asin}?tag=${AMAZON_ASSOCIATE_TAG}`;
    }
    // Check partial prefix (e.g., "Sapiens" matching "Sapiens: A Brief History...")
    for (const [key, asin] of Object.entries(TITLE_ASIN_MAP)) {
      if (cleanTitle.startsWith(key) || key.startsWith(cleanTitle)) {
        return `https://www.amazon.com/dp/${asin}?tag=${AMAZON_ASSOCIATE_TAG}`;
      }
    }
  }

  // 3. Check explicit ISBN or thumbnail ISBN
  const foundIsbn = isbn || extractIsbnFromThumbnail(thumbnail);
  if (foundIsbn) {
    const clean = foundIsbn.replace(/[^0-9Xx]/g, "");
    if (clean.length === 10) {
      return `https://www.amazon.com/dp/${clean}?tag=${AMAZON_ASSOCIATE_TAG}`;
    }
    const converted = isbn13ToIsbn10(clean);
    if (converted) {
      return `https://www.amazon.com/dp/${converted}?tag=${AMAZON_ASSOCIATE_TAG}`;
    }
  }

  // 4. Construct exact Amazon Books search query
  if (title) {
    // Strip trailing subtitles if very long to optimize Amazon search precision
    let queryTitle = title.split(":")[0].trim();
    if (queryTitle.length < 5 && title.includes(":")) {
      queryTitle = title;
    }
    const cleanAuthor = author ? author.replace(/by\s+/i, "").trim() : "";
    const fullQuery = cleanAuthor ? `${queryTitle} ${cleanAuthor}` : queryTitle;

    return `https://www.amazon.com/s?k=${encodeURIComponent(fullQuery)}&i=stripbooks&tag=${AMAZON_ASSOCIATE_TAG}`;
  }

  // 5. Ultimate fallback
  return AMAZON_FALLBACK_LINK;
}

/**
 * Reliably opens the exact Amazon book purchase link in a new browser tab
 */
export function openAmazonBook(options: AmazonBookUrlOptions = {}): void {
  const url = getAmazonBookUrl(options);

  try {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    document.body.appendChild(anchor);
    anchor.click();
    setTimeout(() => {
      if (document.body.contains(anchor)) {
        document.body.removeChild(anchor);
      }
    }, 150);
  } catch (err) {
    try {
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (e) {
      window.location.href = url;
    }
  }
}
