import { useEffect } from "react";
import ModernBooksSection from "@/components/home/ModernBooksSection";
import PopularPicksCarousel from "@/components/home/PopularPicksCarousel";
import BillionaireRecommendations from "@/components/BillionaireRecommendations";
import BookCollections from "@/components/BookCollections";
import TrialNotification from "@/components/home/TrialNotification";
import { useIsMobile } from "@/hooks/use-mobile";
import MobileBookRecommendations from "@/components/MobileBookRecommendations";
import { motion } from "framer-motion";

const HomePage = () => {
  const isMobile = useIsMobile();
  
  useEffect(() => {
    sessionStorage.setItem('lastRoute', '/');
    sessionStorage.setItem('lastValidRoute', '/');
    sessionStorage.removeItem('billionaireBook');
  }, []);

  // For mobile users, show specialized mobile interface
  if (isMobile) {
    return <MobileBookRecommendations />;
  }

  // Desktop rich view
  return (
    <motion.div 
      className="container py-6 space-y-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <TrialNotification showFreemiumStatus={true} />
      <ModernBooksSection />
      <BillionaireRecommendations />
      <BookCollections />
      <PopularPicksCarousel />
    </motion.div>
  );
};

export default HomePage;
