
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BookOpenText, CalendarDays, Plus, Edit, Trash2, Save, ArrowLeft, Search } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  date: Date;
  lastModified: Date;
}

const DiaryPage = () => {
  const [entries, setEntries] = useState<DiaryEntry[]>(() => {
    const savedEntries = localStorage.getItem("diary_entries");
    return savedEntries ? JSON.parse(savedEntries) : [];
  });
  const [activeEntry, setActiveEntry] = useState<DiaryEntry | null>(null);
  const [newEntry, setNewEntry] = useState<Partial<DiaryEntry>>({
    title: "",
    content: ""
  });
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    // Save entries to localStorage whenever they change
    localStorage.setItem("diary_entries", JSON.stringify(entries));
  }, [entries]);

  // If no entries exist, create a sample entry
  useEffect(() => {
    if (entries.length === 0) {
      const sampleEntry: DiaryEntry = {
        id: generateId(),
        title: "My First Reading Journal",
        content: "Today I started reading 'Atomic Habits' by James Clear. The book begins by explaining how small habits can lead to remarkable results over time. I'm excited to apply some of these principles to my own reading habits!",
        date: new Date(),
        lastModified: new Date()
      };
      setEntries([sampleEntry]);
      setActiveEntry(sampleEntry);
    } else if (!activeEntry && entries.length > 0) {
      // Set the most recent entry as active
      setActiveEntry(entries[0]);
    }
  }, [activeEntry, entries]);

  const generateId = () => {
    return Math.random().toString(36).substring(2, 15);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleCreateEntry = () => {
    if (!newEntry.title?.trim()) {
      toast.error("Please enter a title for your diary entry");
      return;
    }

    const entry: DiaryEntry = {
      id: generateId(),
      title: newEntry.title,
      content: newEntry.content || "",
      date: new Date(),
      lastModified: new Date()
    };

    setEntries([entry, ...entries]);
    setActiveEntry(entry);
    setNewEntry({ title: "", content: "" });
    setIsEditing(false);
    toast.success("New diary entry created!");
  };

  const handleUpdateEntry = () => {
    if (!activeEntry) return;

    const updatedEntries = entries.map(entry => 
      entry.id === activeEntry.id 
        ? { ...activeEntry, lastModified: new Date() } 
        : entry
    );

    setEntries(updatedEntries);
    setIsEditing(false);
    toast.success("Diary entry updated!");
  };

  const handleDeleteEntry = (id: string) => {
    const filteredEntries = entries.filter(entry => entry.id !== id);
    setEntries(filteredEntries);
    
    if (activeEntry?.id === id) {
      setActiveEntry(filteredEntries[0] || null);
    }
    
    toast.success("Diary entry deleted");
  };

  const filteredEntries = entries.filter(entry => 
    entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container py-6 animate-fade-in">
      <div className="flex items-center gap-2 mb-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(-1)}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <BookOpenText className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">Reading Diary</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">My Entries</CardTitle>
                <Button size="sm" variant="outline" onClick={() => {
                  setActiveEntry(null);
                  setIsEditing(true);
                }}>
                  <Plus className="h-4 w-4 mr-2" />
                  New
                </Button>
              </div>
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search entries..." 
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                {filteredEntries.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    No entries found.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredEntries.map(entry => (
                      <Card 
                        key={entry.id}
                        className={`cursor-pointer transition-all hover:bg-muted/50 ${
                          activeEntry?.id === entry.id ? 'border-primary bg-primary/5' : ''
                        }`}
                        onClick={() => {
                          setActiveEntry(entry);
                          setIsEditing(false);
                        }}
                      >
                        <CardContent className="p-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium line-clamp-1">{entry.title}</h3>
                              <p className="text-xs text-muted-foreground flex items-center">
                                <CalendarDays className="h-3 w-3 mr-1" />
                                {formatDate(new Date(entry.date))}
                              </p>
                            </div>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={(e) => e.stopPropagation()} 
                                  className="h-7 w-7"
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete diary entry?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the diary entry from your device.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={() => handleDeleteEntry(entry.id)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                          <p className="text-sm mt-2 line-clamp-2">
                            {entry.content}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-2">
          {isEditing ? (
            <Card>
              <CardHeader>
                <CardTitle>
                  {activeEntry ? "Edit Entry" : "New Entry"}
                </CardTitle>
                <CardDescription>
                  Record your thoughts about what you're reading
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title" 
                    placeholder="Entry title..."
                    value={activeEntry ? activeEntry.title : newEntry.title}
                    onChange={(e) => {
                      if (activeEntry) {
                        setActiveEntry({ ...activeEntry, title: e.target.value });
                      } else {
                        setNewEntry({ ...newEntry, title: e.target.value });
                      }
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea 
                    id="content" 
                    placeholder="Write your thoughts about your reading here..."
                    className="min-h-[300px]"
                    value={activeEntry ? activeEntry.content : newEntry.content}
                    onChange={(e) => {
                      if (activeEntry) {
                        setActiveEntry({ ...activeEntry, content: e.target.value });
                      } else {
                        setNewEntry({ ...newEntry, content: e.target.value });
                      }
                    }}
                  />
                </div>
              </CardContent>
              <CardFooter className="justify-between border-t pt-6">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsEditing(false);
                    if (!activeEntry) {
                      setNewEntry({ title: "", content: "" });
                    }
                  }}
                >
                  Cancel
                </Button>
                <Button onClick={activeEntry ? handleUpdateEntry : handleCreateEntry}>
                  <Save className="h-4 w-4 mr-2" />
                  {activeEntry ? "Update" : "Save"}
                </Button>
              </CardFooter>
            </Card>
          ) : activeEntry ? (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{activeEntry.title}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <CalendarDays className="h-4 w-4 mr-1" />
                      {formatDate(new Date(activeEntry.date))}
                      {activeEntry.lastModified && activeEntry.lastModified !== activeEntry.date && (
                        <span className="ml-2 text-xs">
                          (Edited: {formatDate(new Date(activeEntry.lastModified))})
                        </span>
                      )}
                    </CardDescription>
                  </div>
                  <Button 
                    size="sm"
                    onClick={() => setIsEditing(true)}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm dark:prose-invert max-w-none mt-4">
                  <p className="whitespace-pre-line">{activeEntry.content}</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-full flex flex-col items-center justify-center py-16">
              <BookOpenText className="h-16 w-16 text-muted-foreground mb-4" />
              <h2 className="text-xl font-medium mb-2">Your Reading Journal</h2>
              <p className="text-muted-foreground text-center max-w-md mb-6">
                Record your thoughts, insights and reflections as you read. Create your first entry or select one from the list.
              </p>
              <Button 
                onClick={() => {
                  setActiveEntry(null);
                  setIsEditing(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create New Entry
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default DiaryPage;
