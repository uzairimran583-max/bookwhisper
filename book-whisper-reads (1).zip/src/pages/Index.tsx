
import { useEffect } from "react";
import HomePage from "./HomePage";

const Index = () => {
  useEffect(() => {
    // Set document title
    document.title = "BookWise - Find Your Next Great Book";
  }, []);

  return <HomePage />;
};

export default Index;
