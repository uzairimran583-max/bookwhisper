
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { PenLine, Book, Trash2, Plus, Lock } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  relatedBook?: string;
}

const NotesPage = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState<{ title: string; content: string; relatedBook?: string }>({
    title: "",
    content: "",
  });
  const [activeTab, setActiveTab] = useState("all");
  const navigate = useNavigate();
  
  // Check if user is logged in
  const { isAuthenticated } = useAuth();
  const isLoggedIn = isAuthenticated || localStorage.getItem("isLoggedIn") === "true" || localStorage.getItem("authStatus") === "authenticated";
  
  useEffect(() => {
    // Load notes from localStorage
    const savedNotes = localStorage.getItem("user_notes");
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);
  
  const saveNotesToStorage = (updatedNotes: Note[]) => {
    localStorage.setItem("user_notes", JSON.stringify(updatedNotes));
    setNotes(updatedNotes);
  };
  
  const handleCreateNote = () => {
    if (!newNote.title.trim()) {
      toast.error("Please enter a title for your note");
      return;
    }
    
    if (!newNote.content.trim()) {
      toast.error("Please enter some content for your note");
      return;
    }
    
    const newNoteItem: Note = {
      id: Date.now().toString(),
      title: newNote.title,
      content: newNote.content,
      date: new Date().toISOString(),
      relatedBook: newNote.relatedBook
    };
    
    const updatedNotes = [...notes, newNoteItem];
    saveNotesToStorage(updatedNotes);
    
    // Reset form
    setNewNote({ title: "", content: "", relatedBook: "" });
    
    toast.success("Note saved successfully!");
  };
  
  const handleDeleteNote = (id: string) => {
    const updatedNotes = notes.filter(note => note.id !== id);
    saveNotesToStorage(updatedNotes);
    toast.success("Note deleted");
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isLoggedIn) {
    return (
      <div className="container py-12 max-w-lg mx-auto text-center">
        <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Lock className="h-8 w-8 text-primary" />
        </div>
        <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
        <p className="text-muted-foreground mb-8">
          You need to be signed in to access your notes
        </p>
        <div className="flex gap-4 justify-center">
          <Button onClick={() => navigate("/login")}>Sign In</Button>
          <Button variant="outline" onClick={() => navigate("/signup")}>Sign Up</Button>
        </div>
      </div>
    );
  }
  
  const filteredNotes = activeTab === "all" 
    ? notes 
    : activeTab === "diary" 
      ? notes.filter(note => !note.relatedBook)
      : notes.filter(note => note.relatedBook);

  return (
    <div className="container py-8 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center">
            <PenLine className="mr-2 h-6 w-6 text-primary" />
            Your Notes & Diary
          </h1>
          <p className="text-muted-foreground">
            Capture your thoughts, ideas, and book reflections
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* New Note Form */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Create New Note</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium mb-1">Title</label>
              <Input 
                id="title"
                placeholder="Enter a title..."
                value={newNote.title}
                onChange={(e) => setNewNote({...newNote, title: e.target.value})}
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium mb-1">Content</label>
              <Textarea 
                id="content"
                placeholder="Write your thoughts..."
                className="min-h-[150px]"
                value={newNote.content}
                onChange={(e) => setNewNote({...newNote, content: e.target.value})}
              />
            </div>
            <div>
              <label htmlFor="book" className="block text-sm font-medium mb-1">Related Book (optional)</label>
              <Input 
                id="book"
                placeholder="Book title..."
                value={newNote.relatedBook || ""}
                onChange={(e) => setNewNote({...newNote, relatedBook: e.target.value})}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleCreateNote} className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Save Note
            </Button>
          </CardFooter>
        </Card>
        
        {/* Notes List */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="all">All Notes</TabsTrigger>
                <TabsTrigger value="diary">Diary</TabsTrigger>
                <TabsTrigger value="books">Book Notes</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="all" className="mt-0">
              <NotesTabContent 
                notes={filteredNotes} 
                onDelete={handleDeleteNote} 
                formatDate={formatDate}
              />
            </TabsContent>
            
            <TabsContent value="diary" className="mt-0">
              <NotesTabContent 
                notes={filteredNotes} 
                onDelete={handleDeleteNote} 
                formatDate={formatDate}
              />
            </TabsContent>
            
            <TabsContent value="books" className="mt-0">
              <NotesTabContent 
                notes={filteredNotes} 
                onDelete={handleDeleteNote} 
                formatDate={formatDate}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// Extract the notes content to a reusable component
const NotesTabContent = ({ 
  notes, 
  onDelete, 
  formatDate 
}: { 
  notes: Note[]; 
  onDelete: (id: string) => void; 
  formatDate: (date: string) => string;
}) => {
  if (notes.length === 0) {
    return (
      <Alert className="bg-muted/50">
        <AlertDescription>
          No notes found. Create a new note to get started.
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div className="space-y-4">
      {notes.map((note) => (
        <Card key={note.id} className="hover:shadow-md transition-shadow">
          <CardHeader className="py-4 px-5">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl">{note.title}</CardTitle>
                <div className="text-xs text-muted-foreground mt-1">
                  {formatDate(note.date)}
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onDelete(note.id)}
                className="text-destructive hover:text-destructive/90 hover:bg-destructive/10 -mr-2 -mt-2"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="py-3 px-5">
            <p className="whitespace-pre-line">{note.content}</p>
            
            {note.relatedBook && (
              <div className="mt-4 pt-3 border-t flex items-center text-sm text-muted-foreground">
                <Book className="mr-2 h-4 w-4" />
                Related to: <span className="font-medium ml-1">{note.relatedBook}</span>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default NotesPage;
