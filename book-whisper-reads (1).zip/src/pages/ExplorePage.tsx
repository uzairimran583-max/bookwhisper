
import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Book, getTrendingBooks, searchBooks, getBooksByCategory } from "@/services/bookService";
import { CURATED_BOOKS } from "@/services/curatedBooks";
import { allBillionaireRecommendations } from "@/data/billionaireRecommendations";
import { BookOpen, Search, TrendingUp, Sparkles, Compass, Bookmark, MessageSquare, ArrowRight, Calendar } from "lucide-react";
import BookGrid from "@/components/BookGrid";
import { toast } from "sonner";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";

const CATEGORIES = [
  "All",
  "Business",
  "Self-Help",
  "Psychology",
  "Science",
  "Technology",
  "Philosophy",
  "Biography"
];

const ExplorePage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [books, setBooks] = useState<Book[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [activeFilter, setActiveFilter] = useState<"trending" | "billionaire" | "classics">("trending");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Deterministic rotation based on the current date (changes automatically every day)
  const today = new Date();
  const dayOfYear = Math.floor(
    (Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) -
      Date.UTC(today.getFullYear(), 0, 0)) /
      (24 * 60 * 60 * 1000)
  );
  const spotlightBook = CURATED_BOOKS[dayOfYear % CURATED_BOOKS.length] || CURATED_BOOKS[0];
  const formattedToday = today.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });

  useEffect(() => {
    fetchCategoryBooks("All");
  }, []);

  const fetchCategoryBooks = async (category: string) => {
    setSelectedCategory(category);
    setLoading(true);
    try {
      if (category === "All") {
        const trending = await getTrendingBooks();
        setBooks(trending);
      } else {
        const catBooks = await getBooksByCategory(category, 16);
        setBooks(catBooks);
      }
    } catch (error) {
      console.error("Error fetching books:", error);
      toast.error("Failed to load books. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (filter: "trending" | "billionaire" | "classics") => {
    setActiveFilter(filter);
    if (filter === "billionaire") {
      const billionaireBooks: Book[] = allBillionaireRecommendations.flatMap(rec => 
        rec.books.map(b => ({
          id: b.id,
          title: b.title,
          authors: b.authors,
          description: `Recommended by ${rec.billionaire}: "${b.quote || ''}"`,
          categories: ["Business", "Leadership"],
          thumbnail: b.thumbnail,
          publishedDate: "2018",
          pageCount: 300,
          language: "en",
          previewLink: "",
          publisher: "Harper / Penguin",
          billionaireRecommendation: {
            billionaire: rec.billionaire,
            quote: b.quote || ""
          }
        }))
      );
      setBooks(billionaireBooks);
    } else if (filter === "classics") {
      setBooks(CURATED_BOOKS.slice(4));
    } else {
      fetchCategoryBooks(selectedCategory);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="container py-8 max-w-7xl mx-auto px-4 sm:px-6 animate-fade-in">
      {/* Editorial Header */}
      <div className="max-w-3xl mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-primary mb-2">
          <Compass className="h-4 w-4" />
          <span>Curated Reading Collections</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-foreground leading-tight">
          Explore Timeless Knowledge & Modern Thinkers
        </h1>
        <p className="text-base text-muted-foreground mt-2">
          Hand-picked summaries of game-changing non-fiction, billionaire book lists, and practical frameworks for high achievers.
        </p>
      </div>

      {/* Featured Spotlight Card */}
      {spotlightBook && (
        <div className="mb-10 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-card to-secondary/30 border border-border shadow-sm flex flex-col md:flex-row items-center gap-6">
          <img
            src={spotlightBook.thumbnail}
            alt={spotlightBook.title}
            className="w-28 sm:w-36 h-40 sm:h-52 object-cover rounded-xl shadow-md shrink-0"
          />
          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-wider mb-2">
              <Calendar className="h-3 w-3" />
              <span>Spotlight of the Day · {formattedToday}</span>
            </div>
            <h2 className="text-2xl font-bold text-foreground">
              {spotlightBook.title}
            </h2>
            <div className="text-xs text-muted-foreground mt-1 mb-3">
              By {spotlightBook.authors.join(", ")} · {spotlightBook.categories.join(", ")} · 15 min summary
            </div>
            <p className="text-sm text-foreground/80 line-clamp-2 max-w-2xl mb-5">
              {spotlightBook.description}
            </p>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
              <Button size="sm" onClick={() => navigate(`/book/${spotlightBook.id}`)}>
                <BookOpen className="h-4 w-4 mr-1.5" /> Read Summary
              </Button>
              <AmazonBuyButton
                bookTitle={spotlightBook.title}
                author={spotlightBook.authors?.[0]}
                bookId={spotlightBook.id}
                thumbnail={spotlightBook.thumbnail}
                size="sm"
              />
              <Button size="sm" variant="outline" onClick={() => navigate(`/ai-features`, { state: { initialQuestion: `Summarize the key ideas from ${spotlightBook.title} by ${spotlightBook.authors[0]}`, bookTitle: spotlightBook.title, author: spotlightBook.authors[0] } })}>
                <MessageSquare className="h-4 w-4 mr-1.5" /> Ask AI
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Search Bar on Explore */}
      <div className="max-w-xl mx-auto mb-10">
        <form onSubmit={handleSearchSubmit}>
          <div className="relative flex items-center bg-card border border-border rounded-xl shadow-sm overflow-hidden focus-within:ring-2 focus-within:ring-primary/20 focus-within:border-primary/50 transition-all">
            <Search className="h-4 w-4 text-muted-foreground ml-4 shrink-0" />
            <Input
              type="search"
              placeholder="Search by title, topic, or author..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border-none bg-transparent shadow-none px-3 py-5 text-sm focus-visible:ring-0 placeholder:text-muted-foreground/60"
            />
            <button
              type="submit"
              className="mr-2 px-3.5 py-1.5 text-xs font-medium bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
            >
              Search
            </button>
          </div>
        </form>
      </div>

      {/* View Filter Toggles (Zero-Pill Segmented Control) */}
      <div className="flex items-center justify-between flex-wrap gap-4 border-b border-border/60 pb-4 mb-6">
        <div className="flex items-center gap-1 p-1 bg-muted rounded-xl">
          <button
            onClick={() => handleFilterChange("trending")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              activeFilter === "trending"
                ? "bg-card text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            All Trending
          </button>
          <button
            onClick={() => handleFilterChange("billionaire")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              activeFilter === "billionaire"
                ? "bg-card text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Billionaire Picks
          </button>
          <button
            onClick={() => handleFilterChange("classics")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              activeFilter === "classics"
                ? "bg-card text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Classic Masterpieces
          </button>
        </div>

        <div className="text-xs text-muted-foreground font-mono">
          {books.length} curated books
        </div>
      </div>

      {/* Category Pills Bar */}
      {activeFilter === "trending" && (
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-3 mb-6">
          {CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => fetchCategoryBooks(category)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === category
                  ? "bg-foreground text-background font-semibold"
                  : "bg-muted/50 text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      )}

      {/* Books Grid */}
      <BookGrid books={books} loading={loading} />
    </div>
  );
};

export default ExplorePage;
