import { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { getBookById, Book } from "@/services/bookService";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, BookOpen, Clock, FileText } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const ComprehensiveSummaryPage = () => {
  const { id } = useParams<{ id: string }>();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [comprehensiveSummary, setComprehensiveSummary] = useState<string>("");
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const fetchBook = async () => {
      if (!id) return;
      
      setLoading(true);
      try {
        let bookData = location.state?.book;
        if (!bookData) {
          bookData = await getBookById(id);
        }
        setBook(bookData);
        
        // Generate comprehensive summary
        await generateComprehensiveSummary(bookData);
      } catch (error) {
        console.error("Error fetching book:", error);
        toast.error("Failed to load book details. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBook();
  }, [id, location.state?.book]);

  const generateComprehensiveSummary = async (bookData: Book) => {
    setGenerating(true);
    
    try {
      // Import AI service
      const { getComprehensiveBookAnalysis } = await import("@/services/aiService");
      
      // Generate actual AI-powered comprehensive analysis
      const aiResponse = await getComprehensiveBookAnalysis(bookData.title, bookData.authors.join(", "), bookData.description || "");
      
      setComprehensiveSummary(aiResponse);
      toast.success("Comprehensive 5000+ word analysis generated successfully!");
    } catch (error) {
      console.error("Error generating comprehensive summary:", error);
      toast.error("Failed to generate comprehensive analysis. Please try again.");
      
      // Fallback content if AI fails
      setComprehensiveSummary(`# Complete Analysis: ${bookData.title}

## Book Overview
${bookData.title} by ${bookData.authors.join(", ")} is a comprehensive work that offers valuable insights and perspectives. This analysis provides an in-depth look at the key themes, concepts, and practical applications presented in the book.

## Executive Summary
This comprehensive analysis explores the key concepts, practical applications, and transformational insights from this important work. The book provides readers with actionable strategies and frameworks for implementation in daily life.

## Key Insights and Applications
- The book offers practical wisdom and actionable strategies
- Core concepts are presented in an accessible manner
- Real-world examples enhance understanding
- The content is relevant for personal and professional growth
- Implementation guidance helps readers apply the concepts

*This analysis provides a comprehensive overview of the book's main themes and practical applications.*`);
    } finally {
      setGenerating(false);
    }
  };

  const handleBack = () => {
    // Check if we came from a search page
    if (location.state?.fromSearch && location.state?.searchQuery) {
      navigate(`/search?q=${encodeURIComponent(location.state.searchQuery)}`);
    } else if (location.state?.fromBookDetail && location.state?.bookDetailPath) {
      navigate(location.state.bookDetailPath);
    } else {
      navigate(`/book/${id}`);
    }
  };

  if (loading || generating) {
    return (
      <div className="min-h-screen glass-chat-container">
        <div className="container max-w-4xl py-6">
          <div className="flex items-center mb-6">
            <Button onClick={handleBack} variant="outline" className="glass-button mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <h1 className="text-2xl font-bold">Complete Book Generator</h1>
          </div>
          
          <div className="glass-card p-8">
            {generating ? (
              <div className="text-center space-y-4">
                <div className="animate-spin mx-auto h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
                <h3 className="text-lg font-medium">Generating Comprehensive Analysis...</h3>
                <p className="text-muted-foreground">Creating 5000+ word detailed analysis with chapters, examples, quotes and implementation guide</p>
              </div>
            ) : (
              <>
                <Skeleton className="h-8 w-3/4 mb-6" />
                <div className="space-y-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center glass-chat-container">
        <div className="glass-card p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Book not found</h1>
          <p className="mb-6">We couldn't find the book you're looking for.</p>
          <Button onClick={handleBack} className="glass-button">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen glass-chat-container">
      <div className="container max-w-4xl py-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-6"
        >
          <Button onClick={handleBack} variant="outline" className="glass-button">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Book
          </Button>
          
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              8-10 min read
            </div>
            <div className="flex items-center">
              <FileText className="mr-1 h-4 w-4" />
              5000+ words  
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="glass-card overflow-hidden shadow-lg">
            <div className="glass-chat-header p-6 border-b border-white/10">
              <div className="flex items-start space-x-4">
                <div className="glass-icon-container p-3 rounded-full">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold mb-2">{book.title}</h1>
                  <p className="text-lg text-muted-foreground mb-2">Complete Analysis & Generator</p>
                  <p className="text-sm text-muted-foreground">by {book.authors.join(", ")}</p>
                </div>
              </div>
            </div>
            
            <div className="p-8">
              <div className="prose prose-sm max-w-none">
                <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                  {comprehensiveSummary}
                </pre>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="mt-6 flex justify-center">
          <Button 
            onClick={handleBack}
            size="lg"
            className="glass-button"
          >
            Got Complete Analysis? Go Back
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ComprehensiveSummaryPage;