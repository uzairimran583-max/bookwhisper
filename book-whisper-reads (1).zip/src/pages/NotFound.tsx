
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { BookOpenText, Home, Search, ArrowLeft } from "lucide-react";
import { getBookById } from "@/services/bookService";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [attemptingRecovery, setAttemptingRecovery] = useState(false);

  useEffect(() => {
    const attemptToRecover = async () => {
      console.error(
        "404 Error: User attempted to access non-existent route:",
        location.pathname
      );

      // If we're on the root path and getting 404, try to reload
      if (location.pathname === "/" || location.pathname === "") {
        console.log("404 on root path, attempting recovery...");
        setAttemptingRecovery(true);
        
        // Try to navigate to home after a short delay
        setTimeout(() => {
          window.location.href = "/";
        }, 1000);
        return;
      }

      // If the path starts with /book/ try to recover
      if (location.pathname.startsWith('/book/')) {
        setAttemptingRecovery(true);
        
        // Extract the book ID from the URL
        const path = location.pathname.split('/');
        const bookId = path[path.length - 1];
        
        if (bookId) {
          try {
            // First, check if we have billionaire book data in session storage
            const billionaireBookData = sessionStorage.getItem('billionaireBook');
            if (billionaireBookData) {
              const bookData = JSON.parse(billionaireBookData);
              if (bookData.id === bookId) {
                // This is a billionaire recommendation - navigate to book page with data
                navigate(`/book/${bookId}`, { 
                  replace: true,
                  state: { 
                    fromBillionaire: true,
                    bookData: bookData 
                  }
                });
                return;
              }
            }
            
            // Try to fetch the book data
            const bookData = await getBookById(bookId);
            
            if (bookData) {
              // Book exists, must be another issue - retry the navigation
              navigate(`/book/${bookId}`, { replace: true });
              return;
            }
          } catch (error) {
            console.error("Error recovering book:", error);
          } finally {
            setAttemptingRecovery(false);
          }
        }

        // If we get here, we couldn't recover the book
        // Store in session storage to potentially use on the search page
        sessionStorage.setItem('lastBookAttempt', bookId);
      }
      
      // Handle other routes that might need recovery
      else if (location.pathname.startsWith('/reader/')) {
        const path = location.pathname.split('/');
        const bookId = path[path.length - 1];
        
        if (bookId) {
          sessionStorage.setItem('lastBookAttempt', bookId);
          // Redirect to the book detail page instead
          navigate(`/book/${bookId}`, { replace: true });
        }
      }
    };

    attemptToRecover();
  }, [location.pathname, navigate]);

  const goBack = () => {
    navigate(-1);
  };
  
  const goToSearch = () => {
    const lastBookAttempt = sessionStorage.getItem('lastBookAttempt');
    if (lastBookAttempt) {
      navigate(`/search?q=${encodeURIComponent(lastBookAttempt)}`);
    } else {
      navigate('/search');
    }
  };

  const goHome = () => {
    // Use window.location.href for more reliable navigation
    window.location.href = "/";
  };

  if (attemptingRecovery) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center p-6">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <h2 className="text-xl font-medium mb-2">Attempting to recover your page...</h2>
          <p className="text-muted-foreground">Please wait a moment</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center max-w-md p-6">
        <div className="mb-6 w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
          <BookOpenText className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-4xl font-bold mb-4">Page Not Found</h1>
        <p className="text-lg text-muted-foreground mb-8">
          Sorry, we couldn't find the page you're looking for. It might have been moved or deleted.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button onClick={goBack} variant="outline" className="gap-2 transition-transform hover:scale-105 active:scale-95">
            <ArrowLeft className="h-4 w-4" />
            Go Back
          </Button>
          <Button onClick={goHome} className="gap-2 transition-transform hover:scale-105 active:scale-95">
            <Home className="h-4 w-4" />
            Back to Home
          </Button>
          <Button onClick={goToSearch} variant="secondary" className="gap-2 transition-transform hover:scale-105 active:scale-95">
            <Search className="h-4 w-4" />
            Search Books
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
