
import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Moon, Sun, Type, BookOpen, Clock, Calendar, BarChart2, Shield, Trash2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const SettingsPage = () => {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark" || 
      (!localStorage.getItem("theme") && window.matchMedia("(prefers-color-scheme: dark)").matches);
  });
  
  const [readerFontSize, setReaderFontSize] = useState(() => {
    return parseInt(localStorage.getItem("reader_font_size") || "17", 10);
  });

  const [readerFontFamily, setReaderFontFamily] = useState(() => {
    return localStorage.getItem("reader_font_family") || "serif";
  });

  const [readingGoal, setReadingGoal] = useState(() => {
    return parseInt(localStorage.getItem("reading_goal") || "25", 10);
  });

  const [readingTime, setReadingTime] = useState(() => {
    return parseInt(localStorage.getItem("readingTime") || "45", 10);
  });

  const [weeklyReadingTime, setWeeklyReadingTime] = useState<number[]>(() => {
    try {
      const stored = localStorage.getItem("weekly_reading_time");
      return stored ? JSON.parse(stored) : [25, 30, 20, 45, 35, 50, 40];
    } catch {
      return [25, 30, 20, 45, 35, 50, 40];
    }
  });

  const [displayName, setDisplayName] = useState(() => {
    return localStorage.getItem("reader_name") || "Avid Reader";
  });

  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [activeTab, setActiveTab] = useState("reader");
  const navigate = useNavigate();

  const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  useEffect(() => {
    localStorage.setItem("reading_goal", readingGoal.toString());
  }, [readingGoal]);

  useEffect(() => {
    localStorage.setItem("reader_font_size", readerFontSize.toString());
  }, [readerFontSize]);

  useEffect(() => {
    localStorage.setItem("reader_font_family", readerFontFamily);
  }, [readerFontFamily]);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    
    if (newMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
    toast.success(`${newMode ? "Dark" : "Light"} mode enabled`);
  };

  const handleSaveProfile = () => {
    localStorage.setItem("reader_name", displayName);
    toast.success("Settings updated successfully");
  };

  const handleClearCache = () => {
    localStorage.removeItem("search-history");
    toast.success("Search history and temporary caches cleared");
  };

  const goalPercent = Math.min(Math.round(((weeklyReadingTime.reduce((a, b) => a + b, 0) / 7) / readingGoal) * 100), 100);

  return (
    <div className="container py-8 max-w-4xl mx-auto px-4 sm:px-6 animate-fade-in">
      {/* Back button & Page title */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Link to="/" className="p-2 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground">
              Settings & Preferences
            </h1>
            <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
              Customize typography, daily reading goals, and interface display.
            </p>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="border-b border-border/60 pb-2">
          <TabsList className="bg-muted p-1 rounded-xl">
            <TabsTrigger value="reader" className="text-xs font-medium px-4 py-1.5 rounded-lg">
              Reader Experience
            </TabsTrigger>
            <TabsTrigger value="goals" className="text-xs font-medium px-4 py-1.5 rounded-lg">
              Reading Goals
            </TabsTrigger>
            <TabsTrigger value="account" className="text-xs font-medium px-4 py-1.5 rounded-lg">
              Account & Storage
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Reader Experience Tab */}
        <TabsContent value="reader" className="space-y-6">
          <Card className="rounded-xl border border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Sun className="h-4 w-4 text-primary" /> Appearance & Theme
              </CardTitle>
              <CardDescription>
                Choose your visual theme for day and night reading.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">Dark Mode</div>
                  <div className="text-xs text-muted-foreground">High-contrast dark palette for night reading</div>
                </div>
                <Switch checked={darkMode} onCheckedChange={toggleDarkMode} />
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl border border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Type className="h-4 w-4 text-primary" /> Reader Typography
              </CardTitle>
              <CardDescription>
                Configure font style and size for reading book summaries.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 block">
                  Font Family
                </Label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: "serif", label: "Editorial Serif", sample: "Playfair / Garamond" },
                    { id: "sans", label: "Clean Sans", sample: "Inter / System" },
                    { id: "mono", label: "Focus Mono", sample: "Code & Analysis" }
                  ].map(font => (
                    <button
                      key={font.id}
                      type="button"
                      onClick={() => setReaderFontFamily(font.id)}
                      className={`p-3.5 rounded-xl border text-left transition-all ${
                        readerFontFamily === font.id
                          ? "border-primary bg-primary/5 ring-1 ring-primary"
                          : "border-border hover:border-border/80 bg-card"
                      }`}
                    >
                      <div className="text-sm font-semibold">{font.label}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{font.sample}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label className="text-sm font-medium">Font Size: {readerFontSize}px</Label>
                  <span className="text-xs text-muted-foreground">Default: 17px</span>
                </div>
                <Slider
                  value={[readerFontSize]}
                  min={14}
                  max={24}
                  step={1}
                  onValueChange={(val) => setReaderFontSize(val[0])}
                />
              </div>

              {/* Live Preview Box */}
              <div className="p-4 rounded-xl bg-muted/40 border border-border">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                  Live Preview
                </div>
                <p 
                  style={{ 
                    fontSize: `${readerFontSize}px`,
                    fontFamily: readerFontFamily === "serif" ? "Georgia, serif" : readerFontFamily === "mono" ? "monospace" : "sans-serif"
                  }}
                  className="text-foreground leading-relaxed transition-all"
                >
                  "The impediment to action advances action. What stands in the way becomes the way."
                  <span className="block text-xs text-muted-foreground mt-1">— Marcus Aurelius, Meditations</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reading Goals Tab */}
        <TabsContent value="goals" className="space-y-6">
          <Card className="rounded-xl border border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" /> Daily Reading Target
              </CardTitle>
              <CardDescription>
                Set how many minutes of reading insights you want to achieve each day.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-semibold">{readingGoal} minutes per day</span>
                  <span className="text-xs text-primary font-medium">
                    {readingGoal >= 45 ? "Dedicated Reader" : "Steady Habits"}
                  </span>
                </div>
                <Slider
                  value={[readingGoal]}
                  min={10}
                  max={90}
                  step={5}
                  onValueChange={(v) => setReadingGoal(v[0])}
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Weekly Goal Completion</span>
                  <span className="text-xs font-semibold tabular-nums">{goalPercent}%</span>
                </div>
                <Progress value={goalPercent} className="h-2 rounded-full" />
              </div>

              {/* Weekly bar chart */}
              <div className="pt-4 border-t border-border">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                  This Week's Activity
                </div>
                <div className="flex items-end h-36 gap-2">
                  {weeklyReadingTime.map((time, idx) => {
                    const heightPercent = Math.min((time / (readingGoal * 1.4)) * 100, 100);
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                        <span className="text-[10px] text-muted-foreground tabular-nums font-mono">{time}m</span>
                        <div 
                          className={`w-full rounded-md transition-all ${time >= readingGoal ? 'bg-primary' : 'bg-primary/40'}`}
                          style={{ height: `${heightPercent}%` }}
                        />
                        <span className="text-xs text-muted-foreground font-medium">{daysOfWeek[idx]}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Account & Storage Tab */}
        <TabsContent value="account" className="space-y-6">
          <Card className="rounded-xl border border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Reader Profile</CardTitle>
              <CardDescription>
                Personalize your display name across the application.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reader-name" className="text-xs font-medium">Display Name</Label>
                <Input
                  id="reader-name"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="max-w-md"
                />
              </div>
              <div className="pt-2">
                <Button size="sm" onClick={handleSaveProfile}>
                  Save Profile
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl border border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" /> Storage & Cache
              </CardTitle>
              <CardDescription>
                Manage offline caches and stored reading data.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">Clear Search History</div>
                  <div className="text-xs text-muted-foreground">Deletes local recent search keywords</div>
                </div>
                <Button variant="outline" size="sm" onClick={handleClearCache}>
                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Clear
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsPage;
