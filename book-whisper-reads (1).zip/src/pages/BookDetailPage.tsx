import { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { getBookById, Book } from "@/services/bookService";
import { generateSummary } from "@/services/summaryService";
import { savedBooksService } from "@/services/savedBooksService";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Heart, Share2 } from "lucide-react";
import { toast } from "sonner";
import BookCover from "@/components/book-detail/BookCover";
import BookMetadata from "@/components/book-detail/BookMetadata";
import BookSummary from "@/components/book-detail/BookSummary";
import BookAIFeatures from "@/components/book-detail/BookAIFeatures";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { AudiblePlayer } from "@/components/audio/AudiblePlayer";
import { useAuth } from "@/context/AuthContext";

const BookDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSaved, setIsSaved] = useState(false);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [summaryUsed, setSummaryUsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const fetchBook = async () => {
      if (!id) return;

      setLoading(true);
      try {
        const bookData = await getBookById(id);
        setBook(bookData);

        if (bookData) {
          const saved = await savedBooksService.isBookSaved(bookData.id);
          setIsSaved(saved);
        }
      } catch (error) {
        console.error("Error fetching book:", error);
        toast.error("Failed to load book details. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBook();

    const handleSavedChange = async () => {
      if (id) {
        const saved = await savedBooksService.isBookSaved(id);
        setIsSaved(saved);
      }
    };
    window.addEventListener("bookwhisper:saved_books_changed", handleSavedChange);
    return () => window.removeEventListener("bookwhisper:saved_books_changed", handleSavedChange);
  }, [id]);

  const { isAuthenticated, openAuthModal } = useAuth();

  const handleGenerateSummary = async () => {
    if (!book || generatingSummary) return;

    if (!isAuthenticated) {
      toast.info("Sign in or sign up to read AI book summaries.");
      openAuthModal(`Sign in or sign up with Gmail to read AI summary of "${book.title}"`);
      return;
    }

    setGeneratingSummary(true);
    try {
      if (book.description) {
        await generateSummary(book.description);
        setSummaryUsed(true);
        navigate(`/reader/${id}`, {
          state: {
            fromBookDetail: true,
            bookDetailPath: location.pathname + location.search,
          },
        });
      } else {
        toast.error("No book description available for summary generation.");
      }
    } catch (error) {
      console.error("Error generating summary:", error);
      toast.error("Failed to generate summary. Please try again.");
    } finally {
      setGeneratingSummary(false);
    }
  };

  const handleNavigateToAIChat = () => {
    if (!book) return;

    if (!isAuthenticated) {
      toast.info("Sign in or sign up to chat with AI Book Intelligence.");
      openAuthModal(`Sign in or sign up to chat about "${book.title}"`);
      return;
    }

    const initialQuestion = `Tell me about the book "${book.title}" by ${book.authors.join(", ")}`;

    navigate("/ai-features", {
      state: {
        initialQuestion,
        bookTitle: book.title,
        author: book.authors.join(", "),
        bookId: id,
        fromBookDetail: true,
        bookDetailPath: location.pathname + location.search,
      },
    });
  };

  const handleGenerateComprehensiveSummary = async () => {
    if (!book) return;

    if (!isAuthenticated) {
      toast.info("Sign in or sign up to access deep literary analysis.");
      openAuthModal(`Sign in or sign up to access 5000+ word deep analysis of "${book.title}"`);
      return;
    }

    try {
      toast.success("Generating comprehensive chapter analysis...");
      navigate(`/comprehensive-summary/${id}`, {
        state: {
          fromBookDetail: true,
          bookDetailPath: location.pathname + location.search,
          book: book,
        },
      });
    } catch (error) {
      console.error("Error generating comprehensive summary:", error);
      toast.error("Failed to generate comprehensive analysis.");
    }
  };

  const handleBack = () => {
    navigate(-1);
  };

  const handleToggleSaveBook = async () => {
    if (!book) return;

    if (isSaved) {
      const res = await savedBooksService.removeBook(book.id);
      if (res) setIsSaved(false);
    } else {
      const res = await savedBooksService.saveBook(book);
      if (res) setIsSaved(true);
    }
  };

  const handleShare = () => {
    if (navigator.share && book) {
      navigator.share({
        title: book.title,
        text: `Check out this book: ${book.title} by ${book.authors.join(", ")}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  if (loading) {
    return (
      <div className="container max-w-4xl py-6 animate-pulse">
        <Skeleton className="h-8 w-32 mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Skeleton className="aspect-[3/4] w-full rounded-lg" />
          </div>
          <div className="md:col-span-2 space-y-6">
            <div>
              <Skeleton className="h-8 w-3/4 mb-2" />
              <Skeleton className="h-6 w-1/2 mb-4" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="container max-w-4xl py-6">
        <Card className="p-8 text-center border border-border">
          <h1 className="text-2xl font-bold mb-4">Book not found</h1>
          <p className="mb-6 text-muted-foreground">We couldn't find the book you're looking for.</p>
          <Button onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl py-6 pb-24">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <Button onClick={handleBack} variant="ghost" size="sm" className="flex items-center">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        <div className="flex items-center space-x-2">
          {/* Prominent Amazon Buy Button */}
          <AmazonBuyButton
            bookTitle={book.title}
            author={book.authors?.[0]}
            bookId={book.id}
            thumbnail={book.thumbnail}
            size="sm"
          />

          <Button
            onClick={handleToggleSaveBook}
            variant={isSaved ? "default" : "outline"}
            size="icon"
            className="h-9 w-9"
            title={isSaved ? "Remove from Library" : "Save to Library"}
          >
            <Heart className={`h-4 w-4 ${isSaved ? "fill-current text-white" : ""}`} />
          </Button>

          <Button onClick={handleShare} variant="outline" size="icon" className="h-9 w-9" title="Share link">
            <Share2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <BookCover
            id={book.id}
            title={book.title}
            author={book.authors.join(", ")}
            coverImage={book.thumbnail || "/placeholder.svg"}
            rating={book.averageRating}
            showButton={true}
            buttonText="Read Summary"
            onReadClick={handleGenerateSummary}
          />
        </div>

        <div className="md:col-span-2 space-y-6">
          <BookMetadata book={book} isAudibleAvailable={true} />
          <BookSummary book={book} />
          <BookAIFeatures
            book={book}
            summaryUsed={summaryUsed}
            isAudibleAvailable={true}
            generatingSummary={generatingSummary}
            handleGenerateSummary={handleGenerateSummary}
            handleNavigateToAIChat={handleNavigateToAIChat}
            handleGenerateComprehensiveSummary={handleGenerateComprehensiveSummary}
          />
        </div>
      </div>

      {/* Persistent Audio narration player */}
      <AudiblePlayer />
    </div>
  );
};

export default BookDetailPage;
