import { useState, useEffect } from "react";
import { Clock, BookText, Trash, Plus, Sparkles, BookOpen, PenLine, ArrowRight } from "lucide-react";
import { Book } from "@/services/bookService";
import BookCard from "@/components/BookCard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate, Link } from "react-router-dom";
import { savedBooksService } from "@/services/savedBooksService";
import { CURATED_BOOKS } from "@/services/curatedBooks";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";

interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
  relatedBook?: string;
}

const LibraryPage = () => {
  const [activeTab, setActiveTab] = useState<string>("saved");
  const [books, setBooks] = useState<Book[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [readingTime, setReadingTime] = useState(45);
  const [readingGoal, setReadingGoal] = useState(60);
  const navigate = useNavigate();

  const { user, isAuthenticated, openAuthModal } = useAuth();

  useEffect(() => {
    fetchLibraryData();

    const handleSavedChange = () => {
      fetchLibraryData();
    };

    window.addEventListener("bookwhisper:saved_books_changed", handleSavedChange);
    window.addEventListener("bookwhisper:auth_changed", handleSavedChange);
    return () => {
      window.removeEventListener("bookwhisper:saved_books_changed", handleSavedChange);
      window.removeEventListener("bookwhisper:auth_changed", handleSavedChange);
    };
  }, []);

  const fetchLibraryData = async () => {
    setLoading(true);
    try {
      const saved = await savedBooksService.getSavedBooks();
      setBooks(saved);

      const savedTime = parseInt(localStorage.getItem("readingTime") || "45", 10);
      setReadingTime(savedTime);

      const goal = parseInt(localStorage.getItem("reading_goal") || "60", 10);
      setReadingGoal(goal);

      const localNotes = localStorage.getItem("user_notes");
      if (localNotes) {
        setNotes(JSON.parse(localNotes));
      }
    } catch (error) {
      console.error("Error fetching library data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveBook = async (bookId: string) => {
    const success = await savedBooksService.removeBook(bookId);
    if (success) {
      setBooks(prev => prev.filter(b => b.id !== bookId));
    }
  };

  const handleAddStarterPicks = async () => {
    const starters = CURATED_BOOKS.slice(0, 3);
    for (const b of starters) {
      await savedBooksService.saveBook(b);
    }
    const updated = await savedBooksService.getSavedBooks();
    setBooks(updated);
    toast.success("Added top recommended bestsellers to your shelf!");
  };

  const progressPercent = Math.min(Math.round((readingTime / readingGoal) * 100), 100);

  return (
    <div className="container py-8 max-w-7xl mx-auto px-4 sm:px-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-foreground">
            Personal Library
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Your saved titles, key takeaways, and personal reading milestones.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => navigate("/notes")}>
            <PenLine className="h-4 w-4 mr-1.5" /> Reading Diary
          </Button>
          <Button size="sm" onClick={() => navigate("/explore")}>
            <Plus className="h-4 w-4 mr-1.5" /> Explore Books
          </Button>
        </div>
      </div>

      {/* Reading Performance Strip (Clean Editorial Figures) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Books Saved
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-foreground mt-1 tabular-nums">
            {books.length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            In active bookshelf
          </div>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Reading Time
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-foreground mt-1 tabular-nums">
            {readingTime} <span className="text-sm font-normal text-muted-foreground">mins</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Logged this week
          </div>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Weekly Target
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-foreground mt-1 tabular-nums">
            {progressPercent}%
          </div>
          <div className="w-full bg-muted h-1.5 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-primary h-full transition-all duration-500 rounded-full" 
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Reading Streak
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-foreground mt-1 tabular-nums">
            5 <span className="text-sm font-normal text-muted-foreground">days</span>
          </div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium mt-1">
            Consistent reader
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <div className="flex items-center justify-between border-b border-border/60 pb-3 mb-6">
          <TabsList className="bg-muted p-1 rounded-xl">
            <TabsTrigger value="saved" className="text-xs font-medium px-4 py-1.5 rounded-lg">
              Saved Books ({books.length})
            </TabsTrigger>
            <TabsTrigger value="notes" className="text-xs font-medium px-4 py-1.5 rounded-lg">
              Key Insights & Notes ({notes.length})
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="saved" className="mt-0">
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6 py-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-72 rounded-xl bg-muted/60 animate-pulse" />
              ))}
            </div>
          ) : books.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {books.map(book => (
                <div key={book.id} className="relative group">
                  <BookCard book={book} />
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      handleRemoveBook(book.id);
                    }}
                    title="Remove from library"
                    className="absolute top-2 left-2 p-1.5 rounded-full bg-background/80 hover:bg-destructive hover:text-destructive-foreground text-muted-foreground shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-20"
                  >
                    <Trash className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-muted/20 border border-dashed border-border rounded-2xl max-w-2xl mx-auto p-8">
              <BookText className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <h2 className="text-xl font-bold mb-2">Your bookshelf is empty</h2>
              <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
                Save summaries to build your personal reading repository, track daily learning, and review anytime.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Button onClick={handleAddStarterPicks}>
                  <Sparkles className="h-4 w-4 mr-1.5" /> Add Top 3 Bestsellers Starter Pack
                </Button>
                <Button variant="outline" onClick={() => navigate("/explore")}>
                  Browse All Titles
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="notes" className="mt-0">
          {notes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {notes.map(note => (
                <div key={note.id} className="p-5 rounded-xl bg-card border border-border shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-base text-foreground">{note.title}</h3>
                    <span className="text-xs text-muted-foreground font-mono">
                      {new Date(note.date).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-3 mb-4">
                    {note.content}
                  </p>
                  {note.relatedBook && (
                    <div className="text-xs text-primary font-medium flex items-center gap-1">
                      <BookOpen className="h-3.5 w-3.5" /> {note.relatedBook}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-muted/20 border border-dashed border-border rounded-2xl max-w-xl mx-auto p-8">
              <PenLine className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No notes saved yet</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Capture your reflections and action items as you read book summaries.
              </p>
              <Button onClick={() => navigate("/notes")}>
                Create Your First Note
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LibraryPage;
