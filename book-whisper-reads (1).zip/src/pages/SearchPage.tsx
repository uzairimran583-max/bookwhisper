
import { useState, useEffect, useMemo } from "react";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import { searchBooks, Book, getTrendingBooks, getRelativeBooks } from "@/services/bookService";
import BookGrid from "@/components/BookGrid";
import { toast } from "sonner";
import { ArrowLeft, Search, SlidersHorizontal, Sparkles, X, Compass, Layers } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

const FILTER_CATEGORIES = [
  "All",
  "Business",
  "Self-Help",
  "Psychology",
  "Technology",
  "Philosophy",
  "Biography"
];

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const [searchInput, setSearchInput] = useState(initialQuery);
  const [books, setBooks] = useState<Book[]>([]);
  const [relativeBooks, setRelativeBooks] = useState<Book[]>([]);
  const [recommendedBooks, setRecommendedBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState<"relevance" | "rating" | "newest">("relevance");
  const navigate = useNavigate();

  useEffect(() => {
    setSearchInput(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    const fetchSearchResults = async () => {
      if (!initialQuery.trim()) {
        setBooks([]);
        setRelativeBooks([]);
        setRecommendedBooks(prev => {
          if (prev.length === 0) {
            getTrendingBooks().then(trending => setRecommendedBooks(trending));
          }
          return prev;
        });
        return;
      }
      
      setLoading(true);
      try {
        const cleanQ = initialQuery.trim();
        const [results, relative] = await Promise.all([
          searchBooks(cleanQ, 24),
          getRelativeBooks(cleanQ, 8)
        ]);
        
        setBooks(results);

        // Exclude books already in the main search results
        const resultIds = new Set(results.map(b => b.id.toLowerCase()));
        const uniqueRelative = relative.filter(b => !resultIds.has(b.id.toLowerCase())).slice(0, 6);
        setRelativeBooks(uniqueRelative);
      } catch (error) {
        console.error("Error searching books:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSearchResults();
  }, [initialQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setSearchParams({ q: searchInput.trim() });
    }
  };

  const filteredBooks = useMemo(() => {
    let result = [...books];
    if (selectedCategory !== "All") {
      const catLower = selectedCategory.toLowerCase();
      result = result.filter(b => 
        b.categories?.some(c => c.toLowerCase().includes(catLower)) ||
        b.description?.toLowerCase().includes(catLower)
      );
    }

    if (sortBy === "rating") {
      result.sort((a, b) => (b.averageRating || 4.5) - (a.averageRating || 4.5));
    } else if (sortBy === "newest") {
      result.sort((a, b) => (b.publishedYear || 2020) - (a.publishedYear || 2020));
    }

    return result;
  }, [books, selectedCategory, sortBy]);

  return (
    <div className="container py-8 max-w-7xl mx-auto px-4 sm:px-6 animate-fade-in">
      {/* Top back navigation */}
      <div className="flex items-center justify-between mb-6">
        <Link 
          to="/" 
          className="text-xs font-medium text-muted-foreground hover:text-foreground inline-flex items-center transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5 mr-1.5" /> Back to Discover
        </Link>
        <span className="text-xs text-muted-foreground font-mono">
          {initialQuery ? `${filteredBooks.length} results` : "Explore Catalog"}
        </span>
      </div>

      {/* Hero Search Box */}
      <div className="max-w-2xl mx-auto mb-8">
        <form onSubmit={handleSearchSubmit}>
          <div className="relative flex items-center bg-card border border-border shadow-sm rounded-xl overflow-hidden focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
            <Search className="h-5 w-5 text-muted-foreground ml-4 shrink-0" />
            <Input
              type="search"
              placeholder="Search by book title, author, or keywords..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="border-none bg-transparent shadow-none px-3 py-6 text-base focus-visible:ring-0 placeholder:text-muted-foreground/60"
            />
            {searchInput && (
              <button
                type="button"
                onClick={() => setSearchInput("")}
                className="p-2 text-muted-foreground hover:text-foreground mr-1"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            <button
              type="submit"
              className="mr-2 px-4 py-2 text-xs font-semibold text-primary-foreground bg-primary rounded-lg hover:opacity-90 transition-opacity"
            >
              Search
            </button>
          </div>
        </form>

        {/* Popular shortcuts */}
        <div className="flex items-center flex-wrap gap-1.5 mt-3 text-xs text-muted-foreground">
          <span className="font-medium">Trending:</span>
          {["Atomic Habits", "Zero to One", "Psychology of Money", "Deep Work", "Steve Jobs"].map(t => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setSearchInput(t);
                setSearchParams({ q: t });
              }}
              className="px-2 py-0.5 rounded bg-muted hover:bg-secondary text-secondary-foreground text-[11px] transition-colors"
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Filter and sorting controls */}
      {initialQuery && (
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/60 pb-4 mb-8">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {FILTER_CATEGORIES.map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-muted/60 text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto shrink-0 text-xs">
            <span className="text-muted-foreground flex items-center gap-1 font-medium">
              <SlidersHorizontal className="h-3.5 w-3.5" /> Sort:
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-card border border-border text-foreground text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
            >
              <option value="relevance">Relevance</option>
              <option value="rating">Highest Rating</option>
              <option value="newest">Newest First</option>
            </select>
          </div>
        </div>
      )}

      {/* Main Results View */}
      {loading ? (
        <div className="py-12">
          <BookGrid books={[]} loading={true} />
        </div>
      ) : initialQuery ? (
        filteredBooks.length > 0 ? (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold tracking-tight text-foreground">
                Results for <span className="text-primary italic">"{initialQuery}"</span>
              </h2>
              <span className="text-xs text-muted-foreground">
                Showing {filteredBooks.length} titles
              </span>
            </div>
            <BookGrid books={filteredBooks} loading={false} />

            {/* Relative and related books section */}
            {relativeBooks.length > 0 && (
              <div className="mt-14 pt-10 border-t border-border/70">
                <div className="mb-6">
                  <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary mb-1">
                    <Layers className="h-3.5 w-3.5" />
                    <span>Related Books & Relative Topics</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-foreground">
                    Readers searching for "{initialQuery}" also explored
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Curated relative titles covering adjacent ideas, authors, and frameworks.
                  </p>
                </div>
                <BookGrid books={relativeBooks} loading={false} />
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-16 bg-muted/20 border border-dashed border-border rounded-2xl max-w-2xl mx-auto p-8">
            <Search className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-60" />
            <h3 className="text-lg font-semibold mb-2">No direct title match found</h3>
            <p className="text-sm text-muted-foreground mb-6">
              We couldn't find an exact match for "{initialQuery}". Here are related books and recommendations you might enjoy:
            </p>
            {(relativeBooks.length > 0 || recommendedBooks.length > 0) && (
              <div className="text-left mt-8 pt-8 border-t border-border">
                <h4 className="text-sm font-semibold mb-4 text-foreground flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-primary" /> Relative & Recommended Titles
                </h4>
                <BookGrid books={relativeBooks.length > 0 ? relativeBooks : recommendedBooks.slice(0, 4)} loading={false} />
              </div>
            )}
          </div>
        )
      ) : (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-bold tracking-tight text-foreground">
              Trending Bestsellers to Explore
            </h2>
            <p className="text-sm text-muted-foreground">
              Discover timeless ideas, startup playbooks, and billionaire recommendations.
            </p>
          </div>
          <BookGrid books={recommendedBooks} loading={recommendedBooks.length === 0} />
        </div>
      )}
    </div>
  );
};

export default SearchPage;
