
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, ArrowLeft, Star, MessageSquare, Headphones, Bookmark, Infinity as InfinityIcon } from "lucide-react";
import { toast } from "sonner";
import { subscriptionPlans, subscriptionService } from "@/services/subscriptionService";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useAuth } from "@/context/AuthContext";

const SubscriptionPage = () => {
  const [loading, setLoading] = useState<string | null>(null);
  const currentPlan = subscriptionService.getCurrentPlan();
  const daysRemaining = subscriptionService.getDaysRemaining();
  const booksRemaining = subscriptionService.getBooksRemaining();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    // Persist authentication state to localStorage to avoid flashing
    if (!authLoading) {
      localStorage.setItem('isLoggedIn', isAuthenticated ? 'true' : 'false');
    }
  }, [isAuthenticated, authLoading]);
  
  if (authLoading) {
    return (
      <div className="container py-12 flex items-center justify-center">
        <div className="h-8 w-8 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="container py-8 animate-fade-in">
      <Link to="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Home
      </Link>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Star className="h-6 w-6 text-primary" />
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">Everything Unlimited & Free!</h1>
          </div>
          <p className="text-xl text-muted-foreground">
            All features are now completely free and unlimited for everyone
          </p>
        </div>

        <div className="flex justify-center">
          <Card className="w-full max-w-md border-primary border-2 bg-gradient-to-b from-background to-primary/5">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl">Unlimited Free Plan</CardTitle>
                <InfinityIcon className="h-5 w-5 text-primary" />
              </div>
              <CardDescription>
                Everything you need, completely free forever
              </CardDescription>
              <div className="mt-2">
                <span className="text-3xl font-bold">$0</span>
                <span className="text-muted-foreground ml-1">/forever</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <InfinityIcon className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>Unlimited book access</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>Unlimited AI summaries</span>
                </li>
                <li className="flex items-start">
                  <MessageSquare className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>Unlimited AI chat messages</span>
                </li>
                <li className="flex items-start">
                  <Headphones className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>Audio summaries included</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>All premium features</span>
                </li>
                <li className="flex items-start">
                  <Star className="h-5 w-5 text-primary flex-shrink-0 mr-2" />
                  <span>No limits, no restrictions</span>
                </li>
              </ul>
              
              <div className="mt-6 p-4 bg-primary/10 rounded-lg">
                <p className="text-sm font-medium">Current Status:</p>
                <p className="text-sm text-muted-foreground">
                  All features: Unlimited ∞
                </p>
                <p className="text-sm text-muted-foreground">
                  Enjoy completely free access!
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                disabled={true}
              >
                Active Plan ✨
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-16 text-center text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Star className="h-4 w-4" />
            <p className="font-medium">All Features Unlocked</p>
          </div>
          <p className="mb-2">
            Every feature in BookWhisper is now completely free and unlimited.
          </p>
          <p className="text-sm">
            Questions? Contact <a href="#" className="text-primary underline">support@bookwhisper.com</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPage;
