import { useState, useEffect } from "react";
import {
  User,
  Settings,
  HelpCircle,
  LogOut,
  Moon,
  Sun,
  BookOpen,
  FileText,
  Clock,
  MessageSquare,
  Flame,
  Volume2,
  Download,
  CheckCircle2,
  Lock,
  Mail,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Sliders,
  Bookmark
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { useNavigate, Link } from "react-router-dom";
import { subscriptionService } from "@/services/subscriptionService";
import { toast } from "sonner";
import { savedBooksService } from "@/services/savedBooksService";
import { Book } from "@/services/bookService";
import { useAuth } from "@/context/AuthContext";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { audioNarrationService } from "@/services/audioNarrationService";

const ProfilePage = () => {
  const { user, isAuthenticated, signOut, signInWithGmail, openAuthModal } = useAuth();
  const navigate = useNavigate();

  // Theme state
  const [darkMode, setDarkMode] = useState(() => {
    return (
      localStorage.getItem("theme") === "dark" ||
      (!localStorage.getItem("theme") &&
        window.matchMedia("(prefers-color-scheme: dark)").matches)
    );
  });

  // Reading Stats
  const [readingTime, setReadingTime] = useState(() => {
    return parseInt(localStorage.getItem("readingTime") || "35", 10);
  });
  const [readingGoal, setReadingGoal] = useState(() => {
    return parseInt(localStorage.getItem("reading_daily_goal") || "30", 10);
  });
  const [streakDays, setStreakDays] = useState(() => {
    return parseInt(localStorage.getItem("reading_streak_days") || "4", 10);
  });

  // Audio settings
  const [audioSpeed, setAudioSpeed] = useState(() => {
    return localStorage.getItem("bookwhisper_narration_rate") || "1.0";
  });
  const [audioMinutes, setAudioMinutes] = useState(() => {
    return parseInt(localStorage.getItem("bookwhisper_audio_minutes") || "18", 10);
  });

  // Saved books & notes
  const [savedBooks, setSavedBooks] = useState<Book[]>([]);
  const [notesCount, setNotesCount] = useState(0);

  // Quick Gmail input for unauthenticated view
  const [quickEmail, setQuickEmail] = useState("");
  const [signingIn, setSigningIn] = useState(false);

  const currentPlan = subscriptionService.getCurrentPlan();

  useEffect(() => {
    loadProfileData();

    const handleSavedChange = () => {
      loadProfileData();
    };

    window.addEventListener("bookwhisper:saved_books_changed", handleSavedChange);
    return () => {
      window.removeEventListener("bookwhisper:saved_books_changed", handleSavedChange);
    };
  }, [user]);

  const loadProfileData = async () => {
    try {
      const books = await savedBooksService.getSavedBooks();
      setSavedBooks(books);
    } catch (e) {
      console.error("Failed to load saved books in profile:", e);
    }

    try {
      const savedNotes = localStorage.getItem("user_notes");
      if (savedNotes) {
        const parsed = JSON.parse(savedNotes);
        setNotesCount(Array.isArray(parsed) ? parsed.length : 0);
      }
    } catch {
      setNotesCount(0);
    }
  };

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);

    if (newMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }

    toast.success(`${newMode ? "Dark" : "Light"} mode activated`);
  };

  const handleUpdateGoal = (mins: number) => {
    setReadingGoal(mins);
    localStorage.setItem("reading_daily_goal", mins.toString());
    toast.success(`Daily reading goal set to ${mins} mins`);
  };

  const handleAddReadingTime = (addedMins: number) => {
    const newTotal = readingTime + addedMins;
    setReadingTime(newTotal);
    localStorage.setItem("readingTime", newTotal.toString());
    toast.success(`Added ${addedMins} mins to today's reading activity!`);
  };

  const handleAudioSpeedChange = (speed: string) => {
    setAudioSpeed(speed);
    localStorage.setItem("bookwhisper_narration_rate", speed);
    toast.success(`Audible narration speed set to ${speed}x`);
  };

  const handleTestAudio = () => {
    try {
      const rateNum = parseFloat(audioSpeed) || 1.0;
      audioNarrationService.playText(
        "Welcome to BookWhisper. Your Audible narration is working at " + audioSpeed + "x speed."
      );
      toast.info("Playing audio preview...");
    } catch (err) {
      console.error(err);
      toast.error("Audio playback not supported on this browser.");
    }
  };

  const handleQuickSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickEmail.trim()) {
      toast.error("Please enter a valid Gmail address");
      return;
    }
    setSigningIn(true);
    try {
      await signInWithGmail(quickEmail.trim());
      setQuickEmail("");
      loadProfileData();
    } catch (err: any) {
      toast.error(err.message || "Failed to sign in");
    } finally {
      setSigningIn(false);
    }
  };

  const handleSignOut = () => {
    signOut();
    toast.success("Signed out successfully");
  };

  // Export Library & Notes as JSON backup
  const handleExportData = () => {
    try {
      const notes = localStorage.getItem("user_notes") || "[]";
      const exportObject = {
        exportedAt: new Date().toISOString(),
        user: user?.email || "Guest",
        readingTimeMinutes: readingTime,
        readingGoalMinutes: readingGoal,
        streakDays,
        savedBooks: savedBooks.map((b) => ({
          id: b.id,
          title: b.title,
          authors: b.authors,
          categories: b.categories,
        })),
        notes: JSON.parse(notes),
      };

      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObject, null, 2));
      const downloadAnchor = document.createElement("a");
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute(
        "download",
        `bookwhisper_backup_${new Date().toISOString().slice(0, 10)}.json`
      );
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();

      toast.success("Library backup exported successfully!");
    } catch (err) {
      console.error(err);
      toast.error("Failed to export backup file.");
    }
  };

  const progressPercent = Math.min(Math.round((readingTime / readingGoal) * 100), 100);

  return (
    <div className="container py-8 max-w-4xl mx-auto px-4 sm:px-6 animate-fade-in space-y-6">
      {/* Header title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-foreground">Reader Profile</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your bookshelf, reading goals, audio speed, and account.
          </p>
        </div>

        {isAuthenticated && (
          <Button variant="outline" size="sm" onClick={handleSignOut} className="text-destructive hover:bg-destructive/10 shrink-0">
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        )}
      </div>

      {/* Profile Card / Auth Status Banner */}
      {isAuthenticated && user ? (
        <Card className="p-6 bg-gradient-to-br from-card via-card to-primary/5 border border-primary/20 shadow-sm rounded-2xl">
          <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center font-bold text-2xl shadow-md shrink-0">
                {user.email ? user.email.slice(0, 2).toUpperCase() : "BW"}
              </div>
              <div>
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h2 className="text-xl font-bold text-foreground">
                    {user.email?.split("@")[0] || "Book Enthusiast"}
                  </h2>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                    <CheckCircle2 className="h-3 w-3" /> Verified Gmail
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-0.5 flex items-center justify-center sm:justify-start gap-1">
                  <Mail className="h-3.5 w-3.5" /> {user.email}
                </p>
                <div className="mt-2 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <span className="text-xs px-2.5 py-1 rounded-full bg-primary/10 text-primary font-medium">
                    {currentPlan.name} Member
                  </span>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground font-medium">
                    {savedBooks.length} Books in Library
                  </span>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => openAuthModal("Switch or re-verify your Gmail account")}
              className="text-xs rounded-xl"
            >
              Switch Account
            </Button>
          </div>
        </Card>
      ) : (
        <Card className="p-6 bg-gradient-to-br from-amber-500/10 via-background to-secondary/30 border border-amber-500/30 shadow-sm rounded-2xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Lock className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-foreground">
                  Sign in with Gmail to sync library & unlock Buy deals
                </h3>
                <p className="text-xs text-muted-foreground mt-1 max-w-md">
                  Keep your saved books, notes, and reading streaks saved across all devices. Plus unlock verified book purchase options.
                </p>
              </div>
            </div>

            <form onSubmit={handleQuickSignIn} className="w-full md:w-auto flex flex-col sm:flex-row items-center gap-2">
              <Input
                type="email"
                placeholder="your.email@gmail.com"
                value={quickEmail}
                onChange={(e) => setQuickEmail(e.target.value)}
                className="w-full sm:w-64 text-sm bg-background"
                required
              />
              <Button type="submit" disabled={signingIn} className="w-full sm:w-auto bg-amber-600 hover:bg-amber-700 text-white font-semibold shrink-0">
                {signingIn ? "Signing In..." : "1-Click Sign In"}
              </Button>
            </form>
          </div>
        </Card>
      )}

      {/* Feature Section 1: Daily Reading Goal & Streak Tracker */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Streak card */}
        <Card className="p-5 rounded-2xl border bg-card shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Reading Streak</div>
            <div className="text-3xl font-extrabold flex items-center gap-2 text-foreground">
              {streakDays} <span className="text-sm font-semibold text-muted-foreground">Days</span>
            </div>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">Keep the momentum going!</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
            <Flame className="h-7 w-7" />
          </div>
        </Card>

        {/* Today's Reading Time */}
        <Card className="p-5 rounded-2xl border bg-card shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Today's Reading</div>
            <div className="text-3xl font-extrabold flex items-center gap-2 text-foreground">
              {readingTime} <span className="text-sm font-semibold text-muted-foreground">mins</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <button
                onClick={() => handleAddReadingTime(5)}
                className="text-[11px] font-semibold px-2 py-0.5 rounded bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
              >
                +5m
              </button>
              <button
                onClick={() => handleAddReadingTime(15)}
                className="text-[11px] font-semibold px-2 py-0.5 rounded bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
              >
                +15m
              </button>
            </div>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
            <Clock className="h-7 w-7" />
          </div>
        </Card>

        {/* Audible Listening Minutes */}
        <Card className="p-5 rounded-2xl border bg-card shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Audible Listening</div>
            <div className="text-3xl font-extrabold flex items-center gap-2 text-foreground">
              {audioMinutes} <span className="text-sm font-semibold text-muted-foreground">mins</span>
            </div>
            <p className="text-xs text-muted-foreground">Voice narration summaries</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
            <Volume2 className="h-7 w-7" />
          </div>
        </Card>
      </div>

      {/* Goal Progress bar & selector */}
      <Card className="p-6 rounded-2xl border bg-card shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-foreground">Daily Reading Target</h3>
            <p className="text-xs text-muted-foreground">
              {progressPercent >= 100
                ? "🎉 You achieved your daily goal for today!"
                : `${readingGoal - readingTime > 0 ? readingGoal - readingTime : 0} minutes left to hit today's target.`}
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-medium text-muted-foreground mr-1">Goal:</span>
            {[15, 30, 45, 60].map((mins) => (
              <button
                key={mins}
                onClick={() => handleUpdateGoal(mins)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                  readingGoal === mins
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
          <div
            className="bg-primary h-full rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="flex justify-between items-center text-xs font-semibold text-muted-foreground mt-2">
          <span>{readingTime} mins logged</span>
          <span className="text-primary font-bold">{progressPercent}% complete</span>
          <span>{readingGoal} mins goal</span>
        </div>
      </Card>

      {/* Feature Section 2: Audible Voice Narration Settings */}
      <Card className="p-6 rounded-2xl border bg-card shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sliders className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground">Audible Voice Preferences</h3>
              <p className="text-xs text-muted-foreground">
                Set your default listening speed for all book summaries.
              </p>
            </div>
          </div>

          <Button variant="outline" size="sm" onClick={handleTestAudio} className="text-xs gap-1.5">
            <Volume2 className="h-3.5 w-3.5" /> Test Voice
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2">
          {["0.75", "1.0", "1.25", "1.5", "2.0"].map((rate) => (
            <button
              key={rate}
              onClick={() => handleAudioSpeedChange(rate)}
              className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center ${
                audioSpeed === rate
                  ? "border-primary bg-primary/10 text-primary shadow-sm"
                  : "border-border bg-card hover:bg-muted text-muted-foreground"
              }`}
            >
              {rate}x Speed
              <span className="block text-[10px] font-normal text-muted-foreground mt-0.5">
                {rate === "1.0" ? "Normal" : rate === "1.25" ? "Popular" : rate === "2.0" ? "Speed run" : "Paced"}
              </span>
            </button>
          ))}
        </div>
      </Card>

      {/* Feature Section 3: Interactive Saved Bookshelf Preview with BUY buttons */}
      <Card className="p-6 rounded-2xl border bg-card shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground">My Saved Bookshelf</h3>
              <p className="text-xs text-muted-foreground">
                {savedBooks.length} book{savedBooks.length === 1 ? "" : "s"} saved to your library.
              </p>
            </div>
          </div>

          <Button variant="ghost" size="sm" onClick={() => navigate("/library")} className="text-xs">
            Open Library <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        {savedBooks.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {savedBooks.slice(0, 4).map((book) => (
              <div
                key={book.id}
                className="flex items-center gap-3 p-3 rounded-xl border border-border bg-muted/30 hover:bg-muted/60 transition-colors"
              >
                <img
                  src={book.thumbnail}
                  alt={book.title}
                  className="w-12 h-16 object-cover rounded-md shadow-sm shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-foreground line-clamp-1">{book.title}</h4>
                  <p className="text-[11px] text-muted-foreground line-clamp-1">{book.authors?.join(", ")}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-[11px] px-2"
                      onClick={() => navigate(`/book/${book.id}`)}
                    >
                      Read
                    </Button>
                    <AmazonBuyButton
                      bookTitle={book.title}
                      author={book.authors?.[0]}
                      bookId={book.id}
                      thumbnail={book.thumbnail}
                      variant="compact"
                      size="sm"
                      className="h-7"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 px-4 rounded-xl border border-dashed border-border bg-muted/10">
            <Bookmark className="h-8 w-8 text-muted-foreground mx-auto mb-2 opacity-50" />
            <p className="text-sm font-medium text-foreground">No saved books yet</p>
            <p className="text-xs text-muted-foreground mt-0.5 mb-4">
              Explore summaries and save your favorite titles to read later.
            </p>
            <Button size="sm" onClick={() => navigate("/explore")}>
              Explore Books
            </Button>
          </div>
        )}
      </Card>

      {/* Feature Section 4: Quick Navigation & Shortcuts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Notes shortcut */}
        <Card
          onClick={() => navigate("/notes")}
          className="p-4 rounded-2xl border bg-card hover:bg-muted/30 transition-all cursor-pointer flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-foreground">My Reading Notes</h4>
              <p className="text-xs text-muted-foreground">{notesCount} personal key takeaways</p>
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </Card>

        {/* AI Features shortcut */}
        <Card
          onClick={() => navigate("/ai-features")}
          className="p-4 rounded-2xl border bg-card hover:bg-muted/30 transition-all cursor-pointer flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <MessageSquare className="h-5 w-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-foreground">AI Whisper Assistant</h4>
              <p className="text-xs text-muted-foreground">Ask questions & generate mind maps</p>
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </Card>
      </div>

      {/* Feature Section 5: Preferences & Data Backup */}
      <Card className="rounded-2xl border bg-card shadow-sm overflow-hidden">
        <div className="p-4 flex items-center justify-between hover:bg-muted/20 transition-colors">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-muted flex items-center justify-center">
              {darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">Dark Theme</div>
              <div className="text-xs text-muted-foreground">Switch between light and dark modes</div>
            </div>
          </div>
          <Switch checked={darkMode} onCheckedChange={toggleDarkMode} />
        </div>

        <Separator />

        <div
          onClick={handleExportData}
          className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <Download className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">Export Library & Notes Backup</div>
              <div className="text-xs text-muted-foreground">Download all your saved books and notes as JSON</div>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-xs">
            Export
          </Button>
        </div>

        <Separator />

        <div
          onClick={() => navigate("/settings")}
          className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-muted flex items-center justify-center">
              <Settings className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <div className="text-sm font-medium text-foreground">App Settings</div>
              <div className="text-xs text-muted-foreground">Notifications, summaries, and subscription details</div>
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </div>
      </Card>
    </div>
  );
};

export default ProfilePage;
