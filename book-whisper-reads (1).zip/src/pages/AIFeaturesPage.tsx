import React, { useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Sparkles,
  Bot,
  Brain,
  ShieldAlert,
  ArrowLeft,
  BookOpen,
  ChevronRight,
  Layers,
  Flame,
  CheckCircle2,
  ExternalLink
} from "lucide-react";
import ModernAIChat from "@/components/ai/ModernAIChat";
import AIMindMapVisualizer from "@/components/ai/AIMindMapVisualizer";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { CURATED_BOOKS } from "@/services/curatedBooks";

type AIMode = "chat" | "mindmap" | "critique";

const AIFeaturesPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Selected book state
  const initialBook = location.state?.bookTitle
    ? {
        id: location.state?.bookId,
        title: location.state.bookTitle,
        authors: location.state?.author ? [location.state.author] : ["Renowned Author"],
        description: location.state?.description,
        thumbnail: location.state?.thumbnail
      }
    : {
        id: "atomic-habits",
        title: "Atomic Habits",
        authors: ["James Clear"],
        description: "An Easy & Proven Way to Build Good Habits & Break Bad Ones.",
        thumbnail: "https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg"
      };

  const [selectedBook, setSelectedBook] = useState(initialBook);
  const [activeMode, setActiveMode] = useState<AIMode>("chat");

  const modes = [
    {
      id: "chat" as AIMode,
      label: "AI Intelligence Chat",
      icon: Bot,
      tag: "Live Interactive",
      description: "Ask anything, analyze book excerpts, and query concepts"
    },
    {
      id: "mindmap" as AIMode,
      label: "Concept Mind Matrix",
      icon: Brain,
      tag: "Motion Graph",
      description: "Interactive visual synapses and core principles breakdown"
    },
    {
      id: "critique" as AIMode,
      label: "Critical Debate Chamber",
      icon: ShieldAlert,
      tag: "Deep Audit",
      description: "Devil's advocate analysis and practical limitations"
    }
  ];

  const handleBack = () => {
    if (location.state?.fromBookDetail && location.state?.bookDetailPath) {
      navigate(location.state.bookDetailPath);
    } else {
      navigate(-1);
    }
  };

  const critiquePoints = [
    {
      title: "Over-reliance on Incrementalism",
      description:
        "While 1% daily aggregation compounds efficiently in skill acquisition, radical zero-to-one pivot breakthroughs often demand discontinuous leaps rather than micro-iterations."
    },
    {
      title: "Survivorship Bias in System Design",
      description:
        "Success examples frequently highlight winners who maintained rigid habit architectures, without accounting for external systemic tailwinds and serendipity."
    },
    {
      title: "Contextual Rigidity",
      description:
        "Strict habit priming can inadvertently reduce cognitive flexibility in volatile, unpredictable creative environments where opportunistic improvisation is required."
    }
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden pb-16">
      {/* Background Animated Gradient Orbs */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse" />
      <div className="absolute top-40 right-1/4 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="container max-w-6xl mx-auto px-4 pt-6">
        {/* Top Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <Button
              onClick={handleBack}
              variant="outline"
              size="sm"
              className="gap-2 rounded-xl text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back</span>
            </Button>

            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-primary/15 text-primary border border-primary/20">
                <Sparkles className="h-4 w-4" />
              </span>
              <div>
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-foreground flex items-center gap-2">
                  BookWhisper AI Suite
                </h1>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Advanced Cognitive Analysis & Motion Knowledge Engine
                </p>
              </div>
            </div>
          </div>

          {/* Quick Book Switcher Dropdown / Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            <span className="text-xs text-muted-foreground font-medium shrink-0">Focus:</span>
            {CURATED_BOOKS.slice(0, 4).map((b) => (
              <button
                key={b.id}
                onClick={() =>
                  setSelectedBook({
                    id: b.id,
                    title: b.title,
                    authors: b.authors,
                    description: b.description,
                    thumbnail: b.thumbnail
                  })
                }
                className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-all shrink-0 ${
                  selectedBook.title === b.title
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card/70 hover:bg-card border-border/60 text-muted-foreground hover:text-foreground"
                }`}
              >
                {b.title}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Book Banner / Motion Pill */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 p-4 rounded-2xl border border-border/70 bg-gradient-to-r from-card via-card/80 to-background/90 shadow-md backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            {selectedBook.thumbnail && (
              <img
                src={selectedBook.thumbnail}
                alt={selectedBook.title}
                className="w-12 h-16 object-cover rounded-md shadow-md border border-border/50 shrink-0"
              />
            )}
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                  Active Knowledge Focus
                </span>
                <span className="text-xs text-muted-foreground font-mono">
                  {selectedBook.authors.join(", ")}
                </span>
              </div>
              <h2 className="text-lg font-bold text-foreground leading-snug">
                {selectedBook.title}
              </h2>
              <p className="text-xs text-muted-foreground line-clamp-1">
                {selectedBook.description || "Executive literary summary & actionable frameworks."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <AmazonBuyButton
              bookTitle={selectedBook.title}
              author={selectedBook.authors?.[0]}
              bookId={selectedBook.id}
              thumbnail={selectedBook.thumbnail}
              size="sm"
            />
            {selectedBook.id && (
              <Button size="sm" variant="outline" asChild className="text-xs">
                <Link to={`/summary/${selectedBook.id}`}>
                  <BookOpen className="h-3.5 w-3.5 mr-1 text-primary" />
                  Read Summary
                </Link>
              </Button>
            )}
          </div>
        </motion.div>

        {/* Motion Graphic Mode Switcher Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
          {modes.map((mode) => {
            const Icon = mode.icon;
            const isActive = activeMode === mode.id;

            return (
              <motion.button
                key={mode.id}
                onClick={() => setActiveMode(mode.id)}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                className={`relative p-3.5 sm:p-4 rounded-xl text-left border transition-all duration-300 flex flex-col justify-between ${
                  isActive
                    ? "bg-card border-primary/50 shadow-lg shadow-primary/10 ring-1 ring-primary/40"
                    : "bg-card/50 hover:bg-card/80 border-border/60 hover:border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`p-2 rounded-lg border ${
                        isActive
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background border-border/50 text-muted-foreground"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                        isActive
                          ? "bg-primary/10 text-primary border-primary/30"
                          : "bg-background/60 text-muted-foreground border-border/40"
                      }`}
                    >
                      {mode.tag}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-foreground mb-0.5">{mode.label}</h3>
                  <p className="text-[11px] text-muted-foreground line-clamp-1">
                    {mode.description}
                  </p>
                </div>

                {isActive && (
                  <motion.div
                    layoutId="ai-feature-tab"
                    className="absolute -bottom-px inset-x-4 h-0.5 bg-gradient-to-r from-primary via-indigo-500 to-cyan-400"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Active Mode Dynamic Presentation */}
        <AnimatePresence mode="wait">
          {activeMode === "chat" && (
            <motion.div
              key="chat"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <ModernAIChat book={selectedBook} />
            </motion.div>
          )}

          {activeMode === "mindmap" && (
            <motion.div
              key="mindmap"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <AIMindMapVisualizer
                bookTitle={selectedBook.title}
                author={selectedBook.authors.join(", ")}
              />
            </motion.div>
          )}

          {activeMode === "critique" && (
            <motion.div
              key="critique"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <Card className="p-6 rounded-2xl border border-border/70 bg-gradient-to-b from-card to-background shadow-xl">
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-border/50">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="p-1 rounded-md bg-rose-500/10 text-rose-500">
                        <ShieldAlert className="h-4 w-4" />
                      </span>
                      <span className="text-xs font-semibold uppercase tracking-wider text-rose-500">
                        Executive Devil's Advocate & Blindspot Audit
                      </span>
                    </div>
                    <h3 className="text-xl font-bold tracking-tight text-foreground">
                      Critical Audit of "{selectedBook.title}"
                    </h3>
                  </div>

                  <span className="text-xs text-muted-foreground px-3 py-1 rounded-full bg-background border border-border/50">
                    Contrarian Perspective
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
                  {critiquePoints.map((critique, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="p-5 rounded-xl border border-border/60 bg-background/50 hover:bg-background/80 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <span className="text-[11px] font-mono text-muted-foreground block mb-2">
                          CRITIQUE REF #0{idx + 1}
                        </span>
                        <h4 className="font-bold text-base text-foreground mb-2">
                          {critique.title}
                        </h4>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          {critique.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-border/40 text-[11px] text-primary font-medium flex items-center gap-1">
                        <span>How to mitigate this risk</span>
                        <ChevronRight className="h-3 w-3" />
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Brain className="h-5 w-5 text-primary shrink-0" />
                    <p className="text-xs text-foreground/80 leading-relaxed">
                      Want to debate counter-arguments with AI? Switch to AI Chat and ask{" "}
                      <span className="font-semibold text-primary">
                        "What is the single strongest argument against this book?"
                      </span>
                    </p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setActiveMode("chat")}
                    className="shrink-0 font-medium"
                  >
                    Debate in AI Chat →
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default AIFeaturesPage;
