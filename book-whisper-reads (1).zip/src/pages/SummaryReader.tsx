import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { getBookById, Book } from "@/services/bookService";
import { generateSummary, Summary } from "@/services/summaryService";
import { getAIKeyPoints } from "@/services/aiService";
import { audioNarrationService, AudioNarrationState } from "@/services/audioNarrationService";
import { savedBooksService } from "@/services/savedBooksService";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  X,
  PlayCircle,
  PauseCircle,
  Headphones,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  Share2,
  CheckCircle,
} from "lucide-react";
import { toast } from "sonner";
import { AmazonBuyButton } from "@/components/AmazonBuyButton";
import { AudiblePlayer } from "@/components/audio/AudiblePlayer";
import { useAuth } from "@/context/AuthContext";

const SummaryReader = () => {
  const { id } = useParams<{ id: string }>();
  const [book, setBook] = useState<Book | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentKeyPoint, setCurrentKeyPoint] = useState(1);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [readingTime, setReadingTime] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [audioState, setAudioState] = useState<AudioNarrationState>(audioNarrationService.getState());
  const [keyPoints, setKeyPoints] = useState<{ insights: string[]; applications: string[] }>({
    insights: [],
    applications: [],
  });
  const [loadingKeyPoints, setLoadingKeyPoints] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const readerContentRef = useRef<HTMLDivElement>(null);

  // Scroll Progress Listener
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const scrollHeight =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (scrollHeight > 0) {
        const progress = Math.min(Math.max(Math.round((scrollTop / scrollHeight) * 100), 0), 100);
        setScrollProgress(progress);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Track active reading time
  useEffect(() => {
    const timerId = window.setInterval(() => {
      setReadingTime((prev) => prev + 1);
    }, 1000);

    return () => {
      clearInterval(timerId);
    };
  }, []);

  // Subscribe to audible narration
  useEffect(() => {
    const unsubscribe = audioNarrationService.subscribe((state) => {
      setAudioState(state);
    });
    return () => {
      unsubscribe();
      // Stop narration on unmount if leaving page
      audioNarrationService.stop();
    };
  }, []);

  // Load Book and Summary
  useEffect(() => {
    const fetchBookAndSummary = async () => {
      if (!id) return;

      setLoading(true);
      try {
        const bookData = await getBookById(id);
        setBook(bookData);

        if (bookData) {
          const saved = await savedBooksService.isBookSaved(bookData.id);
          setIsSaved(saved);
        }

        if (bookData?.description) {
          const summaryData = await generateSummary(bookData.description);
          setSummary(summaryData);

          // Generate AI key points
          setLoadingKeyPoints(true);
          try {
            const aiKeyPoints = await getAIKeyPoints(
              bookData.title,
              bookData.authors.join(", ")
            );
            setKeyPoints(aiKeyPoints);
          } catch (error) {
            console.error("Error generating key points:", error);
          } finally {
            setLoadingKeyPoints(false);
          }
        }
      } catch (error) {
        console.error("Error fetching book for reader:", error);
        toast.error("Failed to load summary. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBookAndSummary();
  }, [id]);

  const formatReadingTime = () => {
    const minutes = Math.floor(readingTime / 60);
    const seconds = readingTime % 60;
    return `${minutes}m ${seconds < 10 ? "0" : ""}${seconds}s`;
  };

  // Estimated reading time remaining based on scroll progress
  const getEstimatedRemainingMinutes = () => {
    const totalWords = summary?.content ? summary.content.split(/\s+/).length : 500;
    const totalMinutes = Math.max(Math.ceil(totalWords / 200), 2); // 200 wpm
    const remainingFraction = Math.max((100 - scrollProgress) / 100, 0);
    const remainingMins = Math.ceil(totalMinutes * remainingFraction);
    return remainingMins <= 0 ? "Finished" : `~${remainingMins} min left`;
  };

  const handleNextKeyPoint = () => {
    if (keyPoints.insights.length > 0 && currentKeyPoint < keyPoints.insights.length) {
      setCurrentKeyPoint(currentKeyPoint + 1);
    }
  };

  const handlePreviousKeyPoint = () => {
    if (currentKeyPoint > 1) {
      setCurrentKeyPoint(currentKeyPoint - 1);
    }
  };

  const { isAuthenticated, openAuthModal } = useAuth();

  // Working Audible audio playback
  const handleToggleAudio = () => {
    if (!book || !summary) return;

    if (!isAuthenticated) {
      toast.info("Sign in or sign up to unlock AI Voice Narration.");
      openAuthModal("Sign in or sign up with Gmail to unlock Audible Voice Narration");
      return;
    }

    if (audioState.isPlaying && !audioState.isPaused) {
      audioNarrationService.pause();
      toast.info("Audible playback paused");
    } else if (audioState.isPaused) {
      audioNarrationService.resume();
      toast.info("Audible playback resumed");
    } else {
      // Build speech script
      const speechScript = `Summary of ${book.title} by ${book.authors.join(", ")}. ${summary.content}. Key takeaway: ${getKeyInsight(currentKeyPoint)}`;
      audioNarrationService.playText(speechScript, `${book.title} Summary`);
      toast.success("Playing Audible narration...");
    }
  };

  const handleToggleSave = async () => {
    if (!book) return;
    if (isSaved) {
      const res = await savedBooksService.removeBook(book.id);
      if (res) setIsSaved(false);
    } else {
      const res = await savedBooksService.saveBook(book);
      if (res) setIsSaved(true);
    }
  };

  const handleShare = () => {
    if (navigator.share && book) {
      navigator.share({
        title: book.title,
        text: `Reading summary of "${book.title}" on BookWhisper`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  const handleBack = () => {
    if (location.state?.fromBookDetail && location.state?.bookDetailPath) {
      navigate(location.state.bookDetailPath);
    } else {
      navigate(`/book/${id}`);
    }
  };

  const getKeyInsight = (pointNumber: number) => {
    if (keyPoints.insights.length > 0) {
      return keyPoints.insights[pointNumber - 1] || keyPoints.insights[0];
    }
    return "Focus on incremental improvement and core habits every single day.";
  };

  const getApplicationIdea = (pointNumber: number) => {
    if (keyPoints.applications.length > 0) {
      return keyPoints.applications[pointNumber - 1] || keyPoints.applications[0];
    }
    return "Apply this takeaway to your daily workflow and personal review routine.";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-3xl p-8 border border-border shadow-lg">
          <Skeleton className="h-8 w-3/4 mb-4" />
          <Skeleton className="h-4 w-1/3 mb-8" />
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        </Card>
      </div>
    );
  }

  if (!book || !summary) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-xl p-8 text-center border border-border shadow-lg">
          <h1 className="text-2xl font-bold mb-2">Summary not available</h1>
          <p className="text-muted-foreground mb-6">
            We couldn't generate a summary for this book right now.
          </p>
          <Button onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Book
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/20 pb-28">
      {/* =========================================================================
          VISUAL READING PROGRESS INDICATOR (STICKY AT TOP)
          Tracks scroll position in real time as user scrolls through the content.
         ========================================================================= */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border shadow-sm">
        {/* Dynamic Progress Bar */}
        <div className="w-full bg-muted/60 h-1.5 relative overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-500 via-primary to-emerald-500 transition-all duration-150 ease-out"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        {/* Reader Top Bar Controls */}
        <div className="container max-w-5xl py-2.5 px-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="text-xs h-8 px-2.5 shrink-0"
            >
              <ArrowLeft className="h-3.5 w-3.5 mr-1" />
              Back
            </Button>
            <div className="min-w-0 hidden sm:block">
              <h1 className="text-xs font-semibold truncate text-foreground">{book.title}</h1>
              <span className="text-[10px] text-muted-foreground truncate block">
                {book.authors.join(", ")}
              </span>
            </div>
          </div>

          {/* Center: Real-time visual progress indicator badge */}
          <div className="flex items-center gap-2 bg-muted/50 border border-border/60 px-3 py-1 rounded-full text-xs font-medium">
            <span className="flex items-center gap-1.5 text-primary">
              <BookOpen className="h-3.5 w-3.5" />
              <span className="font-bold tabular-nums">{scrollProgress}%</span>
            </span>
            <span className="text-muted-foreground text-[10px] hidden md:inline">
              • {getEstimatedRemainingMinutes()}
            </span>
            <span className="text-muted-foreground text-[10px] hidden lg:inline">
              • Time: {formatReadingTime()}
            </span>
          </div>

          {/* Right: Audible Toggle & Buy on Amazon Button */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Audible Button */}
            <Button
              variant={audioState.isPlaying ? "default" : "outline"}
              size="sm"
              onClick={handleToggleAudio}
              className={`h-8 text-xs font-medium ${
                audioState.isPlaying ? "bg-amber-500 hover:bg-amber-600 text-white" : ""
              }`}
              title={audioState.isPlaying ? "Pause Audible narration" : "Listen with Audible"}
            >
              <Headphones className="h-3.5 w-3.5 mr-1 text-amber-500" />
              <span className="hidden sm:inline">
                {audioState.isPlaying && !audioState.isPaused ? "Audible Playing" : "Audible"}
              </span>
            </Button>

            {/* Amazon Affiliate Buy Button */}
            <AmazonBuyButton
              bookTitle={book.title}
              author={book.authors?.[0]}
              bookId={book.id}
              thumbnail={book.thumbnail}
              variant="compact"
              size="sm"
            />

            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggleSave}
              className="h-8 w-8 rounded-lg"
              title={isSaved ? "Saved to Library" : "Save to Library"}
            >
              {isSaved ? (
                <BookmarkCheck className="h-4 w-4 text-primary fill-current" />
              ) : (
                <Bookmark className="h-4 w-4" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              className="h-8 w-8 rounded-lg text-muted-foreground hover:text-foreground"
              title="Close reader"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main ref={readerContentRef} className="flex-1 container max-w-3xl py-8 px-4">
        {/* Book Header Card */}
        <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-card border border-border/80 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-4">
            {book.thumbnail && (
              <img
                src={book.thumbnail}
                alt={book.title}
                className="w-14 h-20 object-cover rounded-lg shadow-sm shrink-0 border border-border"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = "none";
                }}
              />
            )}
            <div>
              <span className="text-[11px] font-bold tracking-wider uppercase text-primary">
                Executive Book Summary
              </span>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground mt-0.5">
                {book.title}
              </h2>
              <p className="text-xs text-muted-foreground mt-1">
                By {book.authors.join(", ")} {book.publishedDate ? `• ${book.publishedDate.substring(0, 4)}` : ""}
              </p>
            </div>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end gap-2 w-full sm:w-auto justify-between sm:justify-start">
            <span className="text-xs text-muted-foreground">Reading Progress:</span>
            <div className="text-sm font-bold text-primary flex items-center gap-1.5">
              <span>{scrollProgress}%</span>
              {scrollProgress >= 100 && <CheckCircle className="h-4 w-4 text-emerald-500" />}
            </div>
          </div>
        </div>

        {/* Audible Announcement Bar */}
        <div className="mb-6 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30 rounded-xl p-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Headphones className="h-4 w-4" />
            </div>
            <div className="text-xs">
              <span className="font-semibold text-foreground">Audible Voice Reader Ready:</span>{" "}
              <span className="text-muted-foreground">
                Listen hands-free with speed control & sentence tracking.
              </span>
            </div>
          </div>
          <Button
            size="sm"
            onClick={handleToggleAudio}
            className="text-xs font-semibold bg-amber-500 hover:bg-amber-600 text-white shrink-0"
          >
            {audioState.isPlaying && !audioState.isPaused ? (
              <>
                <PauseCircle className="h-3.5 w-3.5 mr-1" /> Pause
              </>
            ) : (
              <>
                <PlayCircle className="h-3.5 w-3.5 mr-1" /> Listen
              </>
            )}
          </Button>
        </div>

        {/* Summary Card */}
        <Card className="p-6 sm:p-10 shadow-md border border-border bg-card rounded-2xl">
          <div className="prose prose-sm sm:prose max-w-none text-foreground/90">
            <div className="leading-relaxed whitespace-pre-line text-base text-foreground/90 space-y-4 font-normal">
              {summary.content}
            </div>

            {summary.isGenerated && (
              <p className="text-xs text-muted-foreground mt-8 pt-4 border-t border-border/50">
                Curated & formatted executive summary powered by BookWhisper insights.
              </p>
            )}
          </div>

          {/* Interactive Key Takeaways Section */}
          <div className="mt-8 pt-8 border-t border-border">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-foreground">Core Takeaways & Practice</h3>
                <p className="text-xs text-muted-foreground">
                  Actionable insights from {book.title}
                </p>
              </div>
              <span className="text-xs font-semibold text-primary px-2.5 py-1 bg-primary/10 rounded-full">
                Point {currentKeyPoint} of {keyPoints.insights.length || 7}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-muted/40 p-5 rounded-xl border border-border/60">
                <p className="text-xs font-bold uppercase tracking-wider text-primary">Key Insight</p>
                <div className="mt-2.5 flex items-start gap-3">
                  <span className="bg-primary text-primary-foreground w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {currentKeyPoint}
                  </span>
                  <p className="text-sm font-medium leading-relaxed text-foreground">
                    {getKeyInsight(currentKeyPoint)}
                  </p>
                </div>
              </div>

              <div className="bg-muted/40 p-5 rounded-xl border border-border/60">
                <p className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Application Idea
                </p>
                <div className="mt-2.5 flex items-start gap-3">
                  <div className="h-6 w-6 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                    <BookOpen className="h-3.5 w-3.5" />
                  </div>
                  <p className="text-sm font-medium leading-relaxed text-foreground">
                    {getApplicationIdea(currentKeyPoint)}
                  </p>
                </div>
              </div>
            </div>

            {/* Stepper buttons */}
            <div className="flex items-center justify-between mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePreviousKeyPoint}
                disabled={currentKeyPoint <= 1}
                className="text-xs"
              >
                <ChevronLeft className="h-3.5 w-3.5 mr-1" />
                Previous Point
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleNextKeyPoint}
                disabled={currentKeyPoint >= (keyPoints.insights.length || 7)}
                className="text-xs"
              >
                Next Point
                <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Amazon Partner Buy Banner (End of reading section) */}
        <div className="mt-8">
          <AmazonBuyButton
            bookTitle={book.title}
            author={book.authors?.[0]}
            bookId={book.id}
            thumbnail={book.thumbnail}
            variant="banner"
          />
        </div>
      </main>

      {/* Floating Audible Player Bar (When audio is active) */}
      <AudiblePlayer />

      {/* Persistent Bottom Bar with reading navigation & actions */}
      <footer className="fixed bottom-0 left-0 right-0 py-3 px-4 border-t bg-background/95 backdrop-blur-md z-30 shadow-md">
        <div className="container max-w-3xl flex justify-between items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousKeyPoint}
            disabled={currentKeyPoint <= 1}
            className="text-xs"
          >
            <ChevronLeft className="mr-1 h-3.5 w-3.5" />
            Previous
          </Button>

          {/* Center: Audible Quick Button & Reading % */}
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleToggleAudio}
              className="rounded-full text-xs font-semibold gap-1.5"
            >
              {audioState.isPlaying && !audioState.isPaused ? (
                <PauseCircle className="h-5 w-5 text-amber-500 fill-amber-500/20" />
              ) : (
                <PlayCircle className="h-5 w-5 text-amber-500" />
              )}
              <span className="hidden sm:inline">
                {audioState.isPlaying ? "Playing Audible" : "Listen"}
              </span>
            </Button>

            <span className="text-xs text-muted-foreground font-medium tabular-nums">
              Point {currentKeyPoint} of {keyPoints.insights.length || 7} • {scrollProgress}%
            </span>
          </div>

          <div className="flex items-center gap-2">
            <AmazonBuyButton
              bookTitle={book.title}
              author={book.authors?.[0]}
              bookId={book.id}
              thumbnail={book.thumbnail}
              variant="compact"
              size="sm"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={handleNextKeyPoint}
              disabled={currentKeyPoint >= (keyPoints.insights.length || 7)}
              className="text-xs"
            >
              Next
              <ChevronRight className="ml-1 h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default SummaryReader;
