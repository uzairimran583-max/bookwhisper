
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { Book, getBooksByCategory } from "@/services/bookService";
import BookGrid from "@/components/BookGrid";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

const CollectionPage = () => {
  const { id } = useParams<{ id: string }>();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  
  const collectionData = {
    "career": {
      title: "Workplace Pro's Strategies for CAREER",
      description: "Build your professional skills with these essential guides",
      category: "Business"
    },
    "effective": {
      title: "The Key Habits of HIGHLY EFFECTIVE",
      description: "Proven methods for personal effectiveness and productivity",
      category: "Self-Help" 
    }
  };
  
  // Define the collection info based on the ID
  const currentCollection = id && id in collectionData 
    ? collectionData[id as keyof typeof collectionData]
    : { title: "Collection", description: "Books curated for you", category: "Self-Help" };

  useEffect(() => {
    const fetchCollectionBooks = async () => {
      setLoading(true);
      try {
        // Fetch books based on the collection category
        const fetchedBooks = await getBooksByCategory(currentCollection.category);
        setBooks(fetchedBooks);
      } catch (error) {
        console.error("Error fetching collection books:", error);
        toast.error("Failed to load collection books. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchCollectionBooks();
  }, [id, currentCollection.category]);

  return (
    <div className="container py-6 animate-fade-in">
      <Link to="/" className="inline-flex items-center mb-4 text-sm">
        <ArrowLeft className="mr-1 h-4 w-4" />
        Back to home
      </Link>
      
      <h1 className="text-2xl font-bold mb-2">{currentCollection.title}</h1>
      <p className="text-muted-foreground mb-6">{currentCollection.description}</p>
      
      <BookGrid books={books} loading={loading} />
    </div>
  );
};

export default CollectionPage;
