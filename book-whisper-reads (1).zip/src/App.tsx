
import * as React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Layout from "./components/Layout";
import HomePage from "./pages/HomePage";
import SearchPage from "./pages/SearchPage";
import BookDetailPage from "./pages/BookDetailPage";
import SummaryReader from "./pages/SummaryReader";
import ComprehensiveSummaryPage from "./pages/ComprehensiveSummaryPage";
import NotFound from "./pages/NotFound";
import ExplorePage from "./pages/ExplorePage";
import LibraryPage from "./pages/LibraryPage";
import ProfilePage from "./pages/ProfilePage";
import SignUpPage from "./pages/SignUpPage";
import LoginPage from "./pages/LoginPage";
import AIFeaturesPage from "./pages/AIFeaturesPage";
import SubscriptionPage from "./pages/SubscriptionPage";
import CollectionPage from "./pages/CollectionPage";
import NotesPage from "./pages/NotesPage";
import SettingsPage from "./pages/SettingsPage";
import DiaryPage from "./pages/DiaryPage";
import MobileBookRecommendations from "./components/MobileBookRecommendations";
import { StrictMode } from "react";
import { AuthProvider } from "./context/AuthContext";
import { RequireAuth } from "./components/RequireAuth";

// Route tracker component to help with route persistence
const RouteTracker = () => {
  const location = useLocation();
  
  useEffect(() => {
    // Store paths in session storage to help with route recovery
    // Only store main routes (not 404 pages)
    if (!location.pathname.includes('404')) {
      sessionStorage.setItem('lastValidRoute', location.pathname + location.search);
    }
    console.log("Current route:", location.pathname); // Debug log for route tracking
  }, [location]);
  
  return null;
};

// Create a new QueryClient instance with better configuration
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 2,
      staleTime: 5 * 60 * 1000,
      gcTime: 10 * 60 * 1000,
    },
  },
});

const App = () => {
  return (
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AuthProvider>
            <TooltipProvider>
              <RouteTracker />
              <Routes>
                <Route element={<Layout />}>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/search" element={<SearchPage />} />
                  <Route path="/book/:id" element={<BookDetailPage />} />
                  <Route path="/explore" element={<ExplorePage />} />
                  <Route path="/mobile-recommendations" element={<MobileBookRecommendations />} />
                  <Route path="/collection/:id" element={<CollectionPage />} />
                  <Route 
                    path="/library" 
                    element={
                      <RequireAuth feature="Your Saved Library">
                        <LibraryPage />
                      </RequireAuth>
                    } 
                  />
                  <Route 
                    path="/profile" 
                    element={
                      <RequireAuth feature="Your Reading Profile">
                        <ProfilePage />
                      </RequireAuth>
                    } 
                  />
                  <Route 
                    path="/ai-features" 
                    element={
                      <RequireAuth feature="AI Literary Intelligence & Chat">
                        <AIFeaturesPage />
                      </RequireAuth>
                    } 
                  />
                  <Route path="/subscription" element={<SubscriptionPage />} />
                  <Route 
                    path="/notes" 
                    element={
                      <RequireAuth feature="Personal Reading Notes">
                        <NotesPage />
                      </RequireAuth>
                    } 
                  />
                  <Route path="/settings" element={<SettingsPage />} />
                  <Route 
                    path="/diary" 
                    element={
                      <RequireAuth feature="Your Reading Diary">
                        <DiaryPage />
                      </RequireAuth>
                    } 
                  />
                </Route>
                <Route 
                  path="/reader/:id" 
                  element={
                    <RequireAuth feature="AI Book Summary">
                      <SummaryReader />
                    </RequireAuth>
                  } 
                />
                <Route 
                  path="/comprehensive-summary/:id" 
                  element={
                    <RequireAuth feature="Deep Chapter-by-Chapter Analysis">
                      <ComprehensiveSummaryPage />
                    </RequireAuth>
                  } 
                />
                <Route 
                  path="/signup" 
                  element={
                    <RequireAuth requireAuth={false} showModal={false}>
                      <SignUpPage />
                    </RequireAuth>
                  } 
                />
                <Route 
                  path="/login" 
                  element={
                    <RequireAuth requireAuth={false} showModal={false}>
                      <LoginPage />
                    </RequireAuth>
                  } 
                />
                <Route path="*" element={<NotFound />} />
              </Routes>
              <Toaster />
              <Sonner position="top-right" closeButton theme="light" />
            </TooltipProvider>
          </AuthProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </React.StrictMode>
  );
};

export default App;
