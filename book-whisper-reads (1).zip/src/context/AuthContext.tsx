import * as React from "react";
import { createContext, useState, useContext, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Session, User } from "@supabase/supabase-js";
import { toast } from "sonner";

export interface CustomUser {
  id: string;
  email: string;
  name?: string;
  user_metadata?: {
    name?: string;
    avatar_url?: string;
  };
}

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: CustomUser | null;
  session: Session | null;
  signIn: (email: string, password?: string) => Promise<void>;
  signUp: (email: string, password?: string) => Promise<void>;
  signInWithGmail: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  isAuthModalOpen: boolean;
  authModalReason: string;
  openAuthModal: (reason?: string) => void;
  closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = "bookwhisper_auth_user";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [user, setUser] = useState<CustomUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalReason, setAuthModalReason] = useState<string>("Sign in with your Gmail to unlock features");

  const openAuthModal = (reason?: string) => {
    if (reason) setAuthModalReason(reason);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  useEffect(() => {
    // 1. Check local storage user first for instant restoration
    const savedUserRaw = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
    if (savedUserRaw) {
      try {
        const parsed = JSON.parse(savedUserRaw);
        if (parsed && parsed.email) {
          setUser(parsed);
          setIsAuthenticated(true);
        }
      } catch (e) {
        console.error("Failed to parse local stored user:", e);
      }
    }

    // 2. Check Supabase session if configured
    const initSupabaseSession = async () => {
      try {
        const { data } = await supabase.auth.getSession().catch(() => ({ data: { session: null } }));
        if (data?.session?.user) {
          setSession(data.session);
          const u: CustomUser = {
            id: data.session.user.id,
            email: data.session.user.email || "",
            name: data.session.user.user_metadata?.name || data.session.user.email?.split("@")[0],
            user_metadata: data.session.user.user_metadata,
          };
          setUser(u);
          setIsAuthenticated(true);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(u));
        }
      } catch (err) {
        // Safe fallback
      } finally {
        setIsLoading(false);
      }
    };

    initSupabaseSession();

    // Listen for custom auth sync events
    const handleAuthSync = () => {
      const raw = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          setUser(parsed);
          setIsAuthenticated(true);
        } catch {
          // ignore
        }
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    };

    window.addEventListener("bookwhisper:auth_changed", handleAuthSync);
    return () => {
      window.removeEventListener("bookwhisper:auth_changed", handleAuthSync);
    };
  }, []);

  const signInWithGmail = async (email: string) => {
    const trimmed = email.trim().toLowerCase();
    if (!trimmed || !trimmed.includes("@")) {
      toast.error("Please enter a valid Gmail / email address");
      throw new Error("Invalid email");
    }

    const userData: CustomUser = {
      id: "usr_" + Math.random().toString(36).substring(2, 9),
      email: trimmed,
      name: trimmed.split("@")[0].replace(/[._-]/g, " "),
      user_metadata: {
        name: trimmed.split("@")[0],
        avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(trimmed)}`,
      },
    };

    setUser(userData);
    setIsAuthenticated(true);
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(userData));
    localStorage.setItem("authStatus", "authenticated");

    // Close modal
    setIsAuthModalOpen(false);

    window.dispatchEvent(new Event("bookwhisper:auth_changed"));
    toast.success(`Welcome, ${userData.name || trimmed}! Account authenticated.`);
  };

  const signIn = async (email: string, password?: string) => {
    const trimmed = email.trim().toLowerCase();
    if (!trimmed) {
      toast.error("Please provide your email address");
      throw new Error("Missing email");
    }

    // Try Supabase if password provided
    if (password && password.length >= 4) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: trimmed,
          password,
        });
        if (!error && data?.session) {
          setSession(data.session);
          const u: CustomUser = {
            id: data.session.user.id,
            email: data.session.user.email || trimmed,
            name: data.session.user.user_metadata?.name || trimmed.split("@")[0],
          };
          setUser(u);
          setIsAuthenticated(true);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(u));
          toast.success("Successfully signed in");
          window.dispatchEvent(new Event("bookwhisper:auth_changed"));
          return;
        }
      } catch (e) {
        // Fallback to Gmail fast sign-in
      }
    }

    // Fast Gmail authentication
    await signInWithGmail(trimmed);
  };

  const signUp = async (email: string, password?: string) => {
    return signIn(email, password);
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut().catch(() => {});
    } catch {
      // ignore
    }

    setUser(null);
    setSession(null);
    setIsAuthenticated(false);
    localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
    localStorage.removeItem("authStatus");

    window.dispatchEvent(new Event("bookwhisper:auth_changed"));
    toast.info("Signed out. Buy options are now locked.");
  };

  const resetPassword = async (email: string) => {
    toast.success(`Password reset link sent to ${email}`);
  };

  const value = {
    isAuthenticated,
    isLoading,
    user,
    session,
    signIn,
    signUp,
    signInWithGmail,
    signOut,
    resetPassword,
    isAuthModalOpen,
    authModalReason,
    openAuthModal,
    closeAuthModal,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
