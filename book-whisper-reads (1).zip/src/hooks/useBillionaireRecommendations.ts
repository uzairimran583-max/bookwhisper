import { useState, useEffect, useCallback } from "react";
import { BookItem, allBillionaireRecommendations } from "@/data/billionaireRecommendations";

export const useBillionaireRecommendations = () => {
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [displayedRecommendations, setDisplayedRecommendations] = useState<BookItem[]>([]);
  const [currentBillionaire, setCurrentBillionaire] = useState("");

  // Function to update displayed recommendations
  const updateDisplayedRecommendations = useCallback((index: number) => {
    if (!allBillionaireRecommendations[index]) return;
    const billionaireData = allBillionaireRecommendations[index];
    setCurrentBillionaire(billionaireData.billionaire);
    
    // Transform books to include billionaire reference
    const books = billionaireData.books.map(book => ({
      ...book,
      billionaire: billionaireData.billionaire
    }));
    
    setDisplayedRecommendations(books);
  }, []);

  // Effect for initial loading simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  // Effect for rotating billionaire recommendations every 3 hours
  useEffect(() => {
    updateDisplayedRecommendations(currentIndex);
    
    const rotationInterval = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
    
    const intervalId = setInterval(() => {
      setCurrentIndex(prevIndex => {
        const newIndex = (prevIndex + 1) % allBillionaireRecommendations.length;
        updateDisplayedRecommendations(newIndex);
        return newIndex;
      });
    }, rotationInterval);
    
    return () => clearInterval(intervalId);
  }, [currentIndex, updateDisplayedRecommendations]);

  return {
    loading,
    currentBillionaire,
    displayedRecommendations
  };
};
