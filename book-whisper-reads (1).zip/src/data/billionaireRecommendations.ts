
// Type for book items
export type BookItem = {
  id: string;
  title: string;
  authors: string[];
  thumbnail: string;
  billionaire?: string;
  quote?: string;
};

export type BillionaireRecommendation = {
  billionaire: string;
  books: BookItem[];
};

// Expanded billionaire recommendations dataset
export const allBillionaireRecommendations: BillionaireRecommendation[] = [
  // Elon Musk's Recommendations
  {
    billionaire: "Elon Musk",
    books: [
      {
        id: "billionaire-1",
        title: "Zero to One",
        authors: ["Peter Thiel"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0804139296-L.jpg",
        quote: "Peter Thiel has built multiple breakthrough companies, and this book shows how."
      },
      {
        id: "billionaire-2",
        title: "Superintelligence",
        authors: ["Nick Bostrom"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0199678111-L.jpg",
        quote: "Worth reading Superintelligence by Bostrom. We need to be super careful with AI."
      },
      {
        id: "billionaire-3",
        title: "The Foundation Trilogy",
        authors: ["Isaac Asimov"],
        thumbnail: "https://covers.openlibrary.org/b/id/6424064-L.jpg",
        quote: "Asimov's Foundation series is fundamental to understanding how civilizations evolve."
      }
    ]
  },
  // Warren Buffett's Recommendations
  {
    billionaire: "Warren Buffett",
    books: [
      {
        id: "billionaire-4",
        title: "The Intelligent Investor",
        authors: ["Benjamin Graham"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0060555661-L.jpg",
        quote: "By far the best book on investing ever written."
      },
      {
        id: "billionaire-5",
        title: "Business Adventures",
        authors: ["John Brooks"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/1497644895-L.jpg",
        quote: "A collection of 12 Wall Street tales that are as relevant today as when they were written."
      },
      {
        id: "billionaire-6",
        title: "The Outsiders",
        authors: ["William N. Thorndike"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/1422162672-L.jpg",
        quote: "An outstanding book about CEOs who excelled at capital allocation."
      }
    ]
  },
  // Naval Ravikant's Recommendations
  {
    billionaire: "Naval Ravikant",
    books: [
      {
        id: "billionaire-7",
        title: "The Almanack of Naval Ravikant",
        authors: ["Eric Jorgenson"],
        thumbnail: "https://covers.openlibrary.org/b/id/10387995-L.jpg",
        quote: "Getting rich is about knowing what to do, who to do it with, and when to do it."
      },
      {
        id: "billionaire-8",
        title: "Sapiens",
        authors: ["Yuval Noah Harari"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0062316095-L.jpg",
        quote: "The best book I've read in the last five years. I recommend this to everybody."
      },
      {
        id: "billionaire-9",
        title: "The Rational Optimist",
        authors: ["Matt Ridley"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0061452056-L.jpg",
        quote: "The most important book I've read. It changed my worldview."
      }
    ]
  },
  // Bill Gates' Recommendations
  {
    billionaire: "Bill Gates",
    books: [
      {
        id: "billionaire-10",
        title: "Enlightenment Now",
        authors: ["Steven Pinker"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0525427570-L.jpg",
        quote: "My favorite book of all time. It shows how the world is getting better."
      },
      {
        id: "billionaire-11",
        title: "Factfulness",
        authors: ["Hans Rosling"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/1250107814-L.jpg",
        quote: "One of the most important books I've ever read. An indispensable guide to thinking about the world."
      },
      {
        id: "billionaire-12",
        title: "The Better Angels of Our Nature",
        authors: ["Steven Pinker"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0143122010-L.jpg",
        quote: "A long but profound look at the reduction in violence and discrimination over time."
      }
    ]
  },
  // Mark Zuckerberg's Recommendations
  {
    billionaire: "Mark Zuckerberg",
    books: [
      {
        id: "billionaire-13",
        title: "Creativity, Inc.",
        authors: ["Ed Catmull"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0812993012-L.jpg",
        quote: "A book about creativity and leadership, written by the co-founder of Pixar."
      },
      {
        id: "billionaire-14",
        title: "The Structure of Scientific Revolutions",
        authors: ["Thomas Kuhn"],
        thumbnail: "https://covers.openlibrary.org/b/isbn/0226458083-L.jpg",
        quote: "It challenges how we think about science and invention."
      },
      {
        id: "billionaire-15",
        title: "Dealing with China",
        authors: ["Henry M. Paulson Jr."],
        thumbnail: "https://covers.openlibrary.org/b/isbn/1455504211-L.jpg",
        quote: "Covers a lot about how to engage and work with China."
      }
    ]
  }
];
