// Real-time Audio Narration Service using Web Speech API (SpeechSynthesis)
// Supports text-to-speech with sentence queueing to prevent Chromium pause bugs,
// speed controls (0.75x - 2x), pause/resume, and sentence progress tracking.

export interface AudioNarrationState {
  isPlaying: boolean;
  isPaused: boolean;
  currentSentence: string;
  currentSentenceIndex: number;
  totalSentences: number;
  progressPercent: number;
  rate: number;
  title: string;
  isSupported: boolean;
}

type AudioNarrationListener = (state: AudioNarrationState) => void;

class AudioNarrationService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private sentences: string[] = [];
  private currentSentenceIndex = 0;
  private rate = 1.0;
  private isPlaying = false;
  private isPaused = false;
  private title = "";
  private listeners: Set<AudioNarrationListener> = new Set();
  private selectedVoice: SpeechSynthesisVoice | null = null;

  constructor() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      this.synth = window.speechSynthesis;
      // Initialize voices when available
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.initVoice();
      }
      this.initVoice();
    }
  }

  private initVoice() {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    // Prioritize high-quality natural English voices
    const preferredVoices = voices.filter(
      (v) =>
        v.lang.startsWith("en") &&
        (v.name.includes("Google") ||
          v.name.includes("Natural") ||
          v.name.includes("Samantha") ||
          v.name.includes("Daniel") ||
          v.name.includes("Premium"))
    );
    this.selectedVoice =
      preferredVoices[0] ||
      voices.find((v) => v.lang.startsWith("en")) ||
      voices[0] ||
      null;
  }

  public isSupported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  public subscribe(listener: AudioNarrationListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(state);
      } catch (e) {
        console.error("AudioNarration listener error:", e);
      }
    });
  }

  public getState(): AudioNarrationState {
    const total = this.sentences.length;
    const progress = total > 0 ? Math.round(((this.currentSentenceIndex + 1) / total) * 100) : 0;
    return {
      isPlaying: this.isPlaying,
      isPaused: this.isPaused,
      currentSentence: this.sentences[this.currentSentenceIndex] || "",
      currentSentenceIndex: this.currentSentenceIndex,
      totalSentences: total,
      progressPercent: this.isPlaying ? Math.min(progress, 100) : 0,
      rate: this.rate,
      title: this.title,
      isSupported: this.isSupported(),
    };
  }

  // Splits long narrative text into natural sentence chunks
  private splitIntoSentences(text: string): string[] {
    const cleaned = text
      .replace(/\r\n/g, " ")
      .replace(/\n+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    // Match sentences ending in punctuation
    const matches = cleaned.match(/[^.!?]+[.!?]+(\s|$)|[^.!?]+$/g);
    if (!matches) {
      return [cleaned].filter(Boolean);
    }
    return matches.map((s) => s.trim()).filter((s) => s.length > 0);
  }

  public playText(text: string, title: string = "Audible Summary") {
    if (!this.synth) {
      console.warn("SpeechSynthesis not supported on this device/browser");
      return;
    }

    this.stop();

    this.sentences = this.splitIntoSentences(text);
    if (this.sentences.length === 0) return;

    this.title = title;
    this.currentSentenceIndex = 0;
    this.isPlaying = true;
    this.isPaused = false;
    this.notify();

    this.speakCurrentSentence();
  }

  private speakCurrentSentence() {
    if (!this.synth) return;
    if (this.currentSentenceIndex >= this.sentences.length) {
      this.stop();
      return;
    }

    const textToSpeak = this.sentences[this.currentSentenceIndex];
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    this.currentUtterance = utterance;

    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    }
    utterance.rate = this.rate;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      if (this.isPlaying && !this.isPaused) {
        this.currentSentenceIndex += 1;
        this.notify();
        this.speakCurrentSentence();
      }
    };

    utterance.onerror = (e) => {
      // Ignore cancellations triggered by stop()
      if (e.error === "canceled" || e.error === "interrupted") return;
      console.warn("SpeechSynthesis utterance error:", e);
      if (this.isPlaying && !this.isPaused) {
        this.currentSentenceIndex += 1;
        this.notify();
        this.speakCurrentSentence();
      }
    };

    try {
      this.synth.speak(utterance);
    } catch (err) {
      console.error("Failed to speak utterance:", err);
    }
  }

  public pause() {
    if (!this.synth || !this.isPlaying) return;
    this.isPaused = true;
    this.isPlaying = true;
    this.synth.pause();
    this.notify();
  }

  public resume() {
    if (!this.synth || !this.isPlaying) return;
    this.isPaused = false;
    this.synth.resume();
    this.notify();
  }

  public togglePlayPause() {
    if (!this.isPlaying) return;
    if (this.isPaused) {
      this.resume();
    } else {
      this.pause();
    }
  }

  public stop() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {
        console.warn("Error cancelling speech synthesis:", e);
      }
    }
    this.currentUtterance = null;
    this.isPlaying = false;
    this.isPaused = false;
    this.currentSentenceIndex = 0;
    this.notify();
  }

  public setRate(newRate: number) {
    this.rate = Math.max(0.75, Math.min(newRate, 2.0));
    // If currently speaking, restart current sentence with the new rate
    if (this.isPlaying && !this.isPaused && this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {
        // ignore
      }
      this.speakCurrentSentence();
    }
    this.notify();
  }

  public nextSentence() {
    if (!this.isPlaying) return;
    if (this.currentSentenceIndex < this.sentences.length - 1) {
      if (this.synth) {
        try {
          this.synth.cancel();
        } catch (e) {
          // ignore
        }
      }
      this.currentSentenceIndex += 1;
      this.notify();
      this.speakCurrentSentence();
    }
  }

  public previousSentence() {
    if (!this.isPlaying) return;
    if (this.currentSentenceIndex > 0) {
      if (this.synth) {
        try {
          this.synth.cancel();
        } catch (e) {
          // ignore
        }
      }
      this.currentSentenceIndex -= 1;
      this.notify();
      this.speakCurrentSentence();
    }
  }
}

export const audioNarrationService = new AudioNarrationService();
