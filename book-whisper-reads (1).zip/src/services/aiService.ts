// AI service for book-related AI assistance
import { freemiumService } from "./freemiumService";
import { Book } from "./bookService";
import { toast } from "sonner";
import { subscriptionService } from "./subscriptionService";

// Flag to toggle between online and offline mode for testing
const USE_OFFLINE_MODE = false;

// Maximum context length for AI processing
const MAX_CONTEXT_LENGTH = 8000;

// Google Gemini API key - from environment with fallback
const GEMINI_API_KEY = (import.meta.env.VITE_GEMINI_API_KEY || "").trim();

// OpenAI API key (placeholder - should be from environment)
const OPENAI_API_KEY = "sk-your-openai-api-key-here";

// Simulated AI response data for offline mode
const BOOK_AI_KNOWLEDGE = {
  "fantasy": [
    "Fantasy novels often involve magic, mythical creatures, and otherworldly settings.",
    "Popular fantasy series include Lord of the Rings, Harry Potter, and A Song of Ice and Fire.",
    "Fantasy as a genre allows authors to explore complex themes through imaginary worlds."
  ],
  "mystery": [
    "Mystery novels typically revolve around solving a crime or puzzle.",
    "Key elements include clues, suspects, and a detective or amateur sleuth.",
    "Authors like Agatha Christie and Arthur Conan Doyle pioneered the genre."
  ],
  "science fiction": [
    "Science fiction explores the impact of science and technology on society.",
    "It often includes futuristic concepts like space travel, time travel, and advanced technology.",
    "Authors like Isaac Asimov, Philip K. Dick, and Ursula K. Le Guin are renowned in this genre."
  ],
  "biography": [
    "Biographies tell the life story of real people, often historical figures or celebrities.",
    "They typically follow chronological order and are based on factual research.",
    "Biographies can provide insight into both personal stories and historical contexts."
  ],
  "self-help": [
    "Self-help books aim to guide readers toward personal improvement.",
    "They often include practical advice, exercises, and inspirational anecdotes.",
    "Common themes include productivity, happiness, relationships, and health."
  ]
};

// Default fallback responses
const DEFAULT_RESPONSES = [
  "That's an interesting question about literature. Books offer us windows into different worlds and perspectives.",
  "I'd recommend exploring various genres to find what resonates with you personally.",
  "Reading regularly has been shown to improve vocabulary, reduce stress, and increase empathy.",
  "Many readers find it helpful to join book clubs or online communities to discover new titles and discuss what they've read."
];

// Helper function to generate an offline response based on query content
function generateOfflineResponse(query: string, bookContext?: { title?: string; author?: string }): string {
  // If there's specific book context, generate a response about that book
  if (bookContext?.title) {
    return generateBookSpecificResponse(query, bookContext);
  }
  
  // Check for genre-related queries
  for (const genre of Object.keys(BOOK_AI_KNOWLEDGE)) {
    if (query.toLowerCase().includes(genre)) {
      const knowledge = BOOK_AI_KNOWLEDGE[genre as keyof typeof BOOK_AI_KNOWLEDGE];
      return `${knowledge.join(" ")} Does that help answer your question about ${genre} books?`;
    }
  }
  
  // Check for author recommendations
  if (query.toLowerCase().includes("recommend") || query.toLowerCase().includes("suggestion")) {
    return "Based on reader preferences, I might recommend trying authors like Kazuo Ishiguro for literary fiction, N.K. Jemisin for innovative fantasy, or Yuval Noah Harari for accessible non-fiction. Would you like more specific recommendations based on your interests?";
  }
  
  // Check for reading habit questions
  if (query.toLowerCase().includes("how to read more") || query.toLowerCase().includes("reading habit")) {
    return "To develop a reading habit, try setting aside a specific time each day, starting with shorter sessions (15-30 minutes), and keeping books easily accessible. Many readers find that reading before bed or during their commute works well. Would you like more specific advice?";
  }
  
  // Default response if no specific pattern is matched
  const randomIndex = Math.floor(Math.random() * DEFAULT_RESPONSES.length);
  return DEFAULT_RESPONSES[randomIndex];
}

// Generate a response for a specific book
function generateBookSpecificResponse(query: string, bookContext: { title?: string; author?: string }): string {
  const { title, author } = bookContext;
  
  if (query.toLowerCase().includes("about") || query.toLowerCase().includes("tell me")) {
    return `"${title}" ${author ? `by ${author}` : ""} is a notable work that has resonated with many readers. The book explores themes that are both timeless and thought-provoking. Many readers appreciate its narrative style and character development. Would you like to know about any specific aspect of this book?`;
  }
  
  if (query.toLowerCase().includes("worth") || query.toLowerCase().includes("should i read")) {
    return `Many readers find "${title}" ${author ? `by ${author}` : ""} worthwhile, particularly if you enjoy thoughtful narrative and engaging character development. The book has received positive critical reception and continues to resonate with readers. Would you like to hear more about what makes it special?`;
  }
  
  if (query.toLowerCase().includes("similar") || query.toLowerCase().includes("like this")) {
    return `If you enjoy "${title}", you might also appreciate works with similar themes or storytelling styles. Many readers who liked this book also enjoyed works by other contemporary authors exploring related ideas. Would you like more specific recommendations based on what you enjoyed about "${title}"?`;
  }
  
  // Default book response
  return `"${title}" ${author ? `by ${author}` : ""} is a book that explores interesting themes and ideas. Many readers find its perspective valuable and thought-provoking. Is there something specific about this book you'd like to discuss?`;
}

// Function to get AI chat response - now unlimited
export const getAIChatResponse = async (query: string, bookContext?: { title?: string; author?: string }, imageData?: string): Promise<string> => {
  console.log("AI Chat Query (unlimited access):", query, "Context:", bookContext);

  try {
    if (USE_OFFLINE_MODE || !GEMINI_API_KEY) {
      console.log("Using offline mode for AI chat");
      await new Promise(resolve => setTimeout(resolve, 1000));
      const response = generateOfflineResponse(query, bookContext);
      return freemiumService.sanitizeHTML(response);
    }
    
    console.log("Calling Google Gemini API for chat response (unlimited access)...");
    
    let prompt = query;
    if (bookContext?.title && bookContext?.author) {
      prompt = `Context: We are discussing "${bookContext.title}" by ${bookContext.author}. User question: ${query}`;
    }

    // Prepare request body
    const requestBody: any = {
      contents: [
        {
          parts: []
        }
      ],
      generationConfig: {
        temperature: 0.5,
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 2048
      }
    };

    // Add image if provided
    if (imageData) {
      requestBody.contents[0].parts.push({
        inline_data: {
          mime_type: "image/jpeg",
          data: imageData.split(',')[1] // Remove data:image/jpeg;base64, prefix
        }
      });
      
      // Enhanced prompt for image analysis
      requestBody.contents[0].parts.push({
        text: `You are an expert book assistant with advanced image recognition capabilities. Analyze this book image carefully and provide detailed information about:

1. **Book Identification**: What book is shown in the image? Provide the exact title and author.
2. **Visual Analysis**: Describe the cover design, colors, and any visible text or symbols.
3. **Book Details**: Share key information about this book including:
   - Genre and category
   - Publication details (if recognizable)
   - Main themes and concepts
   - Target audience
4. **Content Summary**: Provide a brief but informative summary of what this book is about.
5. **Recommendations**: Why should someone read this book? What makes it valuable?

User's question: ${prompt}

Please be specific and accurate in your book identification. Focus on providing helpful, detailed information about the book shown in the image.`
      });
    } else {
      requestBody.contents[0].parts.push({
        text: `You are an AI book assistant that helps readers with book recommendations, summaries, and information about authors. You provide concise, helpful responses focused on literature and reading. ${prompt}`
      });
    }

    if (!GEMINI_API_KEY) {
      return freemiumService.sanitizeHTML(generateOfflineResponse(query, bookContext));
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(requestBody),
      }
    );

    if (!response.ok) {
      console.error("Google Gemini API error:", response.status, response.statusText);
      const errorText = await response.text();
      console.error("API error response:", errorText);
      
      return freemiumService.sanitizeHTML(generateOfflineResponse(query, bookContext));
    }

    const result = await response.json();
    console.log("AI chat response received successfully (unlimited access)");
    
    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content.parts[0].text) {
      const sanitizedResponse = freemiumService.sanitizeHTML(result.candidates[0].content.parts[0].text);
      return sanitizedResponse;
    } else {
      console.error("Invalid API response format:", result);
      return freemiumService.sanitizeHTML(generateOfflineResponse(query, bookContext));
    }
  } catch (error) {
    console.error("Error in AI chat response:", error);
    return freemiumService.sanitizeHTML(generateOfflineResponse(query, bookContext));
  }
};

// Function to check if a query is potentially harmful or problematic
export function isSafeQuery(query: string): boolean {
  const unsafePatterns = [
    /hack/i, /exploit/i, /illegal/i, /steal/i, /attack/i,
    /bypass/i, /fraud/i, /malware/i, /phish/i
  ];
  
  return !unsafePatterns.some(pattern => pattern.test(query));
}

// Function to get enhanced trending books with AI-generated content
export const getEnhancedTrendingBooks = async (): Promise<Book[]> => {
  try {
    // Import here to avoid circular dependency
    const { getTrendingBooks } = await import('./bookService');
    
    // Get regular trending books
    const trendingBooks = await getTrendingBooks();
    
    // In a real implementation, we would enhance these books with AI data
    // For this demo, we'll just return the trending books
    return trendingBooks;
  } catch (error) {
    console.error("Error getting enhanced trending books:", error);
    return [];
  }
};

// Generate an AI summary for a book - now unlimited
export const getAIBookSummary = async (
  title: string, 
  author: string, 
  description: string
): Promise<{ content: string; source: string; timestamp: string }> => {
  try {
    console.log(`Generating unlimited AI summary for "${title}" by ${author}`);
    
    if (USE_OFFLINE_MODE || !GEMINI_API_KEY) {
      console.log("Using intelligent generator for book summary");
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      let summary = "";
      
      if (description && description.length > 100) {
        // Extract key sentences from the description
        const sentences = description.split(/[.!?]+/).filter(s => s.trim().length > 0);
        
        if (sentences.length >= 3) {
          // Use first, middle and last meaningful sentences
          summary = `${sentences[0]}. ${sentences[Math.floor(sentences.length / 2)]}. ${sentences[sentences.length - 1]}.`;
        } else {
          summary = description;
        }
      } else {
        summary = `"${title}" by ${author} is a thought-provoking work that explores various themes and ideas. Readers will find themselves engaged with the narrative and the characters throughout the journey of this book.`;
      }
      
      // Add some AI-like insights
      summary += " The work demonstrates the author's unique perspective and contributes significantly to its genre.";
      
      return {
        content: freemiumService.sanitizeHTML(summary),
        source: "ai-generated-offline",
        timestamp: new Date().toISOString()
      };
    }
    
    console.log("Generating unlimited AI summary with Google Gemini 3.8 Flash...");
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `I want a complete and in-depth understanding of the book '${title}' by ${author} to fully cover all its content. Provide a detailed summary of the entire book, including its plot (if fictional), main arguments or themes (if non-fiction), and key ideas across all chapters or sections. For each major theme, chapter, character (if applicable), or concept, explain its significance to the book's overall message or narrative, providing clear reasons why it matters. Support these explanations with vivid, descriptive examples from the text, such as specific scenes, quotes, character developments, or events, to illustrate how they contribute to the book's purpose or impact. Analyze the author's writing style, historical/cultural context, and intended audience, and explain how these shape the book's content and reception. Identify and discuss any literary devices (e.g., symbolism, metaphors, foreshadowing) or structural elements used, with examples showing their role in enhancing the story or argument. Additionally, provide practical advice on how to apply the book's lessons, themes, or insights to real-life scenarios, academic discussions, or further study, ensuring the advice is specific and actionable. Ensure the response is well-organized, concise yet comprehensive, and easy to understand, covering the entire book without missing any key elements. If I need to focus on specific sections, themes, or aspects, please ask for clarification. If any part of the book is unclear or requires deeper exploration, suggest questions I could consider to deepen my understanding. Book description for context: "${description}".`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.3,
            topP: 0.8,
            topK: 40,
            maxOutputTokens: 1024
          }
        }),
      }
    );

    if (!response.ok) {
      console.error("Google Gemini API error:", response.status, response.statusText);
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    
    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content.parts[0].text) {
      return {
        content: freemiumService.sanitizeHTML(result.candidates[0].content.parts[0].text),
        source: "gemini-ai",
        timestamp: new Date().toISOString()
      };
    } else {
      throw new Error("Invalid API response format");
    }
  } catch (error) {
    console.error("Error generating AI book summary:", error);
    
    return {
      content: `We couldn't generate a detailed summary for "${title}" at this time. The book appears to explore interesting themes that many readers find engaging.`,
      source: "fallback",
      timestamp: new Date().toISOString()
    };
  }
};

// Generate AI key points for a book - using Gemini
export const getAIKeyPoints = async (title: string, author: string): Promise<{ insights: string[]; applications: string[] }> => {
  try {
    console.log(`Generating AI key points for "${title}" by ${author}`);
    
    if (USE_OFFLINE_MODE || !GEMINI_API_KEY) {
      console.log("Using offline mode for key points");
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return {
        insights: [
          `${title} emphasizes the importance of consistent action and mindful decision-making.`,
          `The author demonstrates how small daily practices can create significant long-term change.`,
          `Key psychological principles are explored to help understand human behavior patterns.`,
          `The book provides frameworks for overcoming common obstacles and resistance.`
        ],
        applications: [
          `Apply the book's daily practice methods to develop better habits`,
          `Use the psychological principles to understand your own behavioral patterns`,
          `Implement the frameworks when facing challenging situations`,
          `Study the case examples to improve your problem-solving approach`
        ]
      };
    }
    
    console.log("Generating AI key points with Google Gemini 3.8 Flash...");
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Generate key insights and practical applications for the book "${title}" by ${author}. Provide 2 sections: 1) Key Insights (4-5 main learning points) 2) Applications (4-5 practical ways to implement the concepts). Format as JSON with "insights" and "applications" arrays.`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.4,
            topP: 0.8,
            topK: 40,
            maxOutputTokens: 800
          }
        }),
      }
    );

    if (!response.ok) {
      console.error("Google Gemini API error:", response.status, response.statusText);
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    
    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content.parts[0].text) {
      const content = result.candidates[0].content.parts[0].text;
      
      try {
        // Try to parse as JSON first
        const parsed = JSON.parse(content);
        if (parsed.insights && parsed.applications) {
          return {
            insights: parsed.insights.slice(0, 5),
            applications: parsed.applications.slice(0, 5)
          };
        }
      } catch (e) {
        // If JSON parsing fails, split content into sections
        const lines = content.split('\n').filter((line: string) => line.trim());
        const insights: string[] = [];
        const applications: string[] = [];
        let currentSection = 'insights';
        
        for (const line of lines) {
          const cleanLine = line.replace(/^[-*•]\s*/, '').trim();
          if (cleanLine.toLowerCase().includes('application') || cleanLine.toLowerCase().includes('implement')) {
            currentSection = 'applications';
            continue;
          }
          if (cleanLine && !cleanLine.toLowerCase().includes('insight') && !cleanLine.toLowerCase().includes('section')) {
            if (currentSection === 'insights' && insights.length < 5) {
              insights.push(cleanLine);
            } else if (currentSection === 'applications' && applications.length < 5) {
              applications.push(cleanLine);
            }
          }
        }
        
        return { insights, applications };
      }
    }
    
    throw new Error("Could not parse AI response");
  } catch (error) {
    console.error('Error generating AI key points:', error);
    // Return fallback key points
    return {
      insights: [
        "This book offers valuable insights and practical wisdom",
        "Key concepts are presented in an accessible and engaging manner",
        "The author provides actionable strategies for implementation"
      ],
      applications: [
        "Apply the book's main concepts to your daily routine",
        "Use the strategies in your personal or professional development",
        "Share the insights with others to deepen your understanding"
      ]
    };
  }
};

// Generate comprehensive book analysis - using Gemini
export const getComprehensiveBookAnalysis = async (title: string, author: string, description?: string): Promise<string> => {
  try {
    console.log(`Generating comprehensive analysis for "${title}" by ${author}`);
    
    if (USE_OFFLINE_MODE) {
      console.log("Using offline mode for comprehensive analysis");
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return `# ${title} - Complete AI Analysis & Practical Guide

## Book Overview and Introduction
"${title}" by ${author} is a profound and enlightening work that provides readers with practical wisdom and reliable guidance across various aspects of life. This book is not only grounded in theoretical foundations but is rich with real-life experiences and practical examples.

## Core Messages and Central Ideas
### 1. Personal Development and Self-Awareness
This book emphasizes recognizing and utilizing human inner strength and capabilities.

### 2. Practical Wisdom and Living Principles
The author presents practical methods that can be immediately implemented rather than mere theoretical discussions.

### 3. Continuous Learning Process
The book emphasizes that learning is a continuous process that should never stop.

## Key Themes and Topics
- **Success Principles**: Achieving goals through logical and practical methods
- **Relationship Improvement**: Techniques for strengthening human connections
- **Mental and Emotional Balance**: Methods for dealing with pressure and challenges
- **Goal Setting**: Establishing clear and realistic objectives
- **Better Time Management**: Prioritizing in life
- **Positive Thinking**: Converting negative thoughts into positive energy

## Detailed Chapter Analysis

### Chapter 1: Establishing Fundamental Principles
- The importance of self-knowledge
- Assessing personal strengths and weaknesses
- Clear definition of life goals

### Chapter 2: Practical Methods and Strategies
- The role of daily habits
- Breaking free from negative patterns
- Forming new and better habits

### Chapter 3: Real Examples and Case Studies
- Experiences of successful people
- Ways to learn from failures
- Patience and perseverance in difficult situations

### Chapter 4: Long-term Planning and Vision
- Wise planning for the future
- Realistic and achievable goals
- Methods of measuring success

## Important Quotes and Wisdom from the Book
"${title}" contains many valuable quotes that have the power to transform lives:

### Inspiring Quotes:
- "True success lies in inner happiness and contentment"
- "Every difficulty hides a new opportunity"
- "Change begins with oneself"
- "Patience and continuous effort are the keys to success"

## Practical Applications - How to Use in Life

### In Daily Life
1. **Morning Habits**: Waking up at the right time for a positive start
2. **Meditation and Reflection**: A few minutes of daily silence
3. **Planning**: Setting daily objectives
4. **Gratitude**: Being thankful for existing blessings

### In Business Life
- **Teamwork**: Better relationships with colleagues
- **Leadership**: The ability to make a positive impact
- **Problem Solving**: Creative and practical solutions
- **Time Management**: Proper prioritization

### In Family Life
- **Better Relationships**: Based on love and respect
- **Child Rearing**: Transmitting positive values
- **Home Environment**: Pleasant and peaceful atmosphere

## Important Life Lessons

### 1. The Power of Patience and Perseverance
The author clearly explains that real success is not achieved immediately. Patience and continuous effort are essential.

### 2. Continuous Learning Process
There is always something to learn in life. Every experience is a lesson.

### 3. Respect for Others
Respect and empathy are fundamental in human relationships.

### 4. Focused Attention on Goals
Having clear goals in life and maintaining continuous focus on them is essential.

### 5. Protection from Negative Thinking
Positive thinking and outlook improve life.

## Summary and Recommendation
"${title}" is a book that is extremely useful for anyone who wants to bring positive and lasting change to their life. This book is not just for reading but for action and life application.

### Who Should Read:
- Ambitious professionals building long-term career momentum
- Entrepreneurs and leaders navigating complex strategic decisions
- Readers committed to personal growth and disciplined habits
- Anyone seeking actionable frameworks for clarity and execution

*This comprehensive analysis was generated using BookWhisper AI research and book insights.*`;
    }

    if (!GEMINI_API_KEY) {
      console.log("Using rich curated comprehensive summary (offline mode)");
      return freemiumService.sanitizeHTML(defaultComprehensiveSummary);
    }
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `You are an expert English book analysis specialist. Write an extremely detailed and comprehensive analysis in English for "${title}" by ${author} that contains at least 5000 words.

${description ? `Book details: ${description}` : ''}

You must include these sections:

## 1. Book Introduction and Overview (500+ words)
- Central message and main argument of the book
- Historical background and significance
- Target audience and relevance
- Author's background and experience

## 2. Core Themes and Messages (800+ words)
- Detailed explanation of fundamental themes
- Philosophical concepts
- Universal truths and principles
- Moral and spiritual aspects

## 3. Detailed Chapter Analysis (2000+ words)
- Complete summary of each chapter
- Progressive development of ideas
- Key insights and turning points
- Connections between chapters

## 4. Important Quotes and Analysis (800+ words)
- 15-20 powerful quotes from the book
- Deep analysis of each quote
- Connection to fundamental themes
- Practical applications

## 5. Real Examples and Case Studies (600+ words)
- Concrete examples from the book
- Modern applications and parallels
- Success stories and implementations
- Practical enforcement strategies

## 6. Life Application Guide (800+ words)
- Step-by-step practical plans
- Daily, weekly, and monthly practices
- Habit-building strategies
- Mental transformations
- Challenges and solutions

## 7. Important Life Lessons (400+ words)
- Personal development outcomes
- Professional benefits
- Relationship improvements
- Financial and lifestyle changes

Write an extremely practical, insightful, and detailed analysis that can be immediately applied to life. Use clear, engaging English throughout.`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            topP: 0.8,
            topK: 40,
            maxOutputTokens: 8192
          }
        }),
      }
    );

    if (!response.ok) {
      console.error("Google Gemini API error:", response.status, response.statusText);
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    
    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content.parts[0].text) {
      return result.candidates[0].content.parts[0].text;
    }
    
    throw new Error("Invalid API response format");
  } catch (error) {
    console.error('Error generating comprehensive analysis:', error);
    
    // Enhanced English fallback content
    return `# ${title} - Detailed Analysis and Practical Guide

## Introduction to the Book
"${title}" by ${author} is an excellent book that teaches readers important life lessons.

## Core Topics
- Personal development and self-awareness
- Secrets and methods of success
- Techniques for improving relationships
- Positive thinking and life philosophy

## Key Points from the Book
### Important Insights:
1. Clear definition of life goals
2. Better decision-making ability
3. Methods to deal with pressure and challenges
4. Improvement in human relationships

## Practical Benefits
This book can benefit you in the following ways:
- **In Personal Life**: Self-confidence and better decisions
- **In Business Life**: Leadership and teamwork
- **In Family Life**: Better relationships and connections

## Life Lessons
1. The importance of patience and perseverance
2. Continuous learning process
3. Good behavior with others
4. Focused attention on your goals

*Complete AI analysis unavailable - please try again*`;
  }
};