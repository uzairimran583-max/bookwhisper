import { Book } from "./bookService";

export const CURATED_BOOKS: Book[] = [
  {
    id: "atomic-habits",
    title: "Atomic Habits",
    authors: ["James Clear"],
    description: "An Easy & Proven Way to Build Good Habits & Break Bad Ones. No matter your goals, Atomic Habits offers a proven framework for improving every day. James Clear, one of the world's leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.",
    categories: ["Self-Help", "Psychology", "Personal Development"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg",
    publishedDate: "2018",
    publishedYear: 2018,
    pageCount: 320,
    language: "en",
    previewLink: "https://jamesclear.com/atomic-habits",
    publisher: "Avery / Penguin Random House",
    averageRating: 4.8,
    ratingsCount: 14200,
    isTrending: true,
  },
  {
    id: "psychology-of-money",
    title: "The Psychology of Money",
    authors: ["Morgan Housel"],
    description: "Timeless lessons on wealth, greed, and happiness doing well with money isn't necessarily about what you know. It's about how you behave. And behavior is hard to teach, even to really smart people. Morgan Housel shares 19 short stories exploring the strange ways people think about money.",
    categories: ["Business", "Finance", "Psychology"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780857197689-L.jpg",
    publishedDate: "2020",
    publishedYear: 2020,
    pageCount: 256,
    language: "en",
    previewLink: "https://www.morganhousel.com",
    publisher: "Harriman House",
    averageRating: 4.7,
    ratingsCount: 9800,
    isTrending: true,
  },
  {
    id: "deep-work",
    title: "Deep Work",
    authors: ["Cal Newport"],
    description: "Rules for Focused Success in a Distracted World. Deep work is the ability to focus without distraction on a cognitively demanding task. It's a superpower in our increasingly competitive twenty-first century economy. Cal Newport guides readers through actionable disciplines for cultivating deep focus.",
    categories: ["Business", "Productivity", "Self-Help"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9781455586691-L.jpg",
    publishedDate: "2016",
    publishedYear: 2016,
    pageCount: 304,
    language: "en",
    previewLink: "https://calnewport.com/books/deep-work/",
    publisher: "Grand Central Publishing",
    averageRating: 4.6,
    ratingsCount: 7400,
    isTrending: true,
  },
  {
    id: "zero-to-one",
    title: "Zero to One",
    authors: ["Peter Thiel", "Blake Masters"],
    description: "Notes on Startups, or How to Build the Future. The great secret of our time is that there are still uncharted frontiers to explore and new inventions to create. In Zero to One, legendary entrepreneur and investor Peter Thiel shows how we can find singular ways to create those new things.",
    categories: ["Business", "Technology", "Entrepreneurship"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780804139298-L.jpg",
    publishedDate: "2014",
    publishedYear: 2014,
    pageCount: 224,
    language: "en",
    previewLink: "",
    publisher: "Crown Business",
    averageRating: 4.7,
    ratingsCount: 11200,
    isTrending: true,
    billionaireRecommendation: {
      billionaire: "Elon Musk",
      quote: "Peter Thiel has built multiple breakthrough companies, and this book shows how."
    }
  },
  {
    id: "sapiens",
    title: "Sapiens: A Brief History of Humankind",
    authors: ["Yuval Noah Harari"],
    description: "One hundred thousand years ago, at least six different species of humans inhabited Earth. Yet today there is only one—Homo sapiens. How did our species succeed in the battle for dominance? Yuval Noah Harari surveys the entire history of humankind from early hunter-gatherers to modern technological civilization.",
    categories: ["History", "Anthropology", "Science"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg",
    publishedDate: "2015",
    publishedYear: 2015,
    pageCount: 464,
    language: "en",
    previewLink: "https://www.ynharari.com/book/sapiens/",
    publisher: "Harper",
    averageRating: 4.8,
    ratingsCount: 18500,
    isTrending: true,
    billionaireRecommendation: {
      billionaire: "Naval Ravikant",
      quote: "The best book I've read in the last five years. I recommend this to everybody."
    }
  },
  {
    id: "thinking-fast-and-slow",
    title: "Thinking, Fast and Slow",
    authors: ["Daniel Kahneman"],
    description: "In the international bestseller, Daniel Kahneman, the renowned psychologist and winner of the Nobel Prize in Economics, takes us on a groundbreaking tour of the mind and explains the two systems that drive the way we think—System 1 (fast, intuitive) and System 2 (slow, deliberate).",
    categories: ["Psychology", "Science", "Decision Making"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780374275631-L.jpg",
    publishedDate: "2011",
    publishedYear: 2011,
    pageCount: 512,
    language: "en",
    previewLink: "",
    publisher: "Farrar, Straus and Giroux",
    averageRating: 4.6,
    ratingsCount: 15300,
    isTrending: true,
  },
  {
    id: "principles-life-work",
    title: "Principles: Life and Work",
    authors: ["Ray Dalio"],
    description: "Ray Dalio, one of the world's most successful investors and entrepreneurs, shares the unconventional principles that he's developed, refined, and used over the past forty years to create unique results in both life and business—and which any person or organization can adopt.",
    categories: ["Business", "Management", "Philosophy"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9781501124020-L.jpg",
    publishedDate: "2017",
    publishedYear: 2017,
    pageCount: 592,
    language: "en",
    previewLink: "https://www.principles.com",
    publisher: "Simon & Schuster",
    averageRating: 4.7,
    ratingsCount: 8900,
    isTrending: true,
  },
  {
    id: "intelligent-investor",
    title: "The Intelligent Investor",
    authors: ["Benjamin Graham"],
    description: "The definitive book on value investing. Benjamin Graham's philosophy of 'value investing' shields investors from substantial error and teaches them to develop long-term strategies, making this the investment bible since its original publication in 1949.",
    categories: ["Business", "Finance", "Investing"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780060555665-L.jpg",
    publishedDate: "2006",
    publishedYear: 2006,
    pageCount: 640,
    language: "en",
    previewLink: "",
    publisher: "Harper Business",
    averageRating: 4.7,
    ratingsCount: 12500,
    billionaireRecommendation: {
      billionaire: "Warren Buffett",
      quote: "By far the best book on investing ever written."
    }
  },
  {
    id: "almanack-naval-ravikant",
    title: "The Almanack of Naval Ravikant",
    authors: ["Eric Jorgenson"],
    description: "A Guide to Wealth and Happiness. Getting rich is not just about luck; happiness is not just a trait we are born with. These aspirations may seem out of reach, but building wealth and being happy are skills we can learn. Curated thoughts and lessons from Naval Ravikant.",
    categories: ["Philosophy", "Self-Help", "Finance"],
    thumbnail: "https://covers.openlibrary.org/b/id/10387995-L.jpg",
    publishedDate: "2020",
    publishedYear: 2020,
    pageCount: 244,
    language: "en",
    previewLink: "https://www.navalmanack.com",
    publisher: "Magrathea Publishing",
    averageRating: 4.8,
    ratingsCount: 10400,
    billionaireRecommendation: {
      billionaire: "Naval Ravikant",
      quote: "Getting rich is about knowing what to do, who to do it with, and when to do it."
    }
  },
  {
    id: "steve-jobs",
    title: "Steve Jobs",
    authors: ["Walter Isaacson"],
    description: "Based on more than forty interviews with Steve Jobs conducted over two years—as well as interviews with more than a hundred family members, friends, adversaries, competitors, and colleagues—Walter Isaacson has written a riveting story of the roller-coaster life and searingly intense personality of a creative entrepreneur whose passion for perfection revolutionized six industries.",
    categories: ["Biography", "Technology", "Business"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9781451648539-L.jpg",
    publishedDate: "2011",
    publishedYear: 2011,
    pageCount: 656,
    language: "en",
    previewLink: "",
    publisher: "Simon & Schuster",
    averageRating: 4.8,
    ratingsCount: 16700,
    isTrending: true,
  },
  {
    id: "factfulness",
    title: "Factfulness",
    authors: ["Hans Rosling", "Anna Rosling Rönnlund", "Ola Rosling"],
    description: "Ten Reasons We're Wrong About the World—and Why Things Are Better Than You Think. In Factfulness, Professor of International Health Hans Rosling offers a radical new explanation of why people consistently get basic questions about global trends wrong.",
    categories: ["Science", "Economics", "Nonfiction"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9781250107817-L.jpg",
    publishedDate: "2018",
    publishedYear: 2018,
    pageCount: 352,
    language: "en",
    previewLink: "",
    publisher: "Flatiron Books",
    averageRating: 4.7,
    ratingsCount: 9100,
    billionaireRecommendation: {
      billionaire: "Bill Gates",
      quote: "One of the most important books I've ever read. An indispensable guide to thinking about the world."
    }
  },
  {
    id: "creativity-inc",
    title: "Creativity, Inc.",
    authors: ["Ed Catmull", "Amy Wallace"],
    description: "Overcoming the Unseen Forces That Stand in the Way of True Inspiration. Creativity, Inc. is a manual for anyone who strives for originality and the first-ever, all-access trip into the nerve center of Pixar Animation—into the meetings, postmortems, and 'Braintrust' sessions where some of the most successful films in history are made.",
    categories: ["Business", "Leadership", "Creativity"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780812993011-L.jpg",
    publishedDate: "2014",
    publishedYear: 2014,
    pageCount: 368,
    language: "en",
    previewLink: "",
    publisher: "Random House",
    averageRating: 4.7,
    ratingsCount: 8200,
    billionaireRecommendation: {
      billionaire: "Mark Zuckerberg",
      quote: "A book about creativity and leadership, written by the co-founder of Pixar."
    }
  },
  {
    id: "the-lean-startup",
    title: "The Lean Startup",
    authors: ["Eric Ries"],
    description: "How Today's Entrepreneurs Use Continuous Innovation to Create Radically Successful Businesses. Most startups fail. But many of those failures are preventable. The Lean Startup approach fosters companies that are both more capital efficient and that leverage human creativity more effectively.",
    categories: ["Business", "Entrepreneurship", "Technology"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780307887894-L.jpg",
    publishedDate: "2011",
    publishedYear: 2011,
    pageCount: 336,
    language: "en",
    previewLink: "http://theleanstartup.com/",
    publisher: "Crown Business",
    averageRating: 4.5,
    ratingsCount: 11000,
  },
  {
    id: "man-search-for-meaning",
    title: "Man's Search for Meaning",
    authors: ["Viktor E. Frankl"],
    description: "Psychiatrist Viktor Frankl's memoir has riveted generations of readers with its descriptions of life in Nazi death camps and its lessons for spiritual survival. Frankl argues that we cannot avoid suffering, but we can choose how to cope with it, find meaning in it, and move forward.",
    categories: ["Psychology", "Philosophy", "Biography"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780807014295-L.jpg",
    publishedDate: "1946",
    publishedYear: 1946,
    pageCount: 200,
    language: "en",
    previewLink: "",
    publisher: "Beacon Press",
    averageRating: 4.9,
    ratingsCount: 22000,
  },
  {
    id: "good-to-great",
    title: "Good to Great",
    authors: ["Jim Collins"],
    description: "Why Some Companies Make the Leap and Others Don't. Can a good company become a great company and, if so, how? Over five years, Jim Collins and his research team analyzed twenty-eight companies to discover the key determinants of greatness.",
    categories: ["Business", "Leadership", "Management"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780066620992-L.jpg",
    publishedDate: "2001",
    publishedYear: 2001,
    pageCount: 300,
    language: "en",
    previewLink: "https://www.jimcollins.com",
    publisher: "Harper Business",
    averageRating: 4.6,
    ratingsCount: 9500,
  },
  {
    id: "meditations-marcus-aurelius",
    title: "Meditations",
    authors: ["Marcus Aurelius"],
    description: "Written in Greek by the only Roman emperor who was also a philosopher, without any intention of publication, the Meditations of Marcus Aurelius offer a remarkable series of challenging spiritual reflections and exercises developed as the emperor struggled to understand himself and make sense of the universe.",
    categories: ["Philosophy", "Classics", "Self-Help"],
    thumbnail: "https://covers.openlibrary.org/b/isbn/9780140449334-L.jpg",
    publishedDate: "180",
    publishedYear: 180,
    pageCount: 256,
    language: "en",
    previewLink: "",
    publisher: "Modern Library",
    averageRating: 4.8,
    ratingsCount: 17800,
  }
];

export function findCuratedBook(idOrQuery: string): Book | undefined {
  const q = idOrQuery.toLowerCase().trim();
  return CURATED_BOOKS.find(b => 
    b.id.toLowerCase() === q ||
    b.title.toLowerCase() === q ||
    b.title.toLowerCase().includes(q)
  );
}

export function searchCuratedBooks(query: string): Book[] {
  const q = query.toLowerCase().trim();
  if (!q) return CURATED_BOOKS;
  return CURATED_BOOKS.filter(b => 
    b.title.toLowerCase().includes(q) ||
    b.authors.some(a => a.toLowerCase().includes(q)) ||
    b.categories.some(c => c.toLowerCase().includes(q)) ||
    b.description.toLowerCase().includes(q)
  );
}

/**
 * Finds relative / related books for a given query or seed book
 * Matches based on common categories, themes, authors, or complementary reading
 */
export function getRelativeCuratedBooks(query: string, currentId?: string, limit: number = 6): Book[] {
  const q = query.toLowerCase().trim();
  const candidates = CURATED_BOOKS.filter(b => b.id !== currentId);
  
  if (!q) return candidates.slice(0, limit);

  // Score candidate relevance
  const scored = candidates.map(book => {
    let score = 0;
    const catMatch = book.categories.some(c => c.toLowerCase().includes(q) || q.includes(c.toLowerCase()));
    if (catMatch) score += 3;
    const authorMatch = book.authors.some(a => a.toLowerCase().includes(q) || q.includes(a.toLowerCase()));
    if (authorMatch) score += 4;
    const descMatch = book.description.toLowerCase().includes(q);
    if (descMatch) score += 1;
    return { book, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const relevant = scored.filter(s => s.score > 0).map(s => s.book);

  if (relevant.length >= limit) {
    return relevant.slice(0, limit);
  }

  // Complement with popular picks so user always gets relative recommendations
  const remaining = candidates.filter(b => !relevant.some(r => r.id === b.id));
  return [...relevant, ...remaining].slice(0, limit);
}
