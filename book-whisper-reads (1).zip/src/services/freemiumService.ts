import { toast } from "sonner";
import { subscriptionService } from "./subscriptionService";

class FreemiumService {
  constructor() {
    // No longer need to track usage since everything is free
    console.log("FreemiumService: All features are now unlimited and free");
  }

  // Always return unlimited usage
  getAIChatUsage(): number {
    return 0; // Always show 0 usage since it's unlimited
  }

  getAISummaryUsage(): number {
    return 0; // Always show 0 usage since it's unlimited
  }

  // No-op methods since we don't track usage anymore
  incrementAIChatUsage(): void {
    console.log("AI Chat used - unlimited access");
  }

  incrementAISummaryUsage(): void {
    console.log("AI Summary used - unlimited access");
  }

  // Reset is no longer needed but keep for compatibility
  resetUsage(): void {
    console.log("No usage to reset - everything is unlimited");
  }

  // Always return true since everything is free
  hasAIChatAvailable(): boolean {
    console.log("AI Chat availability check: unlimited access");
    return true;
  }

  hasAISummaryAvailable(): boolean {
    console.log("AI Summary availability check: unlimited access");
    return true;
  }

  // Return a message indicating unlimited access
  getRemainingResetTime(): string {
    return "Unlimited";
  }

  // Show welcome message for unlimited access
  showWelcomeMessage(): void {
    toast.success("Welcome to BookWhisper!", {
      description: "Enjoy unlimited AI chats, book summaries, and all features - completely free!",
      duration: 6000,
    });
  }

  // No longer show subscription prompts since everything is free
  showSubscriptionPrompt(feature: 'chat' | 'summary'): void {
    // No-op since everything is free
  }

  // Log access attempts for analytics
  logAccessAttempt(feature: string, success: boolean): void {
    console.log(`Access attempt: ${feature}, Success: ${success} (unlimited access)`);
  }

  // Initialize for all users - no restrictions
  initializeForUser(): void {
    console.log("Initializing freemium service - all features unlimited");
    this.showWelcomeMessage();
  }

  // Keep sanitization for safety
  sanitizeHTML(html: string): string {
    if (!html) return '';
    
    // Fix common malformed tags
    let sanitized = html
      .replace(/<\\i>/g, '</i>')
      .replace(/<\\b>/g, '</b>')
      .replace(/<\\em>/g, '</em>')
      .replace(/<\\strong>/g, '</strong>')
      .replace(/<\\p>/g, '</p>')
      .replace(/<\\div>/g, '</div>')
      .replace(/<\\span>/g, '</span>');
    
    // Remove any other potentially malformed HTML tags
    sanitized = sanitized.replace(/<\\[^>]*>/g, '');
    
    return sanitized;
  }
}

// Export singleton instance
export const freemiumService = new FreemiumService();
