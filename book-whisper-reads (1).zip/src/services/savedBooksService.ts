import { supabase } from "@/integrations/supabase/client";
import { Book } from "@/services/bookService";
import { toast } from "sonner";

const BASE_STORAGE_KEY = "bookwhisper_saved_books";
const USER_STORAGE_KEY = "bookwhisper_auth_user";

function getCurrentUserEmail(): string | null {
  try {
    const raw = localStorage.getItem(USER_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return parsed.email || null;
    }
  } catch {
    // ignore
  }
  return null;
}

function getStorageKey(): string {
  const email = getCurrentUserEmail();
  return email ? `${BASE_STORAGE_KEY}_${email.replace(/[^a-zA-Z0-9]/g, "_")}` : BASE_STORAGE_KEY;
}

function getLocalSavedBooks(): Book[] {
  try {
    const primaryKey = getStorageKey();
    const raw = localStorage.getItem(primaryKey);
    if (raw) {
      return JSON.parse(raw);
    }
    // Fallback to base key if user-specific is empty
    if (primaryKey !== BASE_STORAGE_KEY) {
      const baseRaw = localStorage.getItem(BASE_STORAGE_KEY);
      if (baseRaw) {
        return JSON.parse(baseRaw);
      }
    }
    return [];
  } catch {
    return [];
  }
}

function saveLocalBooks(books: Book[]): void {
  try {
    const key = getStorageKey();
    localStorage.setItem(key, JSON.stringify(books));
    // Also save in base key for consistency
    localStorage.setItem(BASE_STORAGE_KEY, JSON.stringify(books));
    // Dispatch event to notify all components
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("bookwhisper:saved_books_changed"));
    }
  } catch (e) {
    console.error("Failed to save books to localStorage", e);
  }
}

export const savedBooksService = {
  // Save a book to the user's library
  async saveBook(book: Book): Promise<boolean> {
    try {
      // 1. Try Supabase if user is signed in through Supabase
      const { data: user } = await supabase.auth.getUser().catch(() => ({ data: { user: null } }));

      if (user?.user) {
        const { data: existingBook } = await supabase
          .from("saved_books")
          .select()
          .eq("user_id", user.user.id)
          .eq("book_id", book.id)
          .single()
          .catch(() => ({ data: null }));

        if (existingBook) {
          toast.info("This book is already in your library");
          return true;
        }

        const category = book.categories && book.categories.length > 0 ? book.categories[0] : null;

        await supabase.from("saved_books").insert({
          user_id: user.user.id,
          book_id: book.id,
          title: book.title,
          authors: book.authors,
          thumbnail: book.thumbnail,
          category: category,
          description: book.description || null,
        }).catch(() => {});
      }

      // 2. Local storage persistence (always stored)
      const localBooks = getLocalSavedBooks();
      if (localBooks.some((b) => b.id === book.id)) {
        toast.info("This book is already in your library");
        return true;
      }

      // Clean book object for storage
      const bookToSave: Book = {
        id: book.id,
        title: book.title,
        authors: Array.isArray(book.authors) ? book.authors : [String(book.authors || "Unknown")],
        thumbnail: book.thumbnail || "/placeholder.svg",
        categories: book.categories || [],
        description: book.description || "",
        publishedDate: book.publishedDate || "",
        pageCount: book.pageCount || 0,
        averageRating: book.averageRating || 0,
        language: book.language || "en",
        previewLink: book.previewLink || "",
        publisher: book.publisher || "",
      };

      localBooks.unshift(bookToSave);
      saveLocalBooks(localBooks);
      toast.success(`"${book.title}" saved to your personal library`);
      return true;
    } catch (error) {
      console.error("Error in saveBook:", error);
      toast.error("Failed to save book");
      return false;
    }
  },

  // Get all saved books for the current user
  async getSavedBooks(): Promise<Book[]> {
    try {
      const { data: user } = await supabase.auth.getUser().catch(() => ({ data: { user: null } }));

      if (user?.user) {
        const { data, error } = await supabase
          .from("saved_books")
          .select("*")
          .eq("user_id", user.user.id);

        if (!error && data && data.length > 0) {
          return data.map((book) => ({
            id: book.book_id,
            title: book.title,
            authors: book.authors,
            thumbnail: book.thumbnail,
            categories: book.category ? [book.category] : [],
            description: book.description || "",
            publishedDate: "",
            pageCount: 0,
            language: "",
            previewLink: "",
            publisher: "",
          }));
        }
      }

      return getLocalSavedBooks();
    } catch (error) {
      console.error("Error in getSavedBooks:", error);
      return getLocalSavedBooks();
    }
  },

  // Remove a book from saved books
  async removeBook(bookId: string): Promise<boolean> {
    try {
      const { data: user } = await supabase.auth.getUser().catch(() => ({ data: { user: null } }));

      if (user?.user) {
        await supabase
          .from("saved_books")
          .delete()
          .eq("user_id", user.user.id)
          .eq("book_id", bookId)
          .catch(() => {});
      }

      const localBooks = getLocalSavedBooks().filter((b) => b.id !== bookId);
      saveLocalBooks(localBooks);
      toast.success("Book removed from your library");
      return true;
    } catch (error) {
      console.error("Error in removeBook:", error);
      toast.error("Failed to remove book");
      return false;
    }
  },

  // Check if a book is saved
  async isBookSaved(bookId: string): Promise<boolean> {
    const localBooks = getLocalSavedBooks();
    return localBooks.some((b) => b.id === bookId);
  },
};
