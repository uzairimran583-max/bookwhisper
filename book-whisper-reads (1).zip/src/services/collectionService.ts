
import { Book } from './bookService';

// Interface for collection data
export interface Collection {
  id: string;
  name: string;
  description: string;
  coverImage?: string;
  books: Book[];
}

// Mock collections for demonstration
const mockCollections: Collection[] = [
  {
    id: "bestsellers",
    name: "New York Times Bestsellers",
    description: "Top books from the New York Times Bestseller lists",
    coverImage: "/placeholder.svg",
    books: []  // Will be populated dynamically
  },
  {
    id: "scifi",
    name: "Science Fiction Classics",
    description: "Essential reads from the science fiction genre",
    coverImage: "/placeholder.svg",
    books: []  // Will be populated dynamically
  },
  {
    id: "fantasy",
    name: "Fantasy Adventures",
    description: "Magical worlds and epic quests",
    coverImage: "/placeholder.svg",
    books: []  // Will be populated dynamically
  }
];

// Collection service for managing book collections
class CollectionService {
  // Get all collections
  async getCollections(): Promise<Collection[]> {
    // In a real app, this would fetch from an API or database
    return mockCollections;
  }

  // Get a specific collection by ID
  async getCollection(id: string): Promise<{ data: Book[] }> {
    // In a real app, this would fetch from an API or database
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Find the collection
      const collection = mockCollections.find(c => c.id === id);
      
      if (!collection) {
        throw new Error(`Collection with ID ${id} not found`);
      }
      
      // Generate some mock books for the collection
      const mockBooks: Book[] = Array(8).fill(null).map((_, index) => ({
        id: `${id}-book-${index}`,
        title: `Book ${index + 1} in ${collection.name}`,
        authors: [`Author ${index + 1}`],
        description: `A sample book in the ${collection.name} collection.`,
        thumbnail: `/placeholder.svg`,
        publishedDate: `${2010 + Math.floor(Math.random() * 13)}-01-01`, // 2010-2023
        publishedYear: 2010 + Math.floor(Math.random() * 13), // 2010-2023
        pageCount: Math.floor(Math.random() * 400) + 100,
        categories: ["Fiction"],
        language: "en",
        previewLink: "",
        publisher: "Sample Publisher",
        averageRating: Math.floor(Math.random() * 5) + 1,
        ratingsCount: Math.floor(Math.random() * 100) + 10,
        isTrending: Math.random() > 0.7,
        billionaireRecommendation: false,
      }));
      
      return { data: mockBooks };
    } catch (error) {
      console.error(`Error fetching collection ${id}:`, error);
      return { data: [] };
    }
  }
}

// Export singleton instance
export const collectionService = new CollectionService();
