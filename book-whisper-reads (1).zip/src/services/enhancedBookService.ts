import { bookFetch } from "@/services/bookFetch";
import { toast } from "sonner";
import { Book } from "./bookService";
import { searchOpenLibraryBooks, getBookByISBN } from "./openLibraryService";

export interface EnhancedBook extends Book {
  isbn?: string;
  rating?: number;
  readingLevel?: string;
  subjects?: string[];
  editions?: number;
  firstPublishYear?: number;
  lastPublishYear?: number;
  sourceApi: 'openlibrary' | 'googlebooks' | 'combined';
}

// Enhanced search that combines both Open Library and Google Books
export const enhancedSearchBooks = async (
  query: string, 
  maxResults: number = 20,
  sources: ('openlibrary' | 'googlebooks')[] = ['openlibrary', 'googlebooks']
): Promise<EnhancedBook[]> => {
  const allBooks: EnhancedBook[] = [];
  
  try {
    // Search Open Library first
    if (sources.includes('openlibrary')) {
      console.log("Searching Open Library for:", query);
      const openLibraryBooks = await searchOpenLibraryBooks(query, Math.ceil(maxResults / 2));
      
      const enhancedOLBooks: EnhancedBook[] = openLibraryBooks.map(book => ({
        ...book,
        sourceApi: 'openlibrary' as const,
        subjects: book.categories,
        rating: Math.random() * 5 + 3, // Simulated rating
      }));
      
      allBooks.push(...enhancedOLBooks);
    }
    
    // Search Google Books as secondary
    if (sources.includes('googlebooks') && allBooks.length < maxResults) {
      console.log("Searching Google Books for:", query);
      const googleBooks = await searchGoogleBooks(query, maxResults - allBooks.length);
      allBooks.push(...googleBooks);
    }
    
    // Remove duplicates based on title and author
    const uniqueBooks = removeDuplicates(allBooks);
    
    // Sort by relevance (prioritize books with covers and more complete data)
    return uniqueBooks
      .sort((a, b) => {
        const scoreA = getBookRelevanceScore(a, query);
        const scoreB = getBookRelevanceScore(b, query);
        return scoreB - scoreA;
      })
      .slice(0, maxResults);
      
  } catch (error) {
    console.error("Error in enhanced search:", error);
    toast.error("Failed to search books. Please try again.");
    return [];
  }
};

// Search Google Books with enhanced data
const searchGoogleBooks = async (query: string, maxResults: number): Promise<EnhancedBook[]> => {
  try {
    const response = await bookFetch(
      `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}&maxResults=${maxResults}&fields=items(id,volumeInfo(title,authors,description,categories,imageLinks,publishedDate,pageCount,language,previewLink,publisher,averageRating,ratingsCount,industryIdentifiers))`
    );
    
    if (!response.ok) {
      throw new Error("Failed to fetch from Google Books");
    }
    
    const data = await response.json();
    
    if (!data.items) {
      return [];
    }
    
    return data.items.map((item: any): EnhancedBook => {
      const volumeInfo = item.volumeInfo || {};
      const publishedYear = volumeInfo.publishedDate ? 
        parseInt(volumeInfo.publishedDate.substring(0, 4), 10) : 
        undefined;
      
      return {
        id: item.id,
        title: volumeInfo.title || "Unknown Title",
        authors: volumeInfo.authors || ["Unknown Author"],
        description: volumeInfo.description || "No description available.",
        categories: volumeInfo.categories || [],
        thumbnail: volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || "/placeholder.svg",
        publishedDate: volumeInfo.publishedDate || "Unknown",
        publishedYear,
        pageCount: volumeInfo.pageCount || 0,
        language: volumeInfo.language || "en",
        previewLink: volumeInfo.previewLink || "",
        publisher: volumeInfo.publisher || "Unknown Publisher",
        averageRating: volumeInfo.averageRating,
        ratingsCount: volumeInfo.ratingsCount,
        isbn: volumeInfo.industryIdentifiers?.[0]?.identifier,
        rating: volumeInfo.averageRating,
        subjects: volumeInfo.categories,
        sourceApi: 'googlebooks'
      };
    });
  } catch (error) {
    console.error("Error searching Google Books:", error);
    return [];
  }
};

// Enhanced book discovery by genre with multiple sources
export const discoverBooksByGenre = async (
  genre: string,
  maxResults: number = 15
): Promise<EnhancedBook[]> => {
  try {
    // Get books from both sources
    const [openLibraryBooks, googleBooks] = await Promise.all([
      searchOpenLibraryBooks(`subject:${genre}`, Math.ceil(maxResults / 2)),
      searchGoogleBooks(`subject:${genre}`, Math.ceil(maxResults / 2))
    ]);
    
    const allBooks: EnhancedBook[] = [
      ...openLibraryBooks.map(book => ({ ...book, sourceApi: 'openlibrary' as const })),
      ...googleBooks
    ];
    
    const uniqueBooks = removeDuplicates(allBooks);
    
    return uniqueBooks
      .filter(book => book.thumbnail !== "/placeholder.svg") // Prioritize books with covers
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, maxResults);
      
  } catch (error) {
    console.error("Error discovering books by genre:", error);
    return [];
  }
};

// Get trending books with enhanced metadata
export const getEnhancedTrendingBooks = async (): Promise<EnhancedBook[]> => {
  try {
    const trendingGenres = ['fiction', 'mystery', 'science-fiction', 'business', 'self-help'];
    const promises = trendingGenres.map(genre => 
      discoverBooksByGenre(genre, 4)
    );
    
    const results = await Promise.all(promises);
    const allBooks = results.flat();
    
    // Mix and randomize for variety
    return allBooks
      .sort(() => Math.random() - 0.5)
      .slice(0, 20);
      
  } catch (error) {
    console.error("Error getting enhanced trending books:", error);
    return [];
  }
};

// Enhanced book details with ISBN lookup
export const getEnhancedBookDetails = async (
  bookId: string,
  source: 'openlibrary' | 'googlebooks' = 'googlebooks'
): Promise<EnhancedBook | null> => {
  try {
    if (source === 'googlebooks') {
      const response = await bookFetch(
        `https://www.googleapis.com/books/v1/volumes/${bookId}`
      );
      
      if (!response.ok) {
        throw new Error("Failed to fetch book details");
      }
      
      const data = await response.json();
      const volumeInfo = data.volumeInfo || {};
      
      // Try to get additional info from Open Library if ISBN available
      let openLibraryData = null;
      const isbn = volumeInfo.industryIdentifiers?.[0]?.identifier;
      if (isbn) {
        openLibraryData = await getBookByISBN(isbn);
      }
      
      return {
        id: data.id,
        title: volumeInfo.title || "Unknown Title",
        authors: volumeInfo.authors || ["Unknown Author"],
        description: volumeInfo.description || openLibraryData?.description || "No description available.",
        categories: volumeInfo.categories || [],
        thumbnail: volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || "/placeholder.svg",
        publishedDate: volumeInfo.publishedDate || "Unknown",
        publishedYear: volumeInfo.publishedDate ? parseInt(volumeInfo.publishedDate.substring(0, 4), 10) : undefined,
        pageCount: volumeInfo.pageCount || 0,
        language: volumeInfo.language || "en",
        previewLink: volumeInfo.previewLink || "",
        publisher: volumeInfo.publisher || "Unknown Publisher",
        averageRating: volumeInfo.averageRating,
        ratingsCount: volumeInfo.ratingsCount,
        isbn,
        rating: volumeInfo.averageRating,
        subjects: volumeInfo.categories,
        sourceApi: 'combined'
      };
    }
    
    // Handle Open Library source
    return null;
  } catch (error) {
    console.error("Error getting enhanced book details:", error);
    return null;
  }
};

// Utility functions
const removeDuplicates = (books: EnhancedBook[]): EnhancedBook[] => {
  const seen = new Set<string>();
  return books.filter(book => {
    const key = `${book.title.toLowerCase()}-${book.authors[0]?.toLowerCase()}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
};

const getBookRelevanceScore = (book: EnhancedBook, query: string): number => {
  let score = 0;
  const queryLower = query.toLowerCase();
  
  // Title match
  if (book.title.toLowerCase().includes(queryLower)) {
    score += 10;
  }
  
  // Author match
  if (book.authors.some(author => author.toLowerCase().includes(queryLower))) {
    score += 8;
  }
  
  // Has cover
  if (book.thumbnail && book.thumbnail !== "/placeholder.svg") {
    score += 5;
  }
  
  // Has description
  if (book.description && book.description.length > 50) {
    score += 3;
  }
  
  // Has rating
  if (book.rating && book.rating > 0) {
    score += 2;
  }
  
  // Recent publication
  if (book.publishedYear && book.publishedYear > 2000) {
    score += 1;
  }
  
  return score;
};

// Get personalized recommendations based on reading history
export const getPersonalizedRecommendations = async (
  favoriteGenres: string[],
  readBooks: string[],
  maxResults: number = 10
): Promise<EnhancedBook[]> => {
  try {
    const recommendations: EnhancedBook[] = [];
    
    // Get books from favorite genres
    for (const genre of favoriteGenres.slice(0, 3)) {
      const genreBooks = await discoverBooksByGenre(genre, 5);
      recommendations.push(...genreBooks);
    }
    
    // Filter out already read books
    const filteredBooks = recommendations.filter(book => 
      !readBooks.includes(book.id)
    );
    
    return removeDuplicates(filteredBooks)
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, maxResults);
      
  } catch (error) {
    console.error("Error getting personalized recommendations:", error);
    return [];
  }
};