import { bookFetch } from "@/services/bookFetch";
import { toast } from "sonner";
import { CURATED_BOOKS, findCuratedBook, searchCuratedBooks, getRelativeCuratedBooks } from "./curatedBooks";
import { allBillionaireRecommendations } from "@/data/billionaireRecommendations";

export interface Book {
  id: string;
  title: string;
  authors: string[];
  description: string;
  categories: string[];
  thumbnail: string;
  publishedDate: string;
  pageCount: number;
  language: string;
  previewLink: string;
  publisher: string;
  averageRating?: number;
  ratingsCount?: number;
  publishedYear?: number;
  isTrending?: boolean;
  billionaireRecommendation?: {
    billionaire: string;
    quote: string;
  } | boolean;
}

const BASE_URL = "https://www.googleapis.com/books/v1/volumes";
const GUTENDEX_URL = "https://gutendex.com/books";

// In-memory cache to make searches and repeated book fetches instant
const booksCache = new Map<string, Book>();
CURATED_BOOKS.forEach(b => booksCache.set(b.id, b));

// Enhanced image URL optimization with secure HTTPS and high-res params
const optimizeImageUrl = (url: string): string => {
  if (!url) return "/placeholder.svg";
  
  // Force HTTPS
  let optimizedUrl = url.replace('http:', 'https:');
  
  // Optimize Google Books images
  if (optimizedUrl.includes("books.google.com")) {
    optimizedUrl = optimizedUrl.replace(/&edge=curl/g, '');
    if (!optimizedUrl.includes('zoom=')) {
      optimizedUrl += '&zoom=1';
    }
  }
  
  // Optimize OpenLibrary covers
  if (optimizedUrl.includes("covers.openlibrary.org")) {
    optimizedUrl = optimizedUrl.replace(/-S\.jpg/, '-M.jpg');
  }

  return optimizedUrl;
};

// Helper function to parse book data from Google Books API
const parseBookData = (item: any): Book => {
  const volumeInfo = item.volumeInfo || {};
  const publishedYear = volumeInfo.publishedDate ? 
    parseInt(volumeInfo.publishedDate.substring(0, 4), 10) : 
    undefined;
  
  // Get and optimize thumbnail
  const rawThumbnail = volumeInfo.imageLinks?.thumbnail || 
                      volumeInfo.imageLinks?.smallThumbnail || 
                      "/placeholder.svg";
  const optimizedThumbnail = optimizeImageUrl(rawThumbnail);
  
  return {
    id: item.id,
    title: volumeInfo.title || "Unknown Title",
    authors: volumeInfo.authors || ["Unknown Author"],
    description: volumeInfo.description || "No description available.",
    categories: volumeInfo.categories || [],
    thumbnail: optimizedThumbnail,
    publishedDate: volumeInfo.publishedDate || "Unknown",
    publishedYear,
    pageCount: volumeInfo.pageCount || 0,
    language: volumeInfo.language || "en",
    previewLink: volumeInfo.previewLink || "",
    publisher: volumeInfo.publisher || "Unknown Publisher",
    averageRating: volumeInfo.averageRating,
    ratingsCount: volumeInfo.ratingsCount
  };
};

// Map an OpenLibrary search document to our Book shape
const parseOpenLibraryDoc = (doc: any): Book => {
  const year = doc.first_publish_year || undefined;
  return {
    id: (doc.key || "").replace("/works/", ""),
    title: doc.title || "Unknown Title",
    authors: doc.author_name || ["Unknown Author"],
    description: Array.isArray(doc.first_sentence)
      ? doc.first_sentence.join(". ")
      : doc.first_sentence || "No description available.",
    categories: doc.subject?.slice(0, 3) || [],
    thumbnail: doc.cover_i
      ? optimizeImageUrl(`https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg`)
      : "/placeholder.svg",
    publishedDate: year ? String(year) : "Unknown",
    publishedYear: year,
    pageCount: doc.number_of_pages_median || 0,
    language: doc.language?.[0] || "en",
    previewLink: doc.key ? `https://openlibrary.org${doc.key}` : "",
    publisher: doc.publisher?.[0] || "Unknown Publisher",
  };
};

// Search OpenLibrary — used as a fallback whenever Google Books is unavailable
const searchOpenLibrary = async (query: string, limit: number): Promise<Book[]> => {
  const response = await bookFetch(
    `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=${limit}&fields=key,title,author_name,first_publish_year,cover_i,subject,number_of_pages_median,language,publisher,first_sentence`
  );

  if (!response.ok) {
    throw new Error("OpenLibrary API error");
  }

  const data = await response.json();
  return (data.docs || []).map(parseOpenLibraryDoc).filter((b: Book) => b.id && b.title);
};

// Fast subject browse endpoint (much quicker than solr search for categories)
const getOpenLibrarySubject = async (
  subject: string,
  limit: number,
  publishedIn?: string
): Promise<Book[]> => {
  const slug = subject.toLowerCase().trim().replace(/\s+/g, "_");
  const publishedParam = publishedIn ? `&published_in=${publishedIn}` : "";
  const response = await bookFetch(
    `https://openlibrary.org/subjects/${encodeURIComponent(slug)}.json?limit=${limit}${publishedParam}`
  );

  if (!response.ok) {
    throw new Error("OpenLibrary subject API error");
  }

  const data = await response.json();
  return (data.works || []).map((work: any): Book => ({
    id: (work.key || "").replace("/works/", ""),
    title: work.title || "Unknown Title",
    authors: (work.authors || []).map((a: any) => a.name) || ["Unknown Author"],
    description: "No description available.",
    categories: (work.subject || []).slice(0, 3),
    thumbnail: work.cover_id
      ? optimizeImageUrl(`https://covers.openlibrary.org/b/id/${work.cover_id}-M.jpg`)
      : "/placeholder.svg",
    publishedDate: work.first_publish_year ? String(work.first_publish_year) : "Unknown",
    publishedYear: work.first_publish_year,
    pageCount: 0,
    language: "en",
    previewLink: work.key ? `https://openlibrary.org${work.key}` : "",
    publisher: "Unknown Publisher",
  })).filter((b: Book) => b.id && b.title);
};


// Search books: Google Books with relevance sorting + curated catalogue priority + OpenLibrary fallback
export const searchBooks = async (query: string, maxResults: number = 20): Promise<Book[]> => {
  const cleanQuery = query.trim().toLowerCase();
  if (!cleanQuery) return [];

  // 1. Local curated matches for instant responsiveness and quality
  const localMatches = searchCuratedBooks(cleanQuery);

  // 2. Billionaire recommendation matches (e.g., Elon, Buffett, Gates, Thiel, AI, etc.)
  const billionaireMatches: Book[] = [];
  for (const rec of allBillionaireRecommendations) {
    const isBillionaireMatch = rec.billionaire.toLowerCase().includes(cleanQuery);
    for (const b of rec.books) {
      if (
        isBillionaireMatch ||
        b.title.toLowerCase().includes(cleanQuery) ||
        b.authors.some(a => a.toLowerCase().includes(cleanQuery)) ||
        (b.quote && b.quote.toLowerCase().includes(cleanQuery))
      ) {
        if (!billionaireMatches.some(bm => bm.id === b.id)) {
          billionaireMatches.push({
            id: b.id,
            title: b.title,
            authors: b.authors,
            description: `Recommended by ${rec.billionaire}: "${b.quote || 'Essential reading.'}"`,
            categories: ["Business", "Strategy", "Leadership"],
            thumbnail: b.thumbnail,
            publishedDate: "2018",
            pageCount: 320,
            language: "en",
            previewLink: "",
            publisher: "Bestseller Editions",
            averageRating: 4.8,
            ratingsCount: 5200,
            billionaireRecommendation: {
              billionaire: rec.billionaire,
              quote: b.quote || ""
            }
          });
        }
      }
    }
  }

  // Curated + billionaire matches combined
  const instantMatches = [...localMatches];
  for (const bm of billionaireMatches) {
    if (!instantMatches.some(im => im.id === bm.id || im.title.toLowerCase() === bm.title.toLowerCase())) {
      instantMatches.push(bm);
    }
  }

  // 3. Try Google Books API with clean query
  try {
    const fieldsParam = "items(id,volumeInfo(title,authors,description,categories,imageLinks,publishedDate,pageCount,language,previewLink,publisher,averageRating,ratingsCount,industryIdentifiers))";
    const response = await bookFetch(
      `${BASE_URL}?q=${encodeURIComponent(cleanQuery)}&maxResults=${maxResults}&orderBy=relevance&fields=${fieldsParam}`
    );

    if (response.ok) {
      const data = await response.json();
      if (data.items && data.items.length > 0) {
        const googleBooks: Book[] = data.items.map(parseBookData);
        googleBooks.forEach(b => booksCache.set(b.id, b));

        // Combine: curated & billionaire matches first, then Google Books
        const combined = [...instantMatches];
        for (const gb of googleBooks) {
          if (!combined.some(c => c.title.toLowerCase() === gb.title.toLowerCase())) {
            combined.push(gb);
          }
        }
        return combined.slice(0, maxResults);
      }
    }
  } catch (error) {
    console.warn("Google Books search failed, trying fallback:", error);
  }

  // Fallback 1: Try OpenLibrary
  try {
    const olBooks = await searchOpenLibrary(cleanQuery, maxResults);
    if (olBooks.length > 0) {
      olBooks.forEach(b => booksCache.set(b.id, b));
      const combined = [...instantMatches];
      for (const ob of olBooks) {
        if (!combined.some(c => c.title.toLowerCase() === ob.title.toLowerCase())) {
          combined.push(ob);
        }
      }
      return combined.slice(0, maxResults);
    }
  } catch (olError) {
    console.warn("OpenLibrary search failed:", olError);
  }

  // Fallback 2: Curated & billionaire matching books
  if (instantMatches.length > 0) {
    return instantMatches.slice(0, maxResults);
  }

  return [];
};

/**
 * Finds books relative / related to a book or search query
 * Surfaces books in same domain, similar topics, or complementary themes
 */
export const getRelativeBooks = async (
  queryOrBook: string | Book,
  limit: number = 8
): Promise<Book[]> => {
  let targetCategory = "";
  let targetAuthor = "";
  let queryText = "";
  let excludeId = "";

  if (typeof queryOrBook === "string") {
    queryText = queryOrBook.trim();
  } else {
    queryText = queryOrBook.title;
    excludeId = queryOrBook.id;
    targetCategory = queryOrBook.categories?.[0] || "";
    targetAuthor = queryOrBook.authors?.[0] || "";
  }

  // 1. Curated relative picks
  const curatedRelative = getRelativeCuratedBooks(targetCategory || queryText, excludeId, limit);
  if (curatedRelative.length >= limit) {
    return curatedRelative.slice(0, limit);
  }

  // 2. Fetch category or author relative picks if available
  try {
    const target = targetCategory || targetAuthor || queryText;
    if (target) {
      const more = await getBooksByCategory(target, limit);
      const combined = [...curatedRelative];
      for (const b of more) {
        if (b.id !== excludeId && !combined.some(c => c.id === b.id || c.title.toLowerCase() === b.title.toLowerCase())) {
          combined.push(b);
        }
      }
      return combined.slice(0, limit);
    }
  } catch (err) {
    console.warn("Could not fetch remote relative books:", err);
  }

  return curatedRelative;
};

// Category browse: Google Books + Curated priority + OpenLibrary
export const getBooksByCategory = async (
  category: string,
  maxResults: number = 12
): Promise<Book[]> => {
  const normalizedCategory = category.toLowerCase().trim();
  const curatedForCategory = CURATED_BOOKS.filter(b => 
    b.categories.some(c => c.toLowerCase().includes(normalizedCategory) || normalizedCategory.includes(c.toLowerCase()))
  );

  try {
    const fieldsParam = "items(id,volumeInfo(title,authors,description,categories,imageLinks,publishedDate,pageCount,language,previewLink,publisher,averageRating,ratingsCount))";
    const response = await bookFetch(
      `${BASE_URL}?q=subject:${encodeURIComponent(category)}&maxResults=${maxResults}&orderBy=relevance&fields=${fieldsParam}`
    );

    if (response.ok) {
      const data = await response.json();
      if (data.items && data.items.length > 0) {
        const books: Book[] = data.items.map(parseBookData);
        books.forEach(b => booksCache.set(b.id, b));
        
        // Merge curated books for this category
        const combined = [...curatedForCategory];
        for (const b of books) {
          if (!combined.some(c => c.title.toLowerCase() === b.title.toLowerCase())) {
            combined.push(b);
          }
        }
        return combined.slice(0, maxResults);
      }
    }
  } catch (error) {
    console.warn(`Error fetching ${category} from Google Books:`, error);
  }

  // Fallback to OpenLibrary
  try {
    const olBooks = await getOpenLibrarySubject(category, maxResults);
    if (olBooks.length > 0) {
      return [...curatedForCategory, ...olBooks].slice(0, maxResults);
    }
  } catch (olError) {
    console.warn(`OpenLibrary subject failed for ${category}:`, olError);
  }

  return curatedForCategory.length > 0 ? curatedForCategory : CURATED_BOOKS.slice(0, maxResults);
};

// Enhanced single book fetch with robust fallbacks
export const getBookById = async (id: string): Promise<Book | null> => {
  if (!id) return null;

  // 1. Check in-memory cache and curated catalog
  if (booksCache.has(id)) {
    return booksCache.get(id)!;
  }
  const curated = findCuratedBook(id);
  if (curated) {
    booksCache.set(id, curated);
    return curated;
  }

  // 2. Check billionaire recommendations
  if (id.startsWith("billionaire-")) {
    for (const rec of allBillionaireRecommendations) {
      const found = rec.books.find(b => b.id === id);
      if (found) {
        const bookObj: Book = {
          id: found.id,
          title: found.title,
          authors: found.authors,
          description: `Recommended by ${rec.billionaire}: "${found.quote || 'An essential read on strategy and growth.'}" A defining work that has shaped top leaders and innovators around the world.`,
          categories: ["Business", "Biography", "Strategy"],
          thumbnail: found.thumbnail,
          publishedDate: "2015",
          publishedYear: 2015,
          pageCount: 320,
          language: "en",
          previewLink: "",
          publisher: "Bestseller Editions",
          averageRating: 4.8,
          ratingsCount: 5200,
          billionaireRecommendation: {
            billionaire: rec.billionaire,
            quote: found.quote || ""
          }
        };
        booksCache.set(id, bookObj);
        return bookObj;
      }
    }
  }

  // 3. OpenLibrary work ids (e.g. OL123W)
  if (/^OL\w+W$/i.test(id)) {
    const olBook = await getOpenLibraryWork(id);
    if (olBook) {
      booksCache.set(id, olBook);
      return olBook;
    }
  }

  // 4. Google Books Volume ID
  try {
    const response = await bookFetch(`${BASE_URL}/${id}`);
    if (response.ok) {
      const data = await response.json();
      const book = parseBookData(data);
      booksCache.set(id, book);
      return book;
    }
  } catch (error) {
    console.warn("Google Books volume fetch failed:", error);
  }

  // 5. Fallback: Search OpenLibrary or curated by ID or title
  try {
    const olBook = await getOpenLibraryWork(id);
    if (olBook) {
      booksCache.set(id, olBook);
      return olBook;
    }
  } catch (err) {
    console.warn("Could not fetch OpenLibrary work:", err);
  }

  // 6. Last resort: check if query matches any curated title
  const fallback = findCuratedBook(id.replace(/-/g, " "));
  if (fallback) return fallback;

  return null;
};

// Fetch a single work from OpenLibrary
const getOpenLibraryWork = async (id: string): Promise<Book | null> => {
  try {
    const workId = id.replace("/works/", "");
    const response = await bookFetch(`https://openlibrary.org/works/${workId}.json`);
    if (!response.ok) return null;

    const data = await response.json();
    const cover = data.covers?.[0];

    let authors: string[] = [];
    const authorKey = data.authors?.[0]?.author?.key;
    if (authorKey) {
      try {
        const authorRes = await bookFetch(`https://openlibrary.org${authorKey}.json`);
        if (authorRes.ok) {
          const authorData = await authorRes.json();
          if (authorData.name) authors = [authorData.name];
        }
      } catch {
        // ignore author lookup failures
      }
    }

    return {
      id: workId,
      title: data.title || "Unknown Title",
      authors: authors.length ? authors : ["Unknown Author"],
      description:
        typeof data.description === "string"
          ? data.description
          : data.description?.value || "No description available.",
      categories: data.subjects?.slice(0, 3) || [],
      thumbnail: cover
        ? optimizeImageUrl(`https://covers.openlibrary.org/b/id/${cover}-L.jpg`)
        : "/placeholder.svg",
      publishedDate: data.first_publish_date || "Unknown",
      pageCount: 0,
      language: "en",
      previewLink: `https://openlibrary.org/works/${workId}`,
      publisher: "Unknown Publisher",
    };
  } catch (error) {
    console.error("OpenLibrary work fetch failed:", error);
    return null;
  }
};


// Enhanced trending books with image prioritization and curated fallback
export const getTrendingBooks = async (): Promise<Book[]> => {
  try {
    const categories = ["business", "self-help", "psychology", "technology"];
    const promises = categories.map(category =>
      getBooksByCategory(category, 4).catch(() => [] as Book[])
    );

    const results = await Promise.all(promises);
    const allBooks = results.flat();
    
    // Prioritize books with actual images
    const booksWithImages = allBooks.filter(book => 
      book.thumbnail && !book.thumbnail.includes("placeholder")
    );
    
    const combined = [...CURATED_BOOKS.filter(b => b.isTrending), ...booksWithImages];
    const unique = Array.from(new Map(combined.map(b => [b.title.toLowerCase(), b])).values());
    
    return unique.slice(0, 16);
  } catch (error) {
    console.error("Error fetching trending books:", error);
    return CURATED_BOOKS.slice(0, 12);
  }
};

// Get modern books published from 2007 onwards
export async function getModernBooks(limit = 10): Promise<Book[]> {
  try {
    const subjects = ["self-help", "business", "psychology", "fiction"];
    const results = await Promise.all(
      subjects.map(subject =>
        getOpenLibrarySubject(subject, Math.ceil(limit / 2), "2010-2026").catch(() => [] as Book[])
      )
    );

    const books = results
      .flat()
      .filter(book => book.thumbnail && !book.thumbnail.includes("placeholder"));

    // de-duplicate by id
    const unique = Array.from(new Map(books.map(b => [b.id, b])).values());
    const shuffled = unique.sort(() => Math.random() - 0.5).slice(0, limit);

    if (shuffled.length > 0) {
      console.log(`Found ${shuffled.length} modern books`);
      return shuffled;
    }

    const gBooks = await fetchGoogleBooksModern(limit);
    if (gBooks && gBooks.length > 0) return gBooks;
    return CURATED_BOOKS.slice(0, limit);
  } catch (error) {
    console.error("Error fetching modern books:", error);
    const gBooks = await fetchGoogleBooksModern(limit);
    if (gBooks && gBooks.length > 0) return gBooks;
    return CURATED_BOOKS.slice(0, limit);
  }
}


async function fetchGoogleBooksModern(limit = 10): Promise<Book[]> {
  try {
    const maxResults = Math.min(limit, 40);
    const startYear = 2007;
    const currentYear = new Date().getFullYear();
    
    const fieldsParam = "items(id,volumeInfo(title,authors,description,categories,imageLinks,publishedDate,pageCount,language,previewLink,publisher,industryIdentifiers))";
    const url = `${BASE_URL}?q=subject:fiction+inpublisher:penguin&maxResults=${maxResults}&fields=${fieldsParam}`;
    
    console.log("Fetching modern books from Google Books API:", url);
    const response = await bookFetch(url);
    
    if (!response.ok) {
      throw new Error("Google Books API error");
    }
    
    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      return [];
    }
    
    const books: Book[] = data.items
      .filter((item: any) => {
        const publishedDateStr = item.volumeInfo?.publishedDate;
        if (!publishedDateStr) return false;
        
        const publishedYear = parseInt(publishedDateStr.substring(0, 4), 10);
        return !isNaN(publishedYear) && publishedYear >= startYear && publishedYear <= currentYear;
      })
      .filter((item: any) => item.volumeInfo?.imageLinks?.thumbnail)
      .map((item: any) => {
        const publishedYear = parseInt(item.volumeInfo.publishedDate.substring(0, 4), 10);
        const rawThumbnail = item.volumeInfo.imageLinks?.thumbnail;
        
        return {
          id: item.id,
          title: item.volumeInfo.title,
          authors: item.volumeInfo.authors || ['Unknown Author'],
          description: item.volumeInfo.description || '',
          thumbnail: optimizeImageUrl(rawThumbnail),
          categories: item.volumeInfo.categories || [],
          pageCount: item.volumeInfo.pageCount || 0,
          publishedYear,
          publishedDate: item.volumeInfo.publishedDate,
          language: item.volumeInfo.language || "en",
          previewLink: item.volumeInfo.previewLink || "",
          publisher: item.volumeInfo.publisher || "Unknown Publisher",
        };
      });
    
    console.log(`Found ${books.length} modern books from Google Books with optimized images`);
    return books.length > 0 ? books.slice(0, limit) : CURATED_BOOKS.slice(0, limit);
  } catch (error) {
    console.error("Error fetching modern books from Google Books API:", error);
    return CURATED_BOOKS.slice(0, limit);
  }
}

export const getGutendexBooks = async (query: string, maxResults: number = 10): Promise<any[]> => {
  try {
    const response = await bookFetch(
      `${GUTENDEX_URL}?search=${encodeURIComponent(query)}&page=1`
    );
    
    if (!response.ok) {
      throw new Error("Failed to fetch books from Gutendex");
    }
    
    const data = await response.json();
    return data.results ? data.results.slice(0, maxResults) : [];
  } catch (error) {
    console.error("Error fetching Gutendex books:", error);
    return [];
  }
};
