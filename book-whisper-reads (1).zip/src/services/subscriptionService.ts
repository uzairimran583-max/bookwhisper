import { toast } from "sonner";

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  bookLimit: number;
  features: string[];
  period: 'monthly' | 'yearly';
  aiSummaryLimit: number;
  aiChatLimit: number;
  audibleLimit: number;
}

export interface UserSubscription {
  planId: string;
  startDate: string;
  endDate: string;
  booksAccessed: string[];
  isTrial: boolean;
  summariesUsed: number;
  chatsUsed: number;
  audibleUsed: number;
  savedBooks: string[];
  lastResetTime: string;
}

// Updated subscription plans - everything unlimited and free
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free (Unlimited)',
    price: 0,
    bookLimit: 999999, // Effectively unlimited
    features: [
      'Unlimited book access',
      'Unlimited AI summaries',
      'Unlimited AI chat messages',
      'Audio summaries included',
      'All features free forever',
    ],
    period: 'monthly',
    aiSummaryLimit: 999999, // Effectively unlimited
    aiChatLimit: 999999, // Effectively unlimited
    audibleLimit: 999999 // Audio now included
  }
];

class SubscriptionService {
  private storageKey = 'user_subscription';
  private trialDurationDays = 365;
  private readingTimeKey = 'readingTime';
  private savedBooksKey = 'saved_books';
  private resetIntervalHours = 24;

  constructor() {
    console.log('SubscriptionService: All features are now unlimited and free');
  }

  // No longer require authentication since everything is free
  private isUserAuthenticated(): boolean {
    return true; // Always return true since everything is free
  }

  private requireAuthentication(): boolean {
    return true; // Always allow access since everything is free
  }

  private initializeIfNeeded(): void {
    // Always initialize the unlimited free plan
    this.initializeFreePlan();
  }

  private initializeFreePlan(): void {
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + this.trialDurationDays);

    const freeSubscription: UserSubscription = {
      planId: 'free',
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      booksAccessed: [],
      isTrial: false,
      summariesUsed: 0,
      chatsUsed: 0,
      audibleUsed: 0,
      savedBooks: [],
      lastResetTime: startDate.toISOString()
    };

    localStorage.setItem(this.storageKey, JSON.stringify(freeSubscription));
    console.log("SubscriptionService: Unlimited free plan initialized", freeSubscription);
  }
  
  // No longer need to check and reset usage since everything is unlimited
  private checkAndResetUsage(): void {
    // No-op since everything is unlimited
  }

  private getUserSubscriptionRaw(): UserSubscription | null {
    const data = localStorage.getItem(this.storageKey);
    return data ? JSON.parse(data) : null;
  }

  getUserSubscription(): UserSubscription | null {
    let subscription = this.getUserSubscriptionRaw();
    
    if (!subscription) {
      this.initializeFreePlan();
      subscription = this.getUserSubscriptionRaw();
    }
    
    return subscription;
  }

  getCurrentPlan(): SubscriptionPlan {
    return subscriptionPlans[0]; // Always return the unlimited free plan
  }

  updateSubscription(planId: string): boolean {
    // Everything is free, so just acknowledge
    toast.success("You're on the unlimited free plan - all features included!");
    return true;
  }

  saveBook(bookId: string): boolean {
    try {
      let subscription = this.getUserSubscription();
      if (!subscription) {
        this.initializeFreePlan();
        subscription = this.getUserSubscription();
        if (!subscription) return false;
      }
      
      if (!subscription.savedBooks.includes(bookId)) {
        subscription.savedBooks.push(bookId);
        localStorage.setItem(this.storageKey, JSON.stringify(subscription));
        toast.success("Book saved to your collection");
      }
      
      return true;
    } catch (error) {
      console.error("Error saving book:", error);
      toast.error("Failed to save book");
      return false;
    }
  }
  
  removeSavedBook(bookId: string): boolean {
    try {
      const subscription = this.getUserSubscription();
      if (!subscription) return false;
      
      subscription.savedBooks = subscription.savedBooks.filter(id => id !== bookId);
      localStorage.setItem(this.storageKey, JSON.stringify(subscription));
      toast.success("Book removed from your collection");
      
      return true;
    } catch (error) {
      console.error("Error removing book:", error);
      toast.error("Failed to remove book");
      return false;
    }
  }
  
  getSavedBooks(): string[] {
    const subscription = this.getUserSubscription();
    if (!subscription) return [];
    
    return subscription.savedBooks || [];
  }

  isBookSaved(bookId: string): boolean {
    const subscription = this.getUserSubscription();
    if (!subscription) return false;
    
    return subscription.savedBooks.includes(bookId);
  }

  // Always allow book access since everything is free
  canAccessBook(bookId: string): boolean {
    let subscription = this.getUserSubscription();
    if (!subscription) {
      this.initializeFreePlan();
      subscription = this.getUserSubscription();
      if (!subscription) return false;
    }

    // Always allow access and track it
    if (!subscription.booksAccessed.includes(bookId)) {
      subscription.booksAccessed.push(bookId);
      localStorage.setItem(this.storageKey, JSON.stringify(subscription));
    }
    
    return true;
  }

  isInTrialPeriod(): boolean {
    return false; // No trial needed since everything is free
  }

  getDaysRemaining(): number {
    return 999999; // Effectively unlimited
  }

  getBooksRemaining(): number {
    return 999999; // Effectively unlimited
  }

  // Always allow AI summary since everything is free
  canUseAISummary(): boolean {
    console.log("SubscriptionService: AI Summary - unlimited access");
    return true;
  }
  
  // Always allow AI chat since everything is free
  canUseAIChat(): boolean {
    console.log("SubscriptionService: AI Chat - unlimited access");
    return true;
  }
  
  // Always allow audio since everything is free
  canAccessAudio(): boolean {
    console.log("SubscriptionService: Audio - unlimited access");
    return true;
  }
  
  trackReadingTime(minutes: number): void {
    const currentTime = parseInt(localStorage.getItem(this.readingTimeKey) || "0");
    const newTime = currentTime + minutes;
    localStorage.setItem(this.readingTimeKey, newTime.toString());
  }
  
  getReadingTime(): number {
    return parseInt(localStorage.getItem(this.readingTimeKey) || "0");
  }
  
  getTimeUntilReset(): string {
    return "Unlimited"; // No reset needed since everything is unlimited
  }
  
  // No longer need to reset since everything is unlimited
  resetUsageCounts(): void {
    console.log("SubscriptionService: No usage limits to reset - everything unlimited");
  }

  // Keep these for compatibility but they don't affect limits
  incrementAISummaryUsage(): void {
    console.log("SubscriptionService: AI Summary used - unlimited access");
  }

  incrementAIChatUsage(): void {
    console.log("SubscriptionService: AI Chat used - unlimited access");
  }

  // Initialize unlimited subscription for all users
  initializeUserSubscription(): void {
    this.initializeFreePlan();
    console.log("SubscriptionService: Unlimited free plan initialized for user");
  }
}

export const subscriptionService = new SubscriptionService();
