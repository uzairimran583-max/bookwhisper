const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;

const hasValidProxy = Boolean(
  SUPABASE_URL &&
  typeof SUPABASE_URL === "string" &&
  !SUPABASE_URL.includes("placeholder") &&
  !SUPABASE_URL.startsWith("undefined") &&
  SUPABASE_URL.startsWith("http")
);

const PROXY_URL = hasValidProxy ? `${SUPABASE_URL}/functions/v1/books-proxy` : "";

/**
 * Fetches public book APIs (Google Books, OpenLibrary, Gutendex).
 * If a valid Supabase proxy is configured, routes through it;
 * otherwise performs direct browser fetch with built-in timeout.
 */
const TIMEOUT_MS = 8500;

function withTimeout(input: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  return fetch(input, { ...init, signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

export async function bookFetch(url: string, init?: RequestInit): Promise<Response> {
  if (hasValidProxy && PROXY_URL) {
    try {
      const response = await withTimeout(`${PROXY_URL}?url=${encodeURIComponent(url)}`, { method: "GET" });
      if (response.ok || response.status === 404) {
        return response;
      }
    } catch {
      // Proceed to direct fetch
    }
  }

  return withTimeout(url, init);
}


