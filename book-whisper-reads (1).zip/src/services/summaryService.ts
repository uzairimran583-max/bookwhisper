import { toast } from "sonner";
import { freemiumService } from "./freemiumService";
import { subscriptionService } from "./subscriptionService";

// Interface for summary results
export interface Summary {
  content: string;
  isGenerated: boolean;
}

// Flag to toggle between online and offline mode for testing
const USE_OFFLINE_MODE = false;

// Google Gemini API key - in a production environment, this should be stored securely
const GEMINI_API_KEY = "AIzaSyDa9xh7cdaItB_JuNnHQlscMf0uVtrH0gQ";

// Function to generate a summary using Google Gemini API
export const generateSummary = async (text: string): Promise<Summary> => {
  // For very short descriptions, we return the original text
  if (text.length < 200) {
    console.log("Text too short for summary, returning original text");
    return {
      content: text,
      isGenerated: false
    };
  }

  console.log("Generating unlimited AI summary...");

  if (USE_OFFLINE_MODE) {
    console.log("Using offline mode for summary generation");
    return createFallbackSummary(text);
  }

  try {
    console.log("Generating AI summary with Google Gemini AI (unlimited access)...");
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `You are an AI book assistant that creates concise and informative book summaries. Include key themes, important quotes, and main arguments. Structure your summary with clear paragraphs. Please provide a comprehensive summary of the following book description in about 500 words. Include structure, main themes, and insights: "${text}"`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.3,
            topP: 0.8,
            topK: 40,
            maxOutputTokens: 1024
          }
        }),
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Google Gemini API error:", response.status, response.statusText, errorText);
      return createFallbackSummary(text);
    }

    const result = await response.json();
    console.log("AI Summary generation successful (unlimited access):", result);

    if (result.candidates && result.candidates.length > 0 && result.candidates[0].content.parts[0].text) {
      const sanitizedSummary = freemiumService.sanitizeHTML(result.candidates[0].content.parts[0].text);
      // No longer increment usage since everything is unlimited
      return {
        content: sanitizedSummary,
        isGenerated: true
      };
    } else {
      console.error("Invalid API response format:", result);
      return createFallbackSummary(text);
    }
  } catch (error) {
    console.error("Error generating summary:", error);
    return createFallbackSummary(text);
  }
};

// Helper function to create a fallback summary when the API fails
const createFallbackSummary = (text: string): Summary => {
  console.log("Using fallback summary generation");
  // More comprehensive extraction-based summary
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  
  // For longer texts, extract more sentences to create a more comprehensive summary
  const summaryLength = Math.min(20, sentences.length); // Increased for longer summaries
  
  // Select sentences evenly distributed through the text
  let summaryText = "";
  if (sentences.length <= 20) {
    summaryText = sentences.join(" ");
  } else {
    // Select first five sentences for context
    summaryText = sentences.slice(0, 5).join(" ");
    
    // Select some sentences from the middle
    const middleStart = Math.floor(sentences.length / 3);
    summaryText += " " + sentences.slice(middleStart, middleStart + 8).join(" ");
    
    // Select some sentences from the end for conclusion
    summaryText += " " + sentences.slice(sentences.length - 7).join(" ");
  }
  
  // Sanitize the summary to fix HTML rendering issues
  const sanitizedSummary = freemiumService.sanitizeHTML(summaryText || text.slice(0, 800) + "...");
  
  return {
    content: structureSummary(sanitizedSummary),
    isGenerated: false
  };
};

// Helper function to enhance the summary with structure
const enhanceSummary = (text: string): string => {
  // Format the summary to be more readable with paragraphs
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  
  if (sentences.length <= 3) {
    return text;
  }
  
  // Create paragraphs from groups of sentences
  let paragraphs = [];
  const paragraphSize = Math.ceil(sentences.length / 3);
  
  // Introduction
  paragraphs.push(sentences.slice(0, paragraphSize).join(" "));
  
  // Main content
  paragraphs.push(sentences.slice(paragraphSize, paragraphSize * 2).join(" "));
  
  // Conclusion
  paragraphs.push(sentences.slice(paragraphSize * 2).join(" "));
  
  return paragraphs.join("\n\n");
};

// Helper function to add structure to the fallback summary
const structureSummary = (text: string): string => {
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  
  if (sentences.length <= 5) {
    return text;
  }
  
  // Create a structured summary
  let structured = "";
  
  // Introduction (first 25%)
  const introEnd = Math.floor(sentences.length * 0.25);
  structured += sentences.slice(0, introEnd).join(" ") + "\n\n";
  
  // Main content (next 50%)
  const mainEnd = Math.floor(sentences.length * 0.75);
  structured += sentences.slice(introEnd, mainEnd).join(" ") + "\n\n";
  
  // Conclusion (final 25%)
  structured += sentences.slice(mainEnd).join(" ");
  
  return structured;
};
