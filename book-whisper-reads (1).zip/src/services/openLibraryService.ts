import { bookFetch } from "@/services/bookFetch";

import { toast } from "sonner";
import { Book } from "./bookService";

const BASE_URL = "https://openlibrary.org";

// Convert Open Library book to our app's Book format
const parseOpenLibraryBook = (item: any): Book => {
  // Extract cover ID for thumbnail generation
  const coverId = item.cover_i || (item.covers && item.covers[0]) || null;
  
  // Make sure we have a valid cover ID or use a placeholder
  let thumbnailUrl = "/placeholder.svg";
  if (coverId) {
    // Use secure HTTPS URL
    thumbnailUrl = `https://covers.openlibrary.org/b/id/${coverId}-M.jpg`;
  } else if (item.isbn && item.isbn[0]) {
    // Try ISBN as fallback (with HTTPS)
    thumbnailUrl = `https://covers.openlibrary.org/b/isbn/${item.isbn[0]}-M.jpg`;
  }

  // Generate a reliable ID
  const id = item.key 
    ? item.key.replace("/works/", "") 
    : (item.edition_key && item.edition_key[0]) 
      ? item.edition_key[0] 
      : `ol-${Math.random().toString(36).substring(2, 15)}`;

  return {
    id: id,
    title: item.title || "Unknown Title",
    authors: item.author_name ? [...item.author_name] : [(item.author && item.author.name) || "Unknown Author"],
    description: item.description?.value || item.description || "No description available.",
    categories: item.subject || [],
    thumbnail: thumbnailUrl,
    publishedDate: item.first_publish_year?.toString() || item.publish_date || "Unknown",
    pageCount: item.number_of_pages_median || 0,
    language: item.language?.[0] || "en",
    previewLink: item.key ? `${BASE_URL}${item.key}` : `${BASE_URL}`,
    publisher: item.publisher?.[0] || "Unknown Publisher",
  };
};

// Search books using Open Library API with enhanced features
export const searchOpenLibraryBooks = async (query: string, maxResults: number = 20): Promise<Book[]> => {
  try {
    const response = await bookFetch(
      `${BASE_URL}/search.json?q=${encodeURIComponent(query)}&limit=${maxResults}&fields=key,title,author_name,first_publish_year,cover_i,isbn,subject,publisher,number_of_pages_median,language`
    );
    
    if (!response.ok) {
      throw new Error("Failed to fetch books from Open Library");
    }
    
    const data = await response.json();
    return data.docs 
      ? data.docs
          .filter(doc => doc && doc.title)
          .map(parseOpenLibraryBook) 
      : [];
  } catch (error) {
    console.warn("Open Library search notice:", error);
    return [];
  }
};

// Get book details by ISBN using Open Library Books API
export const getBookByISBN = async (isbn: string): Promise<Book | null> => {
  try {
    const response = await bookFetch(
      `${BASE_URL}/api/books?bibkeys=ISBN:${isbn}&format=json&jscmd=data`
    );
    
    if (!response.ok) {
      throw new Error("Failed to fetch book by ISBN");
    }
    
    const data = await response.json();
    const bookKey = `ISBN:${isbn}`;
    
    if (data[bookKey]) {
      const bookData = data[bookKey];
      return {
        id: isbn,
        title: bookData.title || "Unknown Title",
        authors: bookData.authors ? bookData.authors.map((a: any) => a.name) : ["Unknown Author"],
        description: bookData.excerpts?.[0]?.text || "No description available.",
        categories: bookData.subjects ? bookData.subjects.map((s: any) => s.name) : [],
        thumbnail: bookData.cover?.large || bookData.cover?.medium || "/placeholder.svg",
        publishedDate: bookData.publish_date || "Unknown",
        pageCount: bookData.number_of_pages || 0,
        language: "en",
        previewLink: bookData.url || `${BASE_URL}`,
        publisher: bookData.publishers?.[0]?.name || "Unknown Publisher"
      };
    }
    
    return null;
  } catch (error) {
    console.error("Error fetching book by ISBN:", error);
    return null;
  }
};

// Get books by category from Open Library
export const getOpenLibraryBooksBySubject = async (
  subject: string,
  maxResults: number = 10
): Promise<Book[]> => {
  try {
    const response = await bookFetch(
      `${BASE_URL}/subjects/${encodeURIComponent(subject.toLowerCase())}.json?limit=${maxResults}`
    );
    
    if (!response.ok) {
      throw new Error(`Failed to fetch ${subject} books from Open Library`);
    }
    
    const data = await response.json();
    // Return all works, even if they don't have covers
    return data.works ? data.works.map(parseOpenLibraryBook) : [];
  } catch (error) {
    console.error(`Error fetching ${subject} books from Open Library:`, error);
    toast.error(`Failed to load ${subject} books. Please try again.`);
    return [];
  }
};

// Get a book by ID from Open Library
export const getOpenLibraryBookById = async (id: string): Promise<Book | null> => {
  try {
    // Make sure we use CORS-friendly fetch
    const response = await bookFetch(`${BASE_URL}/works/${id}.json`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });
    
    if (!response.ok) {
      console.error(`OpenLibrary API responded with status: ${response.status}`);
      throw new Error("Failed to fetch book details from Open Library");
    }
    
    const data = await response.json();
    const book = parseOpenLibraryBook(data);
    
    // Fetch additional details like covers if available
    if (data.covers && data.covers.length > 0) {
      book.thumbnail = `https://covers.openlibrary.org/b/id/${data.covers[0]}-L.jpg`;
    }
    
    return book;
  } catch (error) {
    console.error("Error fetching book details from Open Library:", error);
    toast.error("Failed to load book details. Please try again.");
    return null;
  }
};

// Get trending books for entrepreneurs and business
export const getEntrepreneurBooks = async (): Promise<Book[]> => {
  try {
    // Use a variety of subjects for better results
    const subjects = ["entrepreneurship", "business", "investing", "technology", "innovation"];
    const randomSubject = subjects[Math.floor(Math.random() * subjects.length)];
    const books = await getOpenLibraryBooksBySubject(randomSubject, 12);
    
    return books;
  } catch (error) {
    console.error("Error fetching entrepreneur books:", error);
    toast.error("Failed to load entrepreneur books. Please try again.");
    return [];
  }
};

// Get books by famous tech entrepreneurs and innovators
export const getInnovatorBooks = async (): Promise<Book[]> => {
  try {
    // Search for books about or by famous tech entrepreneurs
    const figures = ["Steve Jobs", "Bill Gates", "Mark Zuckerberg", "Elon Musk", "Jeff Bezos"];
    const randomFigure = figures[Math.floor(Math.random() * figures.length)];
    
    const response = await bookFetch(
      `${BASE_URL}/search.json?q=${encodeURIComponent(randomFigure)}&limit=12`
    );
    
    if (!response.ok) {
      throw new Error("Failed to fetch innovator books");
    }
    
    const data = await response.json();
    return data.docs ? data.docs.map(parseOpenLibraryBook) : [];
  } catch (error) {
    console.error("Error fetching innovator books:", error);
    toast.error("Failed to load innovator books. Please try again.");
    return [];
  }
};
